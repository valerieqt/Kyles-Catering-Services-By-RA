<x-landing-layout>
    <!-- Edit Booking Section -->
    <section class="py-12 sm:py-16 lg:py-20 bg-gray-50 min-h-screen">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-8">
                <h2 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Edit Booking</h2>
                <p class="text-lg text-gray-600">
                    Update your booking details for {{ $booking->event_name }}
                </p>
            </div>

            <!-- Success/Error Messages -->
            @if(session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                    {{ session('success') }}
                </div>
            @endif

            @if(session('error'))
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    {{ session('error') }}
                </div>
            @endif

            <div class="bg-white rounded-lg shadow-lg p-6 sm:p-8">
                <!-- Current Booking Info -->
                <div class="bg-blue-50 rounded-lg p-4 mb-6">
                    <h3 class="text-lg font-semibold text-blue-900 mb-2">Current Booking Details</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div><strong>Event:</strong> {{ $booking->event_name }}</div>
                        <div><strong>Date:</strong> {{ $booking->event_date->format('F j, Y') }}</div>
                        <div><strong>Time:</strong> {{ $booking->event_time }}</div>
                        <div><strong>Guests:</strong> {{ $booking->guest_count }}</div>
                        <div><strong>Status:</strong> 
                            <span class="px-2 py-1 text-xs font-semibold rounded-full {{ $booking->status_badge }}">
                                {{ ucfirst($booking->status) }}
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Edit Form -->
                <form method="POST" action="{{ route('bookings.update', $booking) }}" class="space-y-6">
                    @csrf
                    @method('PUT')

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Event Name -->
                        <div>
                            <label for="event_name" class="block text-sm font-medium text-gray-700 mb-2">Event Name *</label>
                            <input type="text" id="event_name" name="event_name" 
                                   value="{{ old('event_name', $booking->event_name) }}"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                   required>
                            @error('event_name')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Event Type -->
                        <div>
                            <label for="event_type" class="block text-sm font-medium text-gray-700 mb-2">Event Type *</label>
                            <select id="event_type" name="event_type" 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                    required>
                                <option value="">Select Event Type</option>
                                <option value="Wedding" {{ old('event_type', $booking->event_type) == 'Wedding' ? 'selected' : '' }}>Wedding</option>
                                <option value="Birthday" {{ old('event_type', $booking->event_type) == 'Birthday' ? 'selected' : '' }}>Birthday</option>
                                <option value="Corporate" {{ old('event_type', $booking->event_type) == 'Corporate' ? 'selected' : '' }}>Corporate Event</option>
                                <option value="Anniversary" {{ old('event_type', $booking->event_type) == 'Anniversary' ? 'selected' : '' }}>Anniversary</option>
                                <option value="Graduation" {{ old('event_type', $booking->event_type) == 'Graduation' ? 'selected' : '' }}>Graduation</option>
                                <option value="Other" {{ old('event_type', $booking->event_type) == 'Other' ? 'selected' : '' }}>Other</option>
                            </select>
                            @error('event_type')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Event Date -->
                        <div>
                            <label for="event_date" class="block text-sm font-medium text-gray-700 mb-2">Event Date *</label>
                            <input type="date" id="event_date" name="event_date" 
                                   value="{{ old('event_date', $booking->event_date->format('Y-m-d')) }}"
                                   min="{{ date('Y-m-d', strtotime('+1 day')) }}"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                   required>
                            @error('event_date')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Event Time -->
                        <div>
                            <label for="event_time" class="block text-sm font-medium text-gray-700 mb-2">Event Time *</label>
                            <input type="time" id="event_time" name="event_time" 
                                   value="{{ old('event_time', $booking->event_time) }}"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                   required>
                            @error('event_time')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Guest Count -->
                        <div>
                            <label for="guest_count" class="block text-sm font-medium text-gray-700 mb-2">Number of Guests *</label>
                            <input type="number" id="guest_count" name="guest_count" 
                                   value="{{ old('guest_count', $booking->guest_count) }}"
                                   min="1"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                   required>
                            @error('guest_count')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Package Type -->
                        <div>
                            <label for="package_type" class="block text-sm font-medium text-gray-700 mb-2">Package Type</label>
                            <select id="package_type" name="package_type" 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500">
                                <option value="">Select Package (Optional)</option>
                                <option value="Basic" {{ old('package_type', $booking->package_type) == 'Basic' ? 'selected' : '' }}>Basic Package</option>
                                <option value="Premium" {{ old('package_type', $booking->package_type) == 'Premium' ? 'selected' : '' }}>Premium Package</option>
                                <option value="Deluxe" {{ old('package_type', $booking->package_type) == 'Deluxe' ? 'selected' : '' }}>Deluxe Package</option>
                                <option value="Custom" {{ old('package_type', $booking->package_type) == 'Custom' ? 'selected' : '' }}>Custom Package</option>
                            </select>
                            @error('package_type')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                    <!-- Venue -->
                    <div>
                        <label for="venue" class="block text-sm font-medium text-gray-700 mb-2">Venue *</label>
                        <input type="text" id="venue" name="venue" 
                               value="{{ old('venue', $booking->venue) }}"
                               placeholder="Enter venue address or location"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                               required>
                        @error('venue')
                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Contact Phone -->
                    <div>
                        <label for="contact_phone" class="block text-sm font-medium text-gray-700 mb-2">Contact Phone *</label>
                        <input type="tel" id="contact_phone" name="contact_phone" 
                               value="{{ old('contact_phone', $booking->contact_phone) }}"
                               placeholder="Enter your phone number"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                               required>
                        @error('contact_phone')
                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Additional Details -->
                    <div>
                        <label for="additional_details" class="block text-sm font-medium text-gray-700 mb-2">Additional Details</label>
                        <textarea id="additional_details" name="additional_details" rows="3"
                                  placeholder="Any additional information about your event"
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500">{{ old('additional_details', $booking->additional_details) }}</textarea>
                        @error('additional_details')
                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Special Requests -->
                    <div>
                        <label for="special_requests" class="block text-sm font-medium text-gray-700 mb-2">Special Requests</label>
                        <textarea id="special_requests" name="special_requests" rows="3"
                                  placeholder="Any special requests or requirements"
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500">{{ old('special_requests', $booking->special_requests) }}</textarea>
                        @error('special_requests')
                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Menu Preferences -->
                    <div>
                        <label for="menu_preferences" class="block text-sm font-medium text-gray-700 mb-2">Menu Preferences</label>
                        <textarea id="menu_preferences" name="menu_preferences" rows="3"
                                  placeholder="Dietary restrictions, preferred cuisines, etc."
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500">{{ old('menu_preferences', $booking->menu_preferences) }}</textarea>
                        @error('menu_preferences')
                            <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Action Buttons -->
                    <div class="flex flex-col sm:flex-row gap-4 pt-6">
                        <button type="submit" 
                                class="flex-1 bg-maroon-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-maroon-700 transition duration-300">
                            Update Booking
                        </button>
                        <a href="{{ route('bookings.index') }}" 
                           class="flex-1 text-center bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-700 transition duration-300">
                            Cancel Changes
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </section>
</x-landing-layout>
