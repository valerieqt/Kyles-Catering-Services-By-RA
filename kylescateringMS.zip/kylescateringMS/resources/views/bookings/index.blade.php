<x-landing-layout>
    <!-- My Bookings Section -->
    <section class="py-12 sm:py-16 lg:py-20 bg-gray-50 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 sm:mb-16">
                <h2 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">My Bookings</h2>
                <p class="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-4 sm:px-0">
                    Manage your upcoming events and view booking history
                </p>
            </div>

            @if($bookings->count() > 0)
                <!-- Bookings Stats -->
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
                    <div class="bg-white rounded-lg shadow-lg p-4 sm:p-6 text-center">
                        <div class="text-2xl sm:text-3xl font-bold text-maroon-600 mb-2">{{ $bookings->count() }}</div>
                        <div class="text-gray-600 text-sm sm:text-base">Total Bookings</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-lg p-4 sm:p-6 text-center">
                        <div class="text-2xl sm:text-3xl font-bold text-yellow-600 mb-2">{{ $bookings->where('status', 'pending')->count() }}</div>
                        <div class="text-gray-600 text-sm sm:text-base">Pending</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-lg p-4 sm:p-6 text-center">
                        <div class="text-2xl sm:text-3xl font-bold text-green-600 mb-2">{{ $bookings->where('status', 'confirmed')->count() }}</div>
                        <div class="text-gray-600 text-sm sm:text-base">Confirmed</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-lg p-4 sm:p-6 text-center">
                        <div class="text-2xl sm:text-3xl font-bold text-blue-600 mb-2">{{ $bookings->where('status', 'completed')->count() }}</div>
                        <div class="text-gray-600 text-sm sm:text-base">Completed</div>
                    </div>
                </div>

                <!-- Filter Buttons -->
                <div class="flex flex-wrap gap-2 sm:gap-4 mb-6 sm:mb-8 justify-center">
                    <button onclick="filterBookings('all')" class="filter-btn bg-maroon-600 text-white px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-lg font-semibold hover:bg-maroon-700 transition duration-300 touch-manipulation">
                        All Bookings
                    </button>
                    <button onclick="filterBookings('pending')" class="filter-btn bg-yellow-600 text-white px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-lg font-semibold hover:bg-yellow-700 transition duration-300 touch-manipulation">
                        Pending
                    </button>
                    <button onclick="filterBookings('confirmed')" class="filter-btn bg-green-600 text-white px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-lg font-semibold hover:bg-green-700 transition duration-300 touch-manipulation">
                        Confirmed
                    </button>
                    <button onclick="filterBookings('completed')" class="filter-btn bg-blue-600 text-white px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-lg font-semibold hover:bg-blue-700 transition duration-300 touch-manipulation">
                        Completed
                    </button>
                </div>

                <!-- Bookings List -->
                <div class="space-y-4 sm:space-y-6">
                    @foreach($bookings as $booking)
                        <div class="booking-item bg-white rounded-lg shadow-lg p-4 sm:p-6" data-status="{{ $booking->status }}">
                            <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
                                <!-- Booking Details -->
                                <div class="lg:col-span-2">
                                    <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-4">
                                        <div class="flex-1">
                                            <h3 class="text-lg sm:text-xl font-semibold text-gray-900 mb-2">
                                                {{ $booking->event_name }}
                                            </h3>
                                            <div class="flex items-center mb-2">
                                                <svg class="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                                </svg>
                                                <span class="text-gray-600">{{ $booking->event_date->format('F j, Y') }}</span>
                                            </div>
                                            <div class="flex items-center mb-2">
                                                <svg class="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                                                </svg>
                                                <span class="text-gray-600">{{ $booking->guest_count }} guests</span>
                                            </div>
                                            @if($booking->package_type)
                                                <div class="flex items-center mb-2">
                                                    <svg class="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                                                    </svg>
                                                    <span class="text-gray-600">{{ $booking->package_type }} Package</span>
                                                </div>
                                            @endif
                                        </div>
                                        <div class="flex flex-col sm:items-end space-y-2 mt-2 sm:mt-0">
                                            <span class="px-3 py-1 text-xs sm:text-sm font-semibold rounded-full {{ $booking->status_badge }} self-start sm:self-end">
                                                {{ ucfirst($booking->status) }}
                                            </span>
                                        </div>
                                    </div>
                                    
                                    @if($booking->additional_details)
                                        <div class="bg-gray-50 rounded-lg p-4 mb-4">
                                            <h4 class="text-sm font-semibold text-gray-700 mb-2">Additional Details:</h4>
                                            <p class="text-gray-600">{{ $booking->additional_details }}</p>
                                        </div>
                                    @endif
                                </div>

                                <!-- Contact & Actions -->
                                <div class="lg:col-span-1">
                                    <div class="bg-gray-50 rounded-lg p-4">
                                        <h4 class="text-sm font-semibold text-gray-700 mb-3">Client Information</h4>
                                        <div class="space-y-3">
                                            <div class="flex items-start">
                                                <svg class="w-4 h-4 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                                                </svg>
                                                <div>
                                                    <div class="text-sm font-medium text-gray-900">{{ $booking->user->name }}</div>
                                                    <div class="text-xs text-gray-500">Client Name</div>
                                                </div>
                                            </div>
                                            <div class="flex items-start">
                                                <svg class="w-4 h-4 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                                </svg>
                                                <div>
                                                    <div class="text-sm text-gray-600">{{ $booking->user->email }}</div>
                                                    <div class="text-xs text-gray-500">Email Address</div>
                                                </div>
                                            </div>
                                            <div class="flex items-start">
                                                <svg class="w-4 h-4 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                                                </svg>
                                                <div>
                                                    <div class="text-sm text-gray-600">{{ $booking->contact_phone ?? $booking->user->phone ?? 'N/A' }}</div>
                                                    <div class="text-xs text-gray-500">Phone Number</div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-4 pt-4 border-t border-gray-200">
                                            <div class="text-xs text-gray-500 mb-3">
                                                Booking Date: {{ $booking->created_at->format('M j, Y') }}
                                            </div>
                                            
                                            <!-- Action Buttons -->
                                            @if($booking->status !== 'completed' && $booking->status !== 'cancelled')
                                                <div class="flex flex-col space-y-2">
                                                    @if($booking->status === 'pending')
                                                        <a href="{{ route('bookings.edit', $booking) }}" 
                                                           class="text-center bg-blue-600 text-white px-3 py-2 text-xs rounded-lg font-semibold hover:bg-blue-700 transition duration-300">
                                                            Edit Details
                                                        </a>
                                                    @endif
                                                    
                                                    <button onclick="openRescheduleModal({{ $booking->id }}, '{{ $booking->event_name }}', '{{ $booking->event_date->format('Y-m-d') }}', '{{ $booking->event_time }}')" 
                                                            class="bg-yellow-600 text-white px-3 py-2 text-xs rounded-lg font-semibold hover:bg-yellow-700 transition duration-300">
                                                        Reschedule
                                                    </button>
                                                    
                                                    <button onclick="openCancelModal({{ $booking->id }}, '{{ $booking->event_name }}')" 
                                                            class="bg-red-600 text-white px-3 py-2 text-xs rounded-lg font-semibold hover:bg-red-700 transition duration-300">
                                                        Cancel Booking
                                                    </button>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>

            @else
                <!-- Empty State -->
                <div class="bg-white rounded-lg shadow-lg p-6 sm:p-8 lg:p-12 text-center">
                    <svg class="mx-auto h-12 w-12 sm:h-16 sm:w-16 text-gray-400 mb-4 sm:mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                    </svg>
                    <h3 class="text-xl sm:text-2xl font-semibold text-gray-900 mb-4">No bookings yet</h3>
                    <p class="text-gray-600 mb-6 sm:mb-8 max-w-2xl mx-auto px-4 sm:px-0">
                        You haven't made any bookings yet. Start by exploring our packages and book your next event!
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4 sm:space-x-4 justify-center">
                        <a href="/#packages" class="bg-maroon-600 text-white px-6 sm:px-8 py-3 rounded-lg font-semibold hover:bg-maroon-700 transition duration-300 touch-manipulation text-center">
                            View Packages
                        </a>
                        <a href="/#book-now" class="border border-maroon-600 text-maroon-600 px-6 sm:px-8 py-3 rounded-lg font-semibold hover:bg-maroon-50 transition duration-300 touch-manipulation text-center">
                            Book Now
                        </a>
                    </div>
                </div>
            @endif
        </div>
    </section>

    <!-- Reschedule Modal -->
    <div id="rescheduleModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 hidden z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-md w-full max-h-screen overflow-y-auto">
            <div class="flex items-center justify-between p-6 border-b border-gray-200">
                <h3 class="text-xl font-semibold text-gray-900">Reschedule Booking</h3>
                <button type="button" onclick="closeRescheduleModal()" class="text-gray-400 hover:text-gray-600 transition duration-200">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            
            <form id="rescheduleForm" method="POST" class="p-6">
                @csrf
                @method('PATCH')
                
                <!-- Current Booking Info -->
                <div class="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 class="font-medium text-blue-900 mb-2">Current Booking</h4>
                    <p class="text-sm text-blue-800 mb-1">Event: <span id="rescheduleEventName" class="font-semibold"></span></p>
                    <p class="text-sm text-blue-700">Date: <span id="currentEventDate"></span> at <span id="currentEventTime"></span></p>
                </div>
                
                <!-- New Date -->
                <div class="mb-4">
                    <label for="reschedule_event_date" class="block text-sm font-medium text-gray-700 mb-2">
                        New Date <span class="text-red-500">*</span>
                    </label>
                    <input type="date" id="reschedule_event_date" name="event_date" 
                           min="{{ date('Y-m-d', strtotime('+1 day')) }}"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500 transition duration-200"
                           required>
                    <div id="reschedule_date_error" class="text-red-500 text-xs mt-1 hidden"></div>
                </div>
                
                <!-- New Time -->
                <div class="mb-4">
                    <label for="reschedule_event_time" class="block text-sm font-medium text-gray-700 mb-2">
                        New Time <span class="text-red-500">*</span>
                    </label>
                    <input type="time" id="reschedule_event_time" name="event_time" 
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500 transition duration-200"
                           required>
                    <div id="reschedule_time_error" class="text-red-500 text-xs mt-1 hidden"></div>
                </div>
                
                <!-- Reason -->
                <div class="mb-6">
                    <label for="reschedule_reason" class="block text-sm font-medium text-gray-700 mb-2">
                        Reason for Rescheduling (Optional)
                    </label>
                    <textarea id="reschedule_reason" name="reschedule_reason" rows="3"
                              placeholder="Please let us know why you need to reschedule..."
                              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500 transition duration-200 resize-none"></textarea>
                </div>
                
                <!-- Action Buttons -->
                <div class="flex flex-col sm:flex-row gap-3 sm:justify-end">
                    <button type="button" onclick="closeRescheduleModal()" 
                            class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition duration-200 font-medium">
                        Cancel
                    </button>
                    <button type="submit" id="rescheduleSubmitBtn"
                            class="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition duration-200 font-medium flex items-center justify-center">
                        <span id="rescheduleSubmitText">Reschedule Booking</span>
                        <svg id="rescheduleSpinner" class="animate-spin -mr-1 ml-2 h-4 w-4 text-white hidden" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Cancel Modal -->
    <div id="cancelModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 hidden z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div class="flex items-center justify-between p-6 border-b border-gray-200">
                <h3 class="text-xl font-semibold text-gray-900">Cancel Booking</h3>
                <button type="button" onclick="closeCancelModal()" class="text-gray-400 hover:text-gray-600 transition duration-200">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            
            <form id="cancelForm" method="POST" class="p-6">
                @csrf
                @method('PATCH')
                
                <!-- Warning Message -->
                <div class="mb-6 p-4 bg-red-50 rounded-lg border border-red-200">
                    <div class="flex items-start">
                        <svg class="w-5 h-5 text-red-400 mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                        </svg>
                        <div>
                            <h4 class="font-medium text-red-900 mb-1">Confirm Cancellation</h4>
                            <p class="text-sm text-red-800 mb-2">
                                Are you sure you want to cancel: <span id="cancelEventName" class="font-semibold"></span>?
                            </p>
                            <p class="text-xs text-red-700">
                                This action cannot be undone. Please contact us if you need to make changes later.
                            </p>
                        </div>
                    </div>
                </div>
                
                <!-- Reason -->
                <div class="mb-6">
                    <label for="cancellation_reason" class="block text-sm font-medium text-gray-700 mb-2">
                        Reason for Cancellation (Optional)
                    </label>
                    <textarea id="cancellation_reason" name="cancellation_reason" rows="3"
                              placeholder="Please let us know why you're cancelling..."
                              class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 transition duration-200 resize-none"></textarea>
                </div>
                
                <!-- Action Buttons -->
                <div class="flex flex-col sm:flex-row gap-3 sm:justify-end">
                    <button type="button" onclick="closeCancelModal()" 
                            class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition duration-200 font-medium">
                        Keep Booking
                    </button>
                    <button type="submit" id="cancelSubmitBtn"
                            class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition duration-200 font-medium flex items-center justify-center">
                        <span id="cancelSubmitText">Cancel Booking</span>
                        <svg id="cancelSpinner" class="animate-spin -mr-1 ml-2 h-4 w-4 text-white hidden" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function filterBookings(status) {
            const bookingItems = document.querySelectorAll('.booking-item');
            const filterButtons = document.querySelectorAll('.filter-btn');
            
            // Reset all button styles
            filterButtons.forEach(btn => {
                btn.classList.remove('ring-2', 'ring-offset-2');
            });
            
            // Highlight active button
            event.target.classList.add('ring-2', 'ring-offset-2');
            
            bookingItems.forEach(item => {
                if (status === 'all' || item.dataset.status === status) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        function openRescheduleModal(bookingId, eventName, currentDate, currentTime) {
            // Reset form and errors
            document.getElementById('rescheduleForm').reset();
            hideFormErrors();
            
            // Set booking information
            document.getElementById('rescheduleEventName').textContent = eventName;
            document.getElementById('currentEventDate').textContent = new Date(currentDate).toLocaleDateString();
            document.getElementById('currentEventTime').textContent = currentTime;
            document.getElementById('rescheduleForm').action = `/bookings/${bookingId}/reschedule`;
            
            // Show modal
            document.getElementById('rescheduleModal').classList.remove('hidden');
            
            // Focus on first input
            setTimeout(() => {
                document.getElementById('reschedule_event_date').focus();
            }, 100);
        }

        function closeRescheduleModal() {
            document.getElementById('rescheduleModal').classList.add('hidden');
            document.getElementById('rescheduleForm').reset();
            hideFormErrors();
            resetSubmitButton('reschedule');
        }

        function openCancelModal(bookingId, eventName) {
            // Reset form
            document.getElementById('cancelForm').reset();
            
            // Set booking information
            document.getElementById('cancelEventName').textContent = eventName;
            document.getElementById('cancelForm').action = `/bookings/${bookingId}/cancel`;
            
            // Show modal
            document.getElementById('cancelModal').classList.remove('hidden');
            
            // Focus on textarea
            setTimeout(() => {
                document.getElementById('cancellation_reason').focus();
            }, 100);
        }

        function closeCancelModal() {
            document.getElementById('cancelModal').classList.add('hidden');
            document.getElementById('cancelForm').reset();
            resetSubmitButton('cancel');
        }

        function hideFormErrors() {
            document.getElementById('reschedule_date_error').classList.add('hidden');
            document.getElementById('reschedule_time_error').classList.add('hidden');
        }

        function showFormError(fieldId, message) {
            const errorElement = document.getElementById(fieldId + '_error');
            if (errorElement) {
                errorElement.textContent = message;
                errorElement.classList.remove('hidden');
            }
        }

        function resetSubmitButton(type) {
            if (type === 'reschedule') {
                document.getElementById('rescheduleSubmitBtn').disabled = false;
                document.getElementById('rescheduleSubmitText').textContent = 'Reschedule Booking';
                document.getElementById('rescheduleSpinner').classList.add('hidden');
            } else if (type === 'cancel') {
                document.getElementById('cancelSubmitBtn').disabled = false;
                document.getElementById('cancelSubmitText').textContent = 'Cancel Booking';
                document.getElementById('cancelSpinner').classList.add('hidden');
            }
        }

        function setSubmitLoading(type) {
            if (type === 'reschedule') {
                document.getElementById('rescheduleSubmitBtn').disabled = true;
                document.getElementById('rescheduleSubmitText').textContent = 'Rescheduling...';
                document.getElementById('rescheduleSpinner').classList.remove('hidden');
            } else if (type === 'cancel') {
                document.getElementById('cancelSubmitBtn').disabled = true;
                document.getElementById('cancelSubmitText').textContent = 'Cancelling...';
                document.getElementById('cancelSpinner').classList.remove('hidden');
            }
        }

        // Form validation
        document.getElementById('rescheduleForm').addEventListener('submit', function(e) {
            hideFormErrors();
            
            const dateInput = document.getElementById('reschedule_event_date');
            const timeInput = document.getElementById('reschedule_event_time');
            const today = new Date();
            const selectedDate = new Date(dateInput.value);
            
            let hasErrors = false;
            
            // Validate date
            if (!dateInput.value) {
                showFormError('reschedule_event_date', 'Please select a date');
                hasErrors = true;
            } else if (selectedDate <= today) {
                showFormError('reschedule_event_date', 'Please select a future date');
                hasErrors = true;
            }
            
            // Validate time
            if (!timeInput.value) {
                showFormError('reschedule_event_time', 'Please select a time');
                hasErrors = true;
            }
            
            if (hasErrors) {
                e.preventDefault();
                return false;
            }
            
            setSubmitLoading('reschedule');
        });

        document.getElementById('cancelForm').addEventListener('submit', function(e) {
            setSubmitLoading('cancel');
        });

        // Close modals when clicking outside
        document.getElementById('rescheduleModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeRescheduleModal();
            }
        });

        document.getElementById('cancelModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeCancelModal();
            }
        });

        // Close modals with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                if (!document.getElementById('rescheduleModal').classList.contains('hidden')) {
                    closeRescheduleModal();
                }
                if (!document.getElementById('cancelModal').classList.contains('hidden')) {
                    closeCancelModal();
                }
            }
        });
    </script>
</x-landing-layout>