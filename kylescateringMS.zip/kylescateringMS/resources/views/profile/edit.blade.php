<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-bold text-2xl text-maroon-800 leading-tight">
                {{ __('Profile Settings') }}
            </h2>
            <a href="/" class="text-maroon-600 hover:text-maroon-800 font-medium transition duration-150 ease-in-out">
                ← Back to Home
            </a>
        </div>
    </x-slot>

    <div class="py-12 bg-gray-50">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8 space-y-8">
            <!-- Profile Information -->
            <div class="bg-white shadow-xl rounded-lg border border-maroon-200 overflow-hidden">
                <div class="bg-gradient-to-r from-maroon-600 to-maroon-700 px-6 py-4">
                    <h3 class="text-lg font-semibold text-white">Profile Information</h3>
                    <p class="text-maroon-100 text-sm">Update your account's profile information and email address.</p>
                </div>
                <div class="p-6">
                    <div class="max-w-xl">
                        @include('profile.partials.update-profile-information-form')
                    </div>
                </div>
            </div>

            <!-- Update Password -->
            <div class="bg-white shadow-xl rounded-lg border border-maroon-200 overflow-hidden">
                <div class="bg-gradient-to-r from-maroon-600 to-maroon-700 px-6 py-4">
                    <h3 class="text-lg font-semibold text-white">Update Password</h3>
                    <p class="text-maroon-100 text-sm">Ensure your account is using a long, random password to stay secure.</p>
                </div>
                <div class="p-6">
                    <div class="max-w-xl">
                        @include('profile.partials.update-password-form')
                    </div>
                </div>
            </div>

            <!-- Delete Account -->
            <div class="bg-white shadow-xl rounded-lg border border-red-200 overflow-hidden">
                <div class="bg-gradient-to-r from-red-600 to-red-700 px-6 py-4">
                    <h3 class="text-lg font-semibold text-white">Delete Account</h3>
                    <p class="text-red-100 text-sm">Once your account is deleted, all of its resources and data will be permanently deleted.</p>
                </div>
                <div class="p-6">
                    <div class="max-w-xl">
                        @include('profile.partials.delete-user-form')
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
