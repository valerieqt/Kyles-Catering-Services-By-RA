<x-landing-layout>
    <!-- Profile Management Section -->
    <section class="py-20 bg-gray-50 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-gray-900 mb-4">Profile Management</h2>
                <p class="text-xl text-gray-600 max-w-3xl mx-auto">
                    Manage your account information and preferences
                </p>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Profile Navigation -->
                <div class="lg:col-span-1">
                    <div class="bg-white rounded-lg shadow-lg p-6 sticky top-24">
                        <div class="text-center mb-6">
                            <div class="w-20 h-20 bg-maroon-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <svg class="w-8 h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                                </svg>
                            </div>
                            <h3 class="text-lg font-semibold text-gray-900">{{ Auth::user()->name }}</h3>
                            <p class="text-gray-500">{{ Auth::user()->email }}</p>
                        </div>
                        
                        <nav class="space-y-2">
                            <a href="#profile-info" class="block px-4 py-2 text-gray-600 hover:text-maroon-600 hover:bg-maroon-50 rounded-lg transition duration-150">
                                Profile Information
                            </a>
                            <a href="#update-password" class="block px-4 py-2 text-gray-600 hover:text-maroon-600 hover:bg-maroon-50 rounded-lg transition duration-150">
                                Update Password
                            </a>
                            <a href="{{ route('bookings.index') }}" class="block px-4 py-2 text-gray-600 hover:text-maroon-600 hover:bg-maroon-50 rounded-lg transition duration-150">
                                My Bookings
                            </a>
                        </nav>
                    </div>
                </div>

                <!-- Profile Content -->
                <div class="lg:col-span-2 space-y-8">
                    <!-- Profile Information -->
                    <div id="profile-info" class="bg-white rounded-lg shadow-lg p-8">
                        <h3 class="text-2xl font-semibold text-gray-900 mb-6">Profile Information</h3>
                        
                        @if(session('status') === 'profile-updated')
                            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                                Profile updated successfully!
                            </div>
                        @endif

                        <form method="POST" action="{{ route('profile.update') }}" class="space-y-6">
                            @csrf
                            @method('PATCH')

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Name</label>
                                <input type="text" name="name" value="{{ old('name', $user->name) }}" 
                                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-maroon-300 focus:border-maroon-300 @error('name') border-red-500 @enderror">
                                @error('name')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                                <input type="email" name="email" value="{{ old('email', $user->email) }}" 
                                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-maroon-300 focus:border-maroon-300 @error('email') border-red-500 @enderror">
                                @error('email')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                                
                                @if ($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail())
                                    <div class="mt-2">
                                        <p class="text-sm mt-2 text-gray-800">
                                            Your email address is unverified.
                                            <button form="send-verification" class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                                Click here to re-send the verification email.
                                            </button>
                                        </p>

                                        @if (session('status') === 'verification-link-sent')
                                            <p class="mt-2 font-medium text-sm text-green-600">
                                                A new verification link has been sent to your email address.
                                            </p>
                                        @endif
                                    </div>
                                @endif
                            </div>

                            <div class="flex items-center justify-end">
                                <button type="submit" class="bg-maroon-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-maroon-700 transition duration-300">
                                    Update Profile
                                </button>
                            </div>
                        </form>

                        @if ($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail())
                            <form id="send-verification" method="POST" action="{{ route('verification.send') }}">
                                @csrf
                            </form>
                        @endif
                    </div>

                    <!-- Update Password -->
                    <div id="update-password" class="bg-white rounded-lg shadow-lg p-8">
                        <h3 class="text-2xl font-semibold text-gray-900 mb-6">Update Password</h3>
                        
                        @if(session('status') === 'password-updated')
                            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                                Password updated successfully!
                            </div>
                        @endif

                        <form method="POST" action="{{ route('password.update') }}" class="space-y-6">
                            @csrf
                            @method('PUT')

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Current Password</label>
                                <input type="password" name="current_password" 
                                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-maroon-300 focus:border-maroon-300 @error('current_password', 'updatePassword') border-red-500 @enderror">
                                @error('current_password', 'updatePassword')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                                <input type="password" name="password" 
                                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-maroon-300 focus:border-maroon-300 @error('password', 'updatePassword') border-red-500 @enderror">
                                @error('password', 'updatePassword')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
                                <input type="password" name="password_confirmation" 
                                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-maroon-300 focus:border-maroon-300 @error('password_confirmation', 'updatePassword') border-red-500 @enderror">
                                @error('password_confirmation', 'updatePassword')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <div class="flex items-center justify-end">
                                <button type="submit" class="bg-maroon-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-maroon-700 transition duration-300">
                                    Update Password
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Delete Account -->
                    <div class="bg-white rounded-lg shadow-lg p-8 border-2 border-red-200">
                        <h3 class="text-2xl font-semibold text-red-600 mb-6">Delete Account</h3>
                        <div class="mb-6">
                            <p class="text-gray-600 mb-4">
                                Once your account is deleted, all of your resources and data will be permanently deleted. Before deleting your account, please download any data or information that you wish to retain.
                            </p>
                        </div>
                        
                        <form method="POST" action="{{ route('profile.destroy') }}" class="space-y-6" onsubmit="return confirm('Are you sure you want to delete your account? This action cannot be undone.')">
                            @csrf
                            @method('DELETE')

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Confirm your password to delete account</label>
                                <input type="password" name="password" placeholder="Password" 
                                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-red-300 focus:border-red-300 @error('password', 'userDeletion') border-red-500 @enderror">
                                @error('password', 'userDeletion')
                                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                                @enderror
                            </div>

                            <div class="flex items-center justify-end">
                                <button type="submit" class="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition duration-300">
                                    Delete Account
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</x-landing-layout>