@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-6">
    <div class="max-w-2xl mx-auto">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-3xl font-bold text-gray-900">Task Details</h1>
            <a href="{{ route('tasks.index', ['date' => $task->task_date->format('Y-m-d')]) }}" 
               class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors">
                Back to Schedule
            </a>
        </div>

        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="space-y-6">
                <!-- Task Header -->
                <div class="border-b border-gray-200 pb-4">
                    <div class="flex items-center justify-between">
                        <h2 class="text-2xl font-semibold text-gray-900">{{ $task->title }}</h2>
                        <span class="px-3 py-1 text-sm rounded-full {{ $task->status_badge }}">
                            {{ ucfirst($task->status) }}
                        </span>
                    </div>
                    <p class="text-gray-600 mt-2">{{ $task->description ?: 'No description provided.' }}</p>
                </div>

                <!-- Task Details -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h3 class="text-lg font-medium text-gray-900 mb-3">Schedule Information</h3>
                        <div class="space-y-3">
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-gray-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 4v10a2 2 0 002 2h4a2 2 0 002-2V11m-6 0h8m-8 0H6a2 2 0 00-2 2v6a2 2 0 002 2h2"></path>
                                </svg>
                                <span class="text-gray-700">{{ ucfirst(str_replace('_', ' ', $task->type)) }}</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-gray-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 4v10a2 2 0 002 2h4a2 2 0 002-2V11m-6 0h8m-8 0H6a2 2 0 00-2 2v6a2 2 0 002 2h2"></path>
                                </svg>
                                <span class="text-gray-700">{{ $task->task_date->format('F j, Y') }}</span>
                            </div>
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-gray-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span class="text-gray-700">{{ \Carbon\Carbon::parse($task->task_time)->format('g:i A') }}</span>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-lg font-medium text-gray-900 mb-3">People Involved</h3>
                        <div class="space-y-3">
                            <div class="flex items-center">
                                <svg class="w-5 h-5 text-gray-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                </svg>
                                <div>
                                    <span class="text-sm text-gray-500">Created by:</span>
                                    <span class="text-gray-700 block">{{ $task->creator->first_name }} {{ $task->creator->last_name }}</span>
                                </div>
                            </div>
                            @if($task->user && $task->user->id !== $task->creator->id)
                                <div class="flex items-center">
                                    <svg class="w-5 h-5 text-gray-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                    </svg>
                                    <div>
                                        <span class="text-sm text-gray-500">Assigned to:</span>
                                        <span class="text-gray-700 block">{{ $task->user->first_name }} {{ $task->user->last_name }}</span>
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Reminder Status -->
                <div class="border-t border-gray-200 pt-4">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 text-gray-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-5 5v-5zM4.828 4.828A4 4 0 015.5 4H9v1H5.5a3 3 0 00-2.121.879l-.707.707A1 1 0 002 7.414V11h1V7.414l.879-.879A2 2 0 015.5 6H9V5H5.5a3 3 0 00-2.121.879z"></path>
                        </svg>
                        <span class="text-gray-700">
                            Reminder: {{ $task->reminder_sent ? 'Sent' : 'Pending' }}
                        </span>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200">
                    @if($task->status !== 'completed')
                        <form action="{{ route('tasks.complete', $task) }}" method="POST" class="inline">
                            @csrf
                            @method('PATCH')
                            <button type="submit" 
                                    class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors">
                                Mark as Complete
                            </button>
                        </form>
                    @endif
                    
                    <a href="{{ route('tasks.index', ['date' => $task->task_date->format('Y-m-d')]) }}" 
                       class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                        Edit Task
                    </a>
                    
                    <form action="{{ route('tasks.destroy', $task) }}" method="POST" class="inline" 
                          onsubmit="return confirm('Are you sure you want to delete this task?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" 
                                class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors">
                            Delete Task
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
