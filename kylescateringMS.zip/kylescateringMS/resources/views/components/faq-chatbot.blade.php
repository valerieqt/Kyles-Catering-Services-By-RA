<!-- FAQ Chatbot Component -->
<style>
/* Modern typing indicator animation */
@keyframes typing-bounce {
    0%, 60%, 100% {
        transform: translateY(0);
        opacity: 0.4;
    }
    30% {
        transform: translateY(-10px);
        opacity: 1;
    }
}

.typing-dot {
    animation: typing-bounce 1.4s infinite ease-in-out;
}

.typing-dot:nth-child(1) { animation-delay: 0s; }
.typing-dot:nth-child(2) { animation-delay: 0.2s; }
.typing-dot:nth-child(3) { animation-delay: 0.4s; }

/* Pulse animation for typing text */
@keyframes pulse-text {
    0%, 100% { opacity: 0.6; }
    50% { opacity: 1; }
}

.typing-text {
    animation: pulse-text 1.5s infinite;
}

/* Smooth message appearance */
.message-appear {
    animation: messageSlideIn 0.3s ease-out;
}

@keyframes messageSlideIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>
<div id="faq-chatbot" class="fixed bottom-4 right-4 z-50">
    <!-- Chatbot Toggle Button -->
    <button id="chatbot-toggle" class="bg-maroon-600 hover:bg-maroon-700 text-white rounded-full p-4 shadow-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-maroon-300">
        <svg id="chat-icon" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
        </svg>
        <svg id="close-icon" class="w-6 h-6 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
        </svg>
    </button>

    <!-- Chatbot Window -->
    <div id="chatbot-window" class="hidden absolute bottom-16 right-0 w-80 sm:w-96 bg-white rounded-lg shadow-2xl border border-gray-200 overflow-hidden">
        <!-- Header -->
        <div class="bg-maroon-600 text-white p-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center mr-3">
                        <svg class="w-5 h-5 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <div>
                        <h3 class="font-semibold text-lg">Kyle's FAQ Assistant</h3>
                        <p class="text-maroon-200 text-sm">Ask me anything!</p>
                    </div>
                </div>
                <button id="minimize-chat" class="text-maroon-200 hover:text-white transition-colors">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                    </svg>
                </button>
            </div>
        </div>

        <!-- Chat Content -->
        <div class="h-96 flex flex-col">
            <!-- Chat Messages Area -->
            <div class="flex-1 overflow-y-auto p-4" id="chat-messages">
                <!-- Initial message -->
                <div class="mb-4">
                    <div class="bg-maroon-50 rounded-lg p-3 mb-3">
                        <p class="text-sm text-maroon-800 font-medium">How can I help you today?</p>
                        <p class="text-xs text-maroon-600 mt-1">Choose from the questions below:</p>
                    </div>
                </div>

                <!-- FAQ Questions as Chat Options -->
                <div id="faq-questions" class="space-y-2">
                    <!-- Questions will be populated by JavaScript -->
                </div>

                <!-- Chat conversation area -->
                <div id="chat-conversation" class="space-y-3 mt-4">
                    <!-- Chat messages will appear here -->
                </div>
            </div>

            <!-- Footer -->
            <div class="border-t border-gray-100 p-3 bg-gray-50">
                <div class="flex items-center justify-between text-xs text-gray-500">
                    <span>Still need help?</span>
                    <a href="tel:09356337433" class="text-maroon-600 hover:text-maroon-700 font-medium">
                        📞 Call us
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// FAQ Data
const faqData = [
    {
        id: 1,
        question: "What events do you cater?",
        answer: "Weddings, birthdays, corporate events, family gatherings, and more—big or small, we've got you covered!",
        keywords: ["events", "cater", "wedding", "birthday", "corporate", "family", "gathering"],
        category: "events"
    },
    {
        id: 2,
        question: "How far in advance should I book?",
        answer: "We recommend minimum of 4 weeks to plan for your event.",
        keywords: ["advance", "book", "booking", "schedule", "time", "weeks"],
        category: "booking"
    },
    {
        id: 3,
        question: "Can I customize the menu?",
        answer: "Yes! We can accommodate dietary restrictions like vegetarian, vegan, gluten-free, and more.",
        keywords: ["customize", "menu", "dietary", "vegetarian", "vegan", "gluten-free", "restrictions"],
        category: "menu"
    },
    {
        id: 4,
        question: "Do you offer tasting sessions?",
        answer: "Absolutely! Taste first, then finalize your menu. We can set up a meeting on the date we agreed.",
        keywords: ["tasting", "sessions", "taste", "meeting", "sample", "try"],
        category: "menu"
    },
    {
        id: 5,
        question: "Are beverages included?",
        answer: "Soft drinks and juices can be included. Alcohol is available upon request.",
        keywords: ["beverages", "drinks", "soft drinks", "juices", "alcohol", "included"],
        category: "menu"
    },
    {
        id: 6,
        question: "Can you handle themed events?",
        answer: "Yes! We design menus to match your theme or event concept.",
        keywords: ["themed", "events", "theme", "design", "concept", "match"],
        category: "events"
    },
    {
        id: 7,
        question: "How much does catering cost?",
        answer: "Pricing depends on guests, menu, and services. Contact us for a personalized quote.",
        keywords: ["cost", "pricing", "price", "quote", "guests", "menu", "services", "money"],
        category: "pricing"
    },
    {
        id: 8,
        question: "Do you provide staff and equipment?",
        answer: "Yes, we provide servers, utensils, plates, and all essential equipment.",
        keywords: ["staff", "equipment", "servers", "utensils", "plates", "provide"],
        category: "services"
    },
    {
        id: 9,
        question: "Do you do buffet and plated service?",
        answer: "Yes! We can handle both buffet-style and formal plated dinners.",
        keywords: ["buffet", "plated", "service", "style", "formal", "dinners"],
        category: "services"
    },
    {
        id: 10,
        question: "What if guest numbers change?",
        answer: "No worries! Just inform us ASAP, and we'll adjust accordingly.",
        keywords: ["guest", "numbers", "change", "adjust", "inform", "asap"],
        category: "booking"
    },
    {
        id: 11,
        question: "Can you accommodate last-minute orders?",
        answer: "We'll do our best—availability depends on date and event size.",
        keywords: ["last-minute", "orders", "availability", "date", "event", "size"],
        category: "booking"
    }
];

// Chatbot functionality
document.addEventListener('DOMContentLoaded', function() {
    const chatbotToggle = document.getElementById('chatbot-toggle');
    const chatbotWindow = document.getElementById('chatbot-window');
    const minimizeChat = document.getElementById('minimize-chat');
    const chatIcon = document.getElementById('chat-icon');
    const closeIcon = document.getElementById('close-icon');
    const faqQuestions = document.getElementById('faq-questions');
    const chatConversation = document.getElementById('chat-conversation');
    const chatMessages = document.getElementById('chat-messages');

    let isOpen = false;
    let conversationStarted = false;

    // Toggle chatbot
    function toggleChatbot() {
        isOpen = !isOpen;
        if (isOpen) {
            chatbotWindow.classList.remove('hidden');
            chatIcon.classList.add('hidden');
            closeIcon.classList.remove('hidden');
            if (!conversationStarted) {
                renderQuestionButtons();
            }
        } else {
            chatbotWindow.classList.add('hidden');
            chatIcon.classList.remove('hidden');
            closeIcon.classList.add('hidden');
        }
    }

    // Render question buttons
    function renderQuestionButtons() {
        faqQuestions.innerHTML = '';
        
        faqData.forEach(item => {
            const questionButton = document.createElement('button');
            questionButton.className = 'w-full text-left p-3 bg-white border border-gray-200 rounded-lg hover:bg-maroon-50 hover:border-maroon-200 transition-colors text-sm';
            questionButton.innerHTML = `
                <div class="flex items-center justify-between">
                    <span class="text-gray-700">${item.question}</span>
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                </div>
            `;
            questionButton.addEventListener('click', () => selectQuestion(item));
            faqQuestions.appendChild(questionButton);
        });
    }

    // Handle question selection
    function selectQuestion(item) {
        conversationStarted = true;
        
        // Hide question buttons
        faqQuestions.style.display = 'none';
        
        // Add user message
        addMessage(item.question, 'user');
        
        // Show typing indicator
        setTimeout(() => {
            showTypingIndicator();
        }, 300);
        
        // Add bot response after typing delay
        setTimeout(() => {
            hideTypingIndicator();
            addMessage(item.answer, 'bot');
            addBackButton();
        }, 2000);
    }

    // Show typing indicator
    function showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typing-indicator';
        typingDiv.className = 'flex justify-start mb-3 message-appear';
        
        typingDiv.innerHTML = `
            <div class="bg-gray-100 px-4 py-3 rounded-lg max-w-xs shadow-sm">
                <div class="flex items-center space-x-3">
                    <div class="flex space-x-1">
                        <div class="w-2 h-2 bg-maroon-400 rounded-full typing-dot"></div>
                        <div class="w-2 h-2 bg-maroon-400 rounded-full typing-dot"></div>
                        <div class="w-2 h-2 bg-maroon-400 rounded-full typing-dot"></div>
                    </div>
                    <span class="text-xs text-gray-500 typing-text">Kyle's Assistant is typing...</span>
                </div>
            </div>
        `;
        
        chatConversation.appendChild(typingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Hide typing indicator
    function hideTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    // Add message to chat
    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'} mb-3 message-appear`;
        
        const messageBubble = document.createElement('div');
        messageBubble.className = `max-w-xs lg:max-w-md px-4 py-2 rounded-lg shadow-sm ${
            sender === 'user' 
                ? 'bg-maroon-600 text-white' 
                : 'bg-gray-100 text-gray-800'
        }`;
        
        messageBubble.innerHTML = `<p class="text-sm leading-relaxed">${text}</p>`;
        messageDiv.appendChild(messageBubble);
        chatConversation.appendChild(messageDiv);
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Add back button to ask another question
    function addBackButton() {
        setTimeout(() => {
            const backButtonDiv = document.createElement('div');
            backButtonDiv.className = 'flex justify-center mt-4';
            backButtonDiv.innerHTML = `
                <button id="ask-another" class="bg-maroon-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-maroon-700 transition-colors">
                    Ask Another Question
                </button>
            `;
            chatConversation.appendChild(backButtonDiv);
            
            // Add event listener to back button
            document.getElementById('ask-another').addEventListener('click', resetChat);
            
            // Scroll to bottom
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 500);
    }

    // Reset chat to show questions again
    function resetChat() {
        chatConversation.innerHTML = '';
        faqQuestions.style.display = 'block';
        conversationStarted = false;
        renderQuestionButtons();
    }

    // Event listeners
    chatbotToggle.addEventListener('click', toggleChatbot);
    minimizeChat.addEventListener('click', toggleChatbot);

    // Close chatbot when clicking outside
    document.addEventListener('click', (e) => {
        if (isOpen && !document.getElementById('faq-chatbot').contains(e.target)) {
            toggleChatbot();
        }
    });

    // Prevent closing when clicking inside chatbot
    document.getElementById('faq-chatbot').addEventListener('click', (e) => {
        e.stopPropagation();
    });
});
</script>
