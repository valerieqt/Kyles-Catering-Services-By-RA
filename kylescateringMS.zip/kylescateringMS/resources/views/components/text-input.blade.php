@props(['disabled' => false])

<input @disabled($disabled) {{ $attributes->merge(['class' => 'border-gray-300 focus:border-maroon-500 focus:ring-maroon-500 rounded-lg shadow-sm px-4 py-3 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-maroon-200 transition duration-150 ease-in-out']) }}>
