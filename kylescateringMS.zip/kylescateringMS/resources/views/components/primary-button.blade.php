<button {{ $attributes->merge(['type' => 'submit', 'class' => 'inline-flex items-center px-6 py-3 bg-maroon-600 border border-transparent rounded-lg font-semibold text-sm text-white uppercase tracking-wider hover:bg-maroon-700 focus:bg-maroon-700 active:bg-maroon-800 focus:outline-none focus:ring-2 focus:ring-maroon-500 focus:ring-offset-2 transition ease-in-out duration-150 shadow-lg hover:shadow-xl transform hover:scale-105']) }}>
    {{ $slot }}
</button>
