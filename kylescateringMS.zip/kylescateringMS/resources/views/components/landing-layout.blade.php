<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Kyle\'s Catering') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="font-sans antialiased bg-gray-50">
        @include('components.landing-nav')

        <!-- Page Content -->
        <main>
            {{ $slot }}
        </main>

        <!-- FAQ Chatbot -->
        @include('components.faq-chatbot')

        <!-- Footer -->
        <footer class="bg-maroon-800 text-white">
            <div class="max-w-7xl mx-auto py-8 sm:py-12 px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
                    <div class="col-span-1 sm:col-span-2 lg:col-span-2">
                        <h3 class="text-xl sm:text-2xl font-bold mb-4">Kyle's Catering</h3>
                        <p class="text-maroon-200 mb-4 text-sm sm:text-base">
                            Creating memorable experiences through exceptional food and service.
                            From intimate gatherings to grand celebrations, we bring your vision to life.
                        </p>
                        <div class="flex space-x-4 justify-center sm:justify-start">
                            <a href="https://www.facebook.com/kylesevent72?mibextid=wwXIfr&rdid=o37noybKzVLMoPGL&share_url=https%3A%2F%2Fwww.facebook.com%2Fshare%2F14P9BKdnmCY%2F%3Fmibextid%3DwwXIfr" target="_blank" class="text-maroon-200 hover:text-white transition duration-150">
                                <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                                </svg>
                            </a>
                        </div>
                    </div>
                    <div class="text-center sm:text-left">
                        <h4 class="text-base sm:text-lg font-semibold mb-4">Quick Links</h4>
                        <ul class="space-y-2">
                            <li><a href="/#home" class="text-maroon-200 hover:text-white transition duration-150 text-sm sm:text-base touch-manipulation">Home</a></li>
                            <li><a href="/#services" class="text-maroon-200 hover:text-white transition duration-150 text-sm sm:text-base touch-manipulation">Services</a></li>
                            <li><a href="/#packages" class="text-maroon-200 hover:text-white transition duration-150 text-sm sm:text-base touch-manipulation">Packages</a></li>
                            <li><a href="/#gallery" class="text-maroon-200 hover:text-white transition duration-150 text-sm sm:text-base touch-manipulation">Gallery</a></li>
                        </ul>
                    </div>
                    <div class="text-center sm:text-left">
                        <h4 class="text-base sm:text-lg font-semibold mb-4">Contact Info</h4>
                        <div class="space-y-2 text-maroon-200 text-sm sm:text-base">
                            <p>
                                <a href="tel: 09356337433" class="hover:text-white transition duration-150 touch-manipulation flex items-center justify-center sm:justify-start">
                                    <svg class="w-4 h-4 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                                    </svg>
                                    <span>09356337433</span>
                                </a>
                            </p>
                            <p>
                                <a href="mailto:kylescateringservicesbyra@gmail.com" class="hover:text-white transition duration-150 touch-manipulation flex items-center justify-center sm:justify-start">
                                    <svg class="w-4 h-4 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                    </svg>
                                    <span>kylescateringservicesbyra@gmail.com</span>
                                </a>
                            </p>
                            <p class="flex items-start justify-center sm:justify-start">
                                <svg class="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                                </svg>
                                <span>Brgy. Pook, Taal, Philippines</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="border-t border-maroon-700 mt-6 sm:mt-8 pt-6 sm:pt-8 text-center text-maroon-200">
                    <p class="text-sm sm:text-base">&copy; {{ date('Y') }} Kyle's Catering. All rights reserved.</p>
                </div>
            </div>
        </footer>

        <!-- Toast Notifications -->
        <div id="toast-container" class="fixed top-16 sm:top-20 right-2 sm:right-4 z-50 space-y-2 max-w-xs sm:max-w-sm">
            <!-- Toast messages will be inserted here -->
        </div>

        <!-- Toast JavaScript -->
        <script>
            function showToast(message, type = 'success') {
                const toast = document.createElement('div');
                const bgColor = type === 'success' ? 'bg-green-500' : type === 'error' ? 'bg-red-500' : 'bg-blue-500';
                
                toast.className = `${bgColor} text-white px-6 py-4 rounded-lg shadow-lg transform transition-all duration-300 translate-x-full opacity-0 max-w-sm`;
                toast.innerHTML = `
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                ${type === 'success' ? 
                                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>' :
                                    type === 'error' ?
                                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>' :
                                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>'
                                }
                            </svg>
                            <span>${message}</span>
                        </div>
                        <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                `;
                
                document.getElementById('toast-container').appendChild(toast);
                
                // Show toast
                setTimeout(() => {
                    toast.classList.remove('translate-x-full', 'opacity-0');
                    toast.classList.add('translate-x-0', 'opacity-100');
                }, 100);
                
                // Auto hide after 5 seconds
                setTimeout(() => {
                    toast.classList.add('translate-x-full', 'opacity-0');
                    setTimeout(() => {
                        if (toast.parentElement) {
                            toast.parentElement.removeChild(toast);
                        }
                    }, 300);
                }, 5000);
            }

            // Check for flash messages on page load
            document.addEventListener('DOMContentLoaded', function() {
                @if(session('login_success'))
                    showToast('{{ session('login_success') }}', 'success');
                @endif
                
                @if(session('logout_success'))
                    showToast('{{ session('logout_success') }}', 'success');
                @endif
                
                @if(session('register_success'))
                    showToast('{{ session('register_success') }}', 'success');
                @endif
            });
        </script>
    </body>
</html>
