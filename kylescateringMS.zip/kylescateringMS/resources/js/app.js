import './bootstrap';

import Alpine from 'alpinejs';

// Make Alpine available globally
window.Alpine = Alpine;

// Start Alpine
Alpine.start();

// Debug log to confirm Alpine is loaded
console.log('Alpine.js loaded:', window.Alpine);

// Additional initialization for mobile menu debugging
document.addEventListener('alpine:init', () => {
    console.log('Alpine.js initialized successfully');
});

// Fallback check
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (typeof window.Alpine !== 'undefined') {
            console.log('Alpine.js is working properly');
        } else {
            console.warn('Alpine.js not loaded - using fallback JavaScript');
        }
    }, 100);
});
