<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('staff_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('staff_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('booking_id')->constrained('bookings')->onDelete('cascade');
            $table->string('role'); // e.g., 'Head Chef', 'Server', 'Event Coordinator'
            $table->enum('status', ['pending', 'confirmed', 'declined', 'completed'])->default('pending');
            $table->text('notes')->nullable();
            $table->text('requirements')->nullable(); // JSON field for requirements array
            $table->timestamp('assigned_at')->useCurrent();
            $table->timestamp('responded_at')->nullable();
            $table->timestamps();

            // Ensure a staff member can only have one assignment per booking
            $table->unique(['staff_id', 'booking_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('staff_assignments');
    }
};
