<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('icon')->default('cube-outline');
            $table->string('color')->default('#7c2d12');
            $table->text('description')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // Insert default categories
        DB::table('categories')->insert([
            [
                'name' => 'Tables',
                'icon' => 'restaurant-outline',
                'color' => '#7c2d12',
                'description' => 'Dining and event tables',
                'is_active' => true,
                'sort_order' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Chairs',
                'icon' => 'person-outline',
                'color' => '#a16207',
                'description' => 'Seating furniture',
                'is_active' => true,
                'sort_order' => 2,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Linens',
                'icon' => 'shirt-outline',
                'color' => '#059669',
                'description' => 'Tablecloths, napkins, and fabric items',
                'is_active' => true,
                'sort_order' => 3,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Kitchen Equipment',
                'icon' => 'restaurant',
                'color' => '#dc2626',
                'description' => 'Cooking and food preparation equipment',
                'is_active' => true,
                'sort_order' => 4,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Dinnerware',
                'icon' => 'cafe-outline',
                'color' => '#7c3aed',
                'description' => 'Plates, bowls, and serving dishes',
                'is_active' => true,
                'sort_order' => 5,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Glassware',
                'icon' => 'wine-outline',
                'color' => '#0891b2',
                'description' => 'Glasses, cups, and drinking vessels',
                'is_active' => true,
                'sort_order' => 6,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Audio/Visual',
                'icon' => 'volume-high-outline',
                'color' => '#ea580c',
                'description' => 'Sound systems, microphones, and AV equipment',
                'is_active' => true,
                'sort_order' => 7,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Lighting',
                'icon' => 'bulb-outline',
                'color' => '#eab308',
                'description' => 'Lighting fixtures and equipment',
                'is_active' => true,
                'sort_order' => 8,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Decorations',
                'icon' => 'flower-outline',
                'color' => '#ec4899',
                'description' => 'Decorative items and centerpieces',
                'is_active' => true,
                'sort_order' => 9,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Tents',
                'icon' => 'home-outline',
                'color' => '#16a34a',
                'description' => 'Outdoor tents and canopies',
                'is_active' => true,
                'sort_order' => 10,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('categories');
    }
};
