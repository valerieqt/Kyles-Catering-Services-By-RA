<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('inventory_return_reports', function (Blueprint $table) {
            $table->id();
            $table->foreignId('booking_id')->constrained('bookings')->onDelete('cascade');
            $table->foreignId('event_inventory_allocation_id')->constrained('event_inventory_allocations')->onDelete('cascade');
            $table->foreignId('returned_by')->constrained('users')->onDelete('cascade');
            $table->integer('quantity_returned');
            $table->integer('quantity_damaged')->default(0);
            $table->integer('quantity_missing')->default(0);
            $table->text('damage_description')->nullable();
            $table->text('missing_description')->nullable();
            $table->text('general_notes')->nullable();
            $table->json('damage_photos')->nullable(); // Store photo paths
            $table->decimal('damage_cost', 10, 2)->default(0);
            $table->decimal('replacement_cost', 10, 2)->default(0);
            $table->enum('condition', ['excellent', 'good', 'fair', 'poor', 'damaged'])->default('good');
            $table->timestamp('returned_at');
            $table->timestamps();

            // Indexes
            $table->index(['booking_id', 'returned_at']);
            $table->index('returned_by');
            $table->index('condition');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('inventory_return_reports');
    }
};
