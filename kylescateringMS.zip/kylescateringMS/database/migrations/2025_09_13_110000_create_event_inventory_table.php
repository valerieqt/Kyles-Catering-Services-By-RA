<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('event_inventory', function (Blueprint $table) {
            $table->id();
            $table->foreignId('booking_id')->constrained()->onDelete('cascade');
            $table->foreignId('inventory_item_id')->constrained()->onDelete('cascade');
            $table->integer('quantity_reserved');
            $table->integer('quantity_used')->default(0);
            $table->integer('quantity_returned')->default(0);
            $table->integer('quantity_damaged')->default(0);
            $table->integer('quantity_lost')->default(0);
            $table->text('damage_notes')->nullable();
            $table->enum('status', ['reserved', 'in_use', 'returned', 'partially_returned'])->default('reserved');
            $table->timestamp('reserved_at')->nullable();
            $table->timestamp('used_at')->nullable();
            $table->timestamp('returned_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('event_inventory');
    }
};
