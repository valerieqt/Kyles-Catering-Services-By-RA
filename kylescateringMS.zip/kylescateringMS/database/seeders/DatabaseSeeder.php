<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            // User and Admin seeders first (required for other seeders)
            AdminSeeder::class,
            // UserSeeder::class,
            
            // Event types (required for bookings)
            EventTypeSeeder::class,
            
            // Core data seeders
            // BookingSeeder::class,
            SingleInventorySeeder::class,
            
            // Dependent seeders (require users and bookings)
            // StaffAssignmentSeeder::class,
            
            // Sample data seeder (optional, for testing)
            // SampleDataSeeder::class,
        ]);
    }
}
