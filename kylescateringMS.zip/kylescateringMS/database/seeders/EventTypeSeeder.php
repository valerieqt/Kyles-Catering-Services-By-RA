<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\EventType;

class EventTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $eventTypes = [
            [
                'name' => 'Wedding',
                'icon' => 'heart',
                'color' => '#ec4899',
                'description' => 'Wedding ceremonies and receptions',
                'is_active' => true,
                'sort_order' => 1,
            ],
            [
                'name' => 'Corporate Event',
                'icon' => 'briefcase',
                'color' => '#3b82f6',
                'description' => 'Business meetings, conferences, and corporate gatherings',
                'is_active' => true,
                'sort_order' => 2,
            ],
            [
                'name' => 'Birthday Party',
                'icon' => 'cake',
                'color' => '#f59e0b',
                'description' => 'Birthday celebrations and parties',
                'is_active' => true,
                'sort_order' => 3,
            ],
            [
                'name' => 'Anniversary',
                'icon' => 'gift',
                'color' => '#8b5cf6',
                'description' => 'Anniversary celebrations',
                'is_active' => true,
                'sort_order' => 4,
            ],
            [
                'name' => 'Graduation',
                'icon' => 'academic-cap',
                'color' => '#10b981',
                'description' => 'Graduation ceremonies and parties',
                'is_active' => true,
                'sort_order' => 5,
            ],
            [
                'name' => 'Baby Shower',
                'icon' => 'baby',
                'color' => '#06b6d4',
                'description' => 'Baby shower celebrations',
                'is_active' => true,
                'sort_order' => 6,
            ],
            [
                'name' => 'Holiday Party',
                'icon' => 'sparkles',
                'color' => '#dc2626',
                'description' => 'Holiday and seasonal celebrations',
                'is_active' => true,
                'sort_order' => 7,
            ],
            [
                'name' => 'Charity Event',
                'icon' => 'heart-hand',
                'color' => '#059669',
                'description' => 'Fundraising and charity events',
                'is_active' => true,
                'sort_order' => 8,
            ],
            [
                'name' => 'Art Event',
                'icon' => 'paint-brush',
                'color' => '#7c3aed',
                'description' => 'Art exhibitions and cultural events',
                'is_active' => true,
                'sort_order' => 9,
            ],
            [
                'name' => 'Music Event',
                'icon' => 'musical-note',
                'color' => '#e11d48',
                'description' => 'Concerts and music festivals',
                'is_active' => true,
                'sort_order' => 10,
            ],
            [
                'name' => 'Reunion',
                'icon' => 'users',
                'color' => '#0891b2',
                'description' => 'Family and school reunions',
                'is_active' => true,
                'sort_order' => 11,
            ],
            [
                'name' => 'Private Party',
                'icon' => 'home',
                'color' => '#7c2d12',
                'description' => 'Private parties and gatherings',
                'is_active' => true,
                'sort_order' => 12,
            ],
            [
                'name' => 'Other',
                'icon' => 'ellipsis-horizontal',
                'color' => '#6b7280',
                'description' => 'Other types of events',
                'is_active' => true,
                'sort_order' => 99,
            ],
        ];

        foreach ($eventTypes as $eventType) {
            EventType::updateOrCreate(
                ['name' => $eventType['name']],
                $eventType
            );
        }

        $this->command->info('✅ Created ' . count($eventTypes) . ' event types');
    }
}
