<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Booking;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class SampleDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->command->info('🌱 Creating sample staff and bookings...');

        // Create additional staff members
        $staff1 = User::updateOrCreate(
            ['email' => 'maria.garcia@kylescatering.com'],
            [
                'name' => 'Maria Garcia',
                'first_name' => 'Maria',
                'last_name' => 'Garcia',
                'email' => 'maria.garcia@kylescatering.com',
                'password' => Hash::make('staff123'),
                'role' => 'staff',
                'email_verified_at' => now(),
            ]
        );

        $staff2 = User::updateOrCreate(
            ['email' => 'james.wilson@kylescatering.com'],
            [
                'name' => 'James Wilson',
                'first_name' => 'James',
                'last_name' => 'Wilson',
                'email' => 'james.wilson@kylescatering.com',
                'password' => Hash::make('staff123'),
                'role' => 'staff',
                'email_verified_at' => now(),
            ]
        );

        $staff3 = User::updateOrCreate(
            ['email' => 'sarah.johnson@kylescatering.com'],
            [
                'name' => 'Sarah Johnson',
                'first_name' => 'Sarah',
                'last_name' => 'Johnson',
                'email' => 'sarah.johnson@kylescatering.com',
                'password' => Hash::make('staff123'),
                'role' => 'staff',
                'email_verified_at' => now(),
            ]
        );

        $this->command->info('✅ Sample staff created:');
        $this->command->info('   Maria Garcia - maria.garcia@kylescatering.com');
        $this->command->info('   James Wilson - james.wilson@kylescatering.com');
        $this->command->info('   Sarah Johnson - sarah.johnson@kylescatering.com');

        // Get admin user for creating bookings
        $admin = User::where('email', 'admin@kylescatering.com')->first();
        $existingStaff = User::where('email', 'staff@kylescatering.com')->first();

        // Create sample bookings
        $sampleBookings = [
            [
                'user_id' => $admin->id,
                'event_name' => 'Corporate Annual Gala',
                'event_date' => now()->addDays(15)->format('Y-m-d'),
                'event_time' => '18:00',
                'guest_count' => 150,
                'event_type' => 'Corporate Event',
                'package_type' => 'Premium',
                'venue' => 'Grand Ballroom, Marriott Hotel',
                'contact_phone' => '+1-555-0123',
                'additional_details' => 'Black-tie event with live entertainment',
                'special_requests' => 'Vegetarian and gluten-free options needed',
                'menu_preferences' => 'Fine dining, 3-course meal with wine pairing',
                'status' => 'confirmed',
            ],
            [
                'user_id' => $staff1->id,
                'event_name' => 'Wedding Reception - Smith & Johnson',
                'event_date' => now()->addDays(30)->format('Y-m-d'),
                'event_time' => '17:30',
                'guest_count' => 80,
                'event_type' => 'Wedding',
                'package_type' => 'Deluxe',
                'venue' => 'Garden Pavilion, Central Park',
                'contact_phone' => '+1-555-0456',
                'additional_details' => 'Outdoor wedding with garden theme',
                'special_requests' => 'Cake cutting ceremony at 8 PM',
                'menu_preferences' => 'Buffet style with international cuisine',
                'status' => 'pending',
            ],
            [
                'user_id' => $staff2->id,
                'event_name' => 'Birthday Celebration - 50th Anniversary',
                'event_date' => now()->addDays(7)->format('Y-m-d'),
                'event_time' => '14:00',
                'guest_count' => 45,
                'event_type' => 'Birthday Party',
                'package_type' => 'Standard',
                'venue' => 'Private Residence - 123 Oak Street',
                'contact_phone' => '+1-555-0789',
                'additional_details' => 'Surprise party for golden anniversary',
                'special_requests' => 'Photo booth setup and anniversary cake',
                'menu_preferences' => 'Traditional American cuisine with dessert bar',
                'status' => 'confirmed',
            ],
            [
                'user_id' => $existingStaff->id,
                'event_name' => 'Product Launch Event',
                'event_date' => now()->addDays(45)->format('Y-m-d'),
                'event_time' => '19:00',
                'guest_count' => 200,
                'event_type' => 'Corporate Event',
                'package_type' => 'Premium',
                'venue' => 'Tech Convention Center, Hall A',
                'contact_phone' => '+1-555-0321',
                'additional_details' => 'Technology product launch with media presence',
                'special_requests' => 'Live streaming setup and branded decorations',
                'menu_preferences' => 'Cocktail reception with canapés and finger foods',
                'status' => 'pending',
            ],
            [
                'user_id' => $staff3->id,
                'event_name' => 'Graduation Party',
                'event_date' => now()->addDays(20)->format('Y-m-d'),
                'event_time' => '16:00',
                'guest_count' => 60,
                'event_type' => 'Graduation',
                'package_type' => 'Standard',
                'venue' => 'Community Center - Main Hall',
                'contact_phone' => '+1-555-0654',
                'additional_details' => 'High school graduation celebration',
                'special_requests' => 'Photo slideshow and graduation cap decorations',
                'menu_preferences' => 'Casual dining with pizza, salads, and desserts',
                'status' => 'completed',
            ]
        ];

        foreach ($sampleBookings as $bookingData) {
            Booking::updateOrCreate(
                [
                    'event_name' => $bookingData['event_name'],
                    'event_date' => $bookingData['event_date']
                ],
                $bookingData
            );
        }

        $this->command->info('✅ Sample bookings created:');
        $this->command->info('   - Corporate Annual Gala (Confirmed)');
        $this->command->info('   - Wedding Reception (Pending)');
        $this->command->info('   - 50th Anniversary Birthday (Confirmed)');
        $this->command->info('   - Product Launch Event (Pending)');
        $this->command->info('   - Graduation Party (Completed)');

        $this->command->info('');
        $this->command->info('🎉 Sample data created successfully!');
        $this->command->info('You can now test the staff management and booking features.');
        $this->command->info('');
        $this->command->info('📱 Test the mobile app with these credentials:');
        $this->command->info('   Admin: admin@kylescatering.com / admin123');
        $this->command->info('   Staff: staff@kylescatering.com / staff123');
        $this->command->info('   Staff: maria.garcia@kylescatering.com / staff123');
    }
}
