<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\InventoryItem;

class SingleInventorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create just one inventory item for testing
        InventoryItem::create([
            'name' => 'Round Table (8-person)',
            'description' => 'Large round table for 8 people - perfect for events',
            'category' => 'Tables',
            'total_quantity' => 5,
            'available_quantity' => 2, // Low stock to test notifications
            'reserved_quantity' => 3,
            'damaged_quantity' => 0,
            'lost_quantity' => 0,
            'unit_cost' => 150.00,
            'condition' => 'good',
            'location' => 'Warehouse A',
            'notes' => 'Test inventory item for low stock notifications'
        ]);

        $this->command->info('✅ Created 1 inventory item: Round Table (8-person)');
        $this->command->info('📊 Quantity: 2 available / 5 total (Low Stock Alert!)');
    }
}
