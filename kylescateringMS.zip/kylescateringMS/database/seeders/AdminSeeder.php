<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create main admin account
        $admin = User::updateOrCreate(
            ['email' => 'admin@kylescatering.com'],
            [
                'name' => 'Kyle Admin',
                'email' => 'admin@kylescatering.com',
                'password' => Hash::make('admin123'),
                'role' => 'admin',
                'email_verified_at' => now(),
            ]
        );

        $this->command->info('✅ Admin account created:');
        $this->command->info('   Email: admin@kylescatering.com');
        $this->command->info('   Password: admin123');
        $this->command->info('   Role: admin');

        // Create staff account
        $staff = User::updateOrCreate(
            ['email' => 'staff@kylescatering.com'],
            [
                'name' => 'Staff Member',
                'email' => 'staff@kylescatering.com',
                'password' => Hash::make('staff123'),
                'role' => 'staff',
                'email_verified_at' => now(),
            ]
        );

        $this->command->info('✅ Staff account created:');
        $this->command->info('   Email: staff@kylescatering.com');
        $this->command->info('   Password: staff123');
        $this->command->info('   Role: staff');

        // Create additional test admin
        $testAdmin = User::updateOrCreate(
            ['email' => 'test@admin.com'],
            [
                'name' => 'Test Administrator',
                'email' => 'test@admin.com',
                'password' => Hash::make('password123'),
                'role' => 'admin',
                'email_verified_at' => now(),
            ]
        );

        $this->command->info('✅ Test admin account created:');
        $this->command->info('   Email: test@admin.com');
        $this->command->info('   Password: password123');
        $this->command->info('   Role: admin');

        $this->command->info('');
        $this->command->info('🎉 All admin accounts have been created successfully!');
        $this->command->info('You can now test login with any of the above credentials.');
    }
}
