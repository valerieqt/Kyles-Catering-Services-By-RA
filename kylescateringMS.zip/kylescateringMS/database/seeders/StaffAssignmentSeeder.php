<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\StaffAssignment;
use App\Models\User;
use App\Models\Booking;

class StaffAssignmentSeeder extends Seeder
{
    /**
     * Run the database seeder.
     */
    public function run(): void
    {
        // Get staff members and bookings
        $staffMembers = User::where('role', 'staff')->get();
        $bookings = Booking::whereIn('status', ['confirmed', 'pending'])->get();

        if ($staffMembers->isEmpty()) {
            $this->command->info('No staff members found. Please run UserSeeder first.');
            return;
        }

        if ($bookings->isEmpty()) {
            $this->command->info('No bookings found. Please run BookingSeeder first.');
            return;
        }

        $roles = [
            'Head Chef',
            'Sous Chef',
            'Server',
            'Bartender',
            'Event Coordinator',
            'Kitchen Assistant',
            'Catering Manager',
            'Setup Crew',
            'Cleanup Crew'
        ];

        $assignments = [];

        // Create assignments for some bookings
        foreach ($bookings->take(8) as $booking) {
            // Assign 1-2 staff members per event (or all available if less than 2)
            $maxAssignments = min(2, $staffMembers->count());
            $assignmentCount = rand(1, $maxAssignments);
            $selectedStaff = $staffMembers->random($assignmentCount);
            
            foreach ($selectedStaff as $staff) {
                $role = $roles[array_rand($roles)];
                
                $assignment = StaffAssignment::create([
                    'staff_id' => $staff->id,
                    'booking_id' => $booking->id,
                    'role' => $role,
                    'status' => $booking->status === 'confirmed' ? 'confirmed' : 'pending',
                    'notes' => $this->generateNotes($role),
                    'requirements' => $this->generateRequirements($role),
                    'assigned_at' => now(),
                    'responded_at' => $booking->status === 'confirmed' ? now() : null,
                ]);

                $assignments[] = $assignment;
            }
        }

        $this->command->info('✅ Created ' . count($assignments) . ' staff assignments');
        $this->command->info('📋 Assignment Status Distribution:');
        $this->command->info('   - Confirmed: ' . collect($assignments)->where('status', 'confirmed')->count());
        $this->command->info('   - Pending: ' . collect($assignments)->where('status', 'pending')->count());
    }

    private function generateNotes($role)
    {
        $notes = [
            'Head Chef' => 'Lead kitchen operations and oversee food preparation',
            'Sous Chef' => 'Assist head chef and manage kitchen staff',
            'Server' => 'Provide excellent customer service and food delivery',
            'Bartender' => 'Prepare and serve beverages, manage bar area',
            'Event Coordinator' => 'Oversee event logistics and coordinate with client',
            'Kitchen Assistant' => 'Support kitchen operations and food prep',
            'Catering Manager' => 'Manage overall catering operations',
            'Setup Crew' => 'Handle event setup and equipment arrangement',
            'Cleanup Crew' => 'Responsible for post-event cleanup and breakdown'
        ];

        return $notes[$role] ?? 'Standard event duties as assigned';
    }

    private function generateRequirements($role)
    {
        $requirements = [
            'Head Chef' => ['Professional chef attire', 'Food safety certification', 'Leadership skills'],
            'Sous Chef' => ['Professional chef attire', 'Food safety certification', 'Team coordination'],
            'Server' => ['Professional serving attire', 'Customer service experience', 'Physical stamina'],
            'Bartender' => ['Professional attire', 'Bartending certification', 'Knowledge of cocktails'],
            'Event Coordinator' => ['Professional business attire', 'Communication skills', 'Event management experience'],
            'Kitchen Assistant' => ['Kitchen-appropriate attire', 'Food safety awareness', 'Willingness to learn'],
            'Catering Manager' => ['Professional attire', 'Management experience', 'Problem-solving skills'],
            'Setup Crew' => ['Comfortable work attire', 'Physical strength', 'Attention to detail'],
            'Cleanup Crew' => ['Comfortable work attire', 'Thoroughness', 'Time management']
        ];

        return $requirements[$role] ?? ['Professional attire', 'Punctuality', 'Team player'];
    }
}
