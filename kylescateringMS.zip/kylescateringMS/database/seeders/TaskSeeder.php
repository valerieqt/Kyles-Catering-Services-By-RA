<?php

namespace Database\Seeders;

use App\Models\Task;
use App\Models\User;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class TaskSeeder extends Seeder
{
    public function run(): void
    {
        // Get the first admin user, or create one if none exists
        $admin = User::where('role', 'admin')->first();
        
        if (!$admin) {
            $admin = User::first();
        }

        if (!$admin) {
            $this->command->warn('No users found. Please create a user first before running this seeder.');
            return;
        }

        $tasks = [
            [
                'title' => 'Client Meeting - Wedding Planning',
                'description' => 'Initial consultation with the Johnson family for their wedding catering needs. Discuss menu options, guest count, and venue requirements.',
                'task_date' => now()->addDays(2),
                'task_time' => '10:00:00',
                'type' => 'client_meeting',
                'status' => 'pending',
                'user_id' => $admin->id,
                'created_by' => $admin->id,
            ],
            [
                'title' => 'Food Tasting Session',
                'description' => 'Menu tasting for the corporate event next month. Test new appetizer combinations and main course options.',
                'task_date' => now()->addDays(3),
                'task_time' => '14:30:00',
                'type' => 'food_tasting',
                'status' => 'pending',
                'user_id' => $admin->id,
                'created_by' => $admin->id,
            ],
            [
                'title' => 'Team Meeting - Weekly Review',
                'description' => 'Weekly team meeting to review upcoming events, inventory status, and staff assignments.',
                'task_date' => now()->addDays(1),
                'task_time' => '09:00:00',
                'type' => 'meeting',
                'status' => 'pending',
                'user_id' => $admin->id,
                'created_by' => $admin->id,
            ],
            [
                'title' => 'Consultation - Birthday Party',
                'description' => 'Phone consultation with Mrs. Smith regarding catering for her daughter\'s 16th birthday party.',
                'task_date' => now()->addDays(5),
                'task_time' => '16:00:00',
                'type' => 'consultation',
                'status' => 'pending',
                'user_id' => $admin->id,
                'created_by' => $admin->id,
            ],
            [
                'title' => 'Vendor Meeting - Supplier Review',
                'description' => 'Meeting with local suppliers to review pricing and quality of ingredients for the upcoming season.',
                'task_date' => now()->addDays(7),
                'task_time' => '11:00:00',
                'type' => 'other',
                'status' => 'pending',
                'user_id' => $admin->id,
                'created_by' => $admin->id,
            ],
            [
                'title' => 'Completed Event Follow-up',
                'description' => 'Follow-up call with the Anderson family regarding their recent anniversary celebration.',
                'task_date' => now()->subDays(1),
                'task_time' => '15:00:00',
                'type' => 'client_meeting',
                'status' => 'completed',
                'user_id' => $admin->id,
                'created_by' => $admin->id,
                'reminder_sent' => true,
            ],
        ];

        foreach ($tasks as $taskData) {
            Task::create($taskData);
        }

        $this->command->info('Created ' . count($tasks) . ' sample tasks.');
    }
}
