<?php

namespace Database\Seeders;

use App\Models\InventoryItem;
use Illuminate\Database\Seeder;

class InventorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $inventoryItems = [
            // Tables and Seating
            [
                'name' => 'Round Tables (8-person)',
                'description' => 'Round dining tables that seat 8 people comfortably',
                'category' => 'Tables',
                'total_quantity' => 25,
                'available_quantity' => 25,
                'unit_cost' => 45.00,
                'condition' => 'good',
                'location' => 'Warehouse A - Section 1',
                'notes' => 'White tablecloth compatible'
            ],
            [
                'name' => 'Rectangular Tables (6-person)',
                'description' => 'Rectangular dining tables for 6 people',
                'category' => 'Tables',
                'total_quantity' => 20,
                'available_quantity' => 20,
                'unit_cost' => 35.00,
                'condition' => 'good',
                'location' => 'Warehouse A - Section 1'
            ],
            [
                'name' => 'Chiavari Chairs - Gold',
                'description' => 'Elegant gold Chiavari chairs for formal events',
                'category' => 'Chairs',
                'total_quantity' => 200,
                'available_quantity' => 200,
                'unit_cost' => 8.50,
                'condition' => 'good',
                'location' => 'Warehouse A - Section 2',
                'notes' => 'Cushions available separately'
            ],
            [
                'name' => 'Folding Chairs - White',
                'description' => 'White plastic folding chairs for casual events',
                'category' => 'Chairs',
                'total_quantity' => 150,
                'available_quantity' => 150,
                'unit_cost' => 3.25,
                'condition' => 'good',
                'location' => 'Warehouse A - Section 2'
            ],
            
            // Linens and Decorations
            [
                'name' => 'White Tablecloths (Round)',
                'description' => 'White polyester tablecloths for round tables',
                'category' => 'Linens',
                'total_quantity' => 50,
                'available_quantity' => 50,
                'unit_cost' => 12.00,
                'condition' => 'good',
                'location' => 'Warehouse B - Linen Storage'
            ],
            [
                'name' => 'Black Tablecloths (Rectangular)',
                'description' => 'Black polyester tablecloths for rectangular tables',
                'category' => 'Linens',
                'total_quantity' => 40,
                'available_quantity' => 40,
                'unit_cost' => 12.00,
                'condition' => 'good',
                'location' => 'Warehouse B - Linen Storage'
            ],
            [
                'name' => 'Cloth Napkins - White',
                'description' => 'White cotton napkins',
                'category' => 'Linens',
                'total_quantity' => 500,
                'available_quantity' => 500,
                'unit_cost' => 2.50,
                'condition' => 'good',
                'location' => 'Warehouse B - Linen Storage'
            ],
            [
                'name' => 'Centerpiece Vases',
                'description' => 'Glass vases for table centerpieces',
                'category' => 'Decorations',
                'total_quantity' => 30,
                'available_quantity' => 30,
                'unit_cost' => 15.00,
                'condition' => 'good',
                'location' => 'Warehouse B - Decorations'
            ],
            
            // Kitchen Equipment
            [
                'name' => 'Chafing Dishes',
                'description' => 'Stainless steel chafing dishes for buffet service',
                'category' => 'Kitchen Equipment',
                'total_quantity' => 20,
                'available_quantity' => 20,
                'unit_cost' => 85.00,
                'condition' => 'good',
                'location' => 'Kitchen Storage',
                'notes' => 'Includes fuel canisters'
            ],
            [
                'name' => 'Serving Trays - Large',
                'description' => 'Large stainless steel serving trays',
                'category' => 'Kitchen Equipment',
                'total_quantity' => 40,
                'available_quantity' => 40,
                'unit_cost' => 25.00,
                'condition' => 'good',
                'location' => 'Kitchen Storage'
            ],
            [
                'name' => 'Coffee Urns',
                'description' => '100-cup capacity coffee urns',
                'category' => 'Kitchen Equipment',
                'total_quantity' => 6,
                'available_quantity' => 6,
                'unit_cost' => 120.00,
                'condition' => 'good',
                'location' => 'Kitchen Storage',
                'notes' => 'Regular maintenance required'
            ],
            
            // Utensils and Dinnerware
            [
                'name' => 'Dinner Plates - White',
                'description' => 'White ceramic dinner plates',
                'category' => 'Dinnerware',
                'total_quantity' => 300,
                'available_quantity' => 300,
                'unit_cost' => 4.50,
                'condition' => 'good',
                'location' => 'Kitchen Storage - Dinnerware'
            ],
            [
                'name' => 'Wine Glasses',
                'description' => 'Clear glass wine glasses',
                'category' => 'Glassware',
                'total_quantity' => 200,
                'available_quantity' => 200,
                'unit_cost' => 3.75,
                'condition' => 'good',
                'location' => 'Kitchen Storage - Glassware',
                'notes' => 'Handle with care - fragile'
            ],
            [
                'name' => 'Silverware Sets',
                'description' => 'Complete silverware sets (fork, knife, spoon)',
                'category' => 'Utensils',
                'total_quantity' => 250,
                'available_quantity' => 250,
                'unit_cost' => 6.00,
                'condition' => 'good',
                'location' => 'Kitchen Storage - Utensils'
            ],
            
            // Audio/Visual Equipment
            [
                'name' => 'Wireless Microphones',
                'description' => 'Professional wireless microphone systems',
                'category' => 'Audio/Visual',
                'total_quantity' => 8,
                'available_quantity' => 8,
                'unit_cost' => 150.00,
                'condition' => 'good',
                'location' => 'AV Storage',
                'notes' => 'Batteries and charging stations included'
            ],
            [
                'name' => 'Portable Speakers',
                'description' => 'Bluetooth portable speakers for background music',
                'category' => 'Audio/Visual',
                'total_quantity' => 12,
                'available_quantity' => 12,
                'unit_cost' => 75.00,
                'condition' => 'good',
                'location' => 'AV Storage'
            ],
            
            // Lighting and Ambiance
            [
                'name' => 'String Lights - Warm White',
                'description' => 'LED string lights for ambient lighting',
                'category' => 'Lighting',
                'total_quantity' => 20,
                'available_quantity' => 20,
                'unit_cost' => 25.00,
                'condition' => 'good',
                'location' => 'Warehouse B - Decorations'
            ],
            [
                'name' => 'Uplighting - LED',
                'description' => 'Color-changing LED uplighting fixtures',
                'category' => 'Lighting',
                'total_quantity' => 16,
                'available_quantity' => 16,
                'unit_cost' => 95.00,
                'condition' => 'good',
                'location' => 'AV Storage',
                'notes' => 'Remote controls included'
            ],
            
            // Tents and Outdoor Equipment
            [
                'name' => 'Party Tent 20x30',
                'description' => 'Large white party tent for outdoor events',
                'category' => 'Tents',
                'total_quantity' => 3,
                'available_quantity' => 3,
                'unit_cost' => 450.00,
                'condition' => 'good',
                'location' => 'Outdoor Storage',
                'notes' => 'Stakes and guy-lines included'
            ],
            [
                'name' => 'Cocktail Tables',
                'description' => 'High-top cocktail tables for standing events',
                'category' => 'Tables',
                'total_quantity' => 15,
                'available_quantity' => 15,
                'unit_cost' => 55.00,
                'condition' => 'good',
                'location' => 'Warehouse A - Section 1'
            ]
        ];

        foreach ($inventoryItems as $item) {
            InventoryItem::updateOrCreate(
                ['name' => $item['name']],
                $item
            );
        }

        $this->command->info('✅ Created ' . count($inventoryItems) . ' inventory items');
        $this->command->info('📦 Inventory categories: Tables, Chairs, Linens, Decorations, Kitchen Equipment, Dinnerware, Glassware, Utensils, Audio/Visual, Lighting, Tents');
        $this->command->info('💰 Total inventory value: $' . number_format(
            collect($inventoryItems)->sum(function($item) {
                return $item['total_quantity'] * $item['unit_cost'];
            }), 2
        ));
    }
}
