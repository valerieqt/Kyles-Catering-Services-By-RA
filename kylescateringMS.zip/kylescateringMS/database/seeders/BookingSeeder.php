<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Booking;
use App\Models\User;
use App\Models\EventType;
use Carbon\Carbon;

class BookingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get users to assign bookings to
        $users = User::all();
        
        if ($users->isEmpty()) {
            $this->command->info('No users found. Please run UserSeeder first.');
            return;
        }

        // Create some client users for bookings
        $clientEmails = [
            'john.doe@example.com',
            'sarah.johnson@company.com',
            'michael.brown@events.com',
            'emily.davis@wedding.com',
            'david.wilson@corporate.com'
        ];

        foreach ($clientEmails as $email) {
            $user = User::updateOrCreate(
                ['email' => $email],
                [
                    'name' => $this->generateNameFromEmail($email),
                    'first_name' => explode('.', explode('@', $email)[0])[0],
                    'last_name' => explode('.', explode('@', $email)[0])[1] ?? 'Client',
                    'password' => bcrypt('password123'),
                    'role' => 'client',
                    'email_verified_at' => now(),
                ]
            );
            $users[] = $user;
        }

        // Generate dynamic dates relative to current time
        $now = Carbon::now();
        
        // Get available event types, fallback to default if none exist
        $eventTypes = EventType::active()->pluck('name')->toArray();
        if (empty($eventTypes)) {
            $eventTypes = ['Wedding', 'Corporate Event', 'Birthday Party', 'Anniversary', 'Other'];
        }
        
        // Helper function to get random event type
        $getRandomEventType = function() use ($eventTypes) {
            return $eventTypes[array_rand($eventTypes)];
        };
        
        // Comprehensive booking data
        $bookings = [
            // Past Events (Completed)
            [
                'event_name' => 'Annual Corporate Gala 2024',
                'event_date' => $now->copy()->subDays(rand(30, 60))->format('Y-m-d'),
                'event_time' => '18:30',
                'guest_count' => '100+',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Premium',
                'venue' => 'Grand Ballroom, Marriott Downtown',
                'contact_phone' => '+1-555-0123',
                'additional_details' => 'Black-tie corporate annual celebration with awards ceremony',
                'special_requests' => 'Live jazz band, photo booth, premium bar service',
                'menu_preferences' => '4-course fine dining with wine pairing, vegetarian options',
                'status' => 'completed',
            ],
            [
                'event_name' => 'Smith-Johnson Wedding Reception',
                'event_date' => $now->copy()->subDays(rand(20, 40))->format('Y-m-d'),
                'event_time' => '17:00',
                'guest_count' => '100+',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Deluxe',
                'venue' => 'Sunset Gardens, Central Park Pavilion',
                'contact_phone' => '+1-555-0456',
                'additional_details' => 'Outdoor wedding reception with garden theme',
                'special_requests' => 'Cake cutting at 8 PM, string quartet during dinner',
                'menu_preferences' => 'Buffet style with international cuisine, gluten-free options',
                'status' => 'completed',
            ],
            [
                'event_name' => 'Tech Startup Product Launch',
                'event_date' => $now->copy()->subDays(rand(10, 25))->format('Y-m-d'),
                'event_time' => '19:00',
                'guest_count' => '100+',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Premium',
                'venue' => 'Innovation Hub, Tech District',
                'contact_phone' => '+1-555-0789',
                'additional_details' => 'Product launch event with media and investors',
                'special_requests' => 'Live streaming setup, branded decorations, demo stations',
                'menu_preferences' => 'Cocktail reception with canapés and finger foods',
                'status' => 'completed',
            ],

            // Current/Recent Events (Confirmed)
            [
                'event_name' => 'Golden Anniversary Celebration',
                'event_date' => $now->copy()->subDays(rand(1, 7))->format('Y-m-d'),
                'event_time' => '14:00',
                'guest_count' => '51-100',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Standard',
                'venue' => 'Community Center - Heritage Hall',
                'contact_phone' => '+1-555-0321',
                'additional_details' => '50th wedding anniversary celebration',
                'special_requests' => 'Photo slideshow, anniversary cake, family seating arrangement',
                'menu_preferences' => 'Traditional American cuisine with dessert bar',
                'status' => 'confirmed',
            ],
            [
                'event_name' => 'Medical Conference Dinner',
                'event_date' => $now->copy()->addDays(rand(1, 5))->format('Y-m-d'),
                'event_time' => '18:00',
                'guest_count' => '100+',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Premium',
                'venue' => 'Medical Center Conference Hall',
                'contact_phone' => '+1-555-0654',
                'additional_details' => 'Annual medical conference closing dinner',
                'special_requests' => 'Keynote speaker setup, professional networking area',
                'menu_preferences' => 'Formal dinner service with dietary restrictions accommodated',
                'status' => 'confirmed',
            ],

            // Upcoming Events (Confirmed)
            [
                'event_name' => 'University Graduation Party',
                'event_date' => $now->copy()->addDays(rand(7, 15))->format('Y-m-d'),
                'event_time' => '16:00',
                'guest_count' => '51-100',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Standard',
                'venue' => 'University Alumni Center',
                'contact_phone' => '+1-555-0987',
                'additional_details' => 'Graduation celebration for Class of 2025',
                'special_requests' => 'Photo booth, graduation cap decorations, music playlist',
                'menu_preferences' => 'Casual dining with pizza, salads, and celebration cake',
                'status' => 'confirmed',
            ],
            [
                'event_name' => 'Charity Fundraising Gala',
                'event_date' => $now->copy()->addDays(rand(15, 25))->format('Y-m-d'),
                'event_time' => '19:30',
                'guest_count' => '100+',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Premium',
                'venue' => 'Grand Hotel Ballroom',
                'contact_phone' => '+1-555-0147',
                'additional_details' => 'Annual charity gala with silent auction',
                'special_requests' => 'Auction display area, donation collection, VIP seating',
                'menu_preferences' => 'Elegant 3-course dinner with premium wine selection',
                'status' => 'confirmed',
            ],
            [
                'event_name' => 'Corporate Team Building Retreat',
                'event_date' => $now->copy()->addDays(rand(20, 30))->format('Y-m-d'),
                'event_time' => '12:00',
                'guest_count' => '26-50',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Standard',
                'venue' => 'Mountain View Resort',
                'contact_phone' => '+1-555-0258',
                'additional_details' => 'Full-day team building with outdoor activities',
                'special_requests' => 'Outdoor setup, team activity stations, portable equipment',
                'menu_preferences' => 'BBQ lunch with vegetarian options, snacks throughout day',
                'status' => 'confirmed',
            ],

            // Pending Events (Awaiting Confirmation)
            [
                'event_name' => 'Art Gallery Opening Night',
                'event_date' => $now->copy()->addDays(rand(30, 40))->format('Y-m-d'),
                'event_time' => '18:00',
                'guest_count' => '51-100',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Deluxe',
                'venue' => 'Modern Art Gallery, Downtown',
                'contact_phone' => '+1-555-0369',
                'additional_details' => 'Contemporary art exhibition opening with artist meet & greet',
                'special_requests' => 'Wine and cheese reception, art-friendly lighting, mingling space',
                'menu_preferences' => 'Sophisticated hors d\'oeuvres with wine and cocktail service',
                'status' => 'pending',
            ],
            [
                'event_name' => 'High School Reunion - Class of 2005',
                'event_date' => $now->copy()->addDays(rand(35, 50))->format('Y-m-d'),
                'event_time' => '19:00',
                'guest_count' => '100+',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Standard',
                'venue' => 'High School Gymnasium (Decorated)',
                'contact_phone' => '+1-555-0741',
                'additional_details' => '20-year high school reunion celebration',
                'special_requests' => 'Yearbook display, DJ with 2000s music, photo memories wall',
                'menu_preferences' => 'Nostalgic comfort food buffet with dessert station',
                'status' => 'pending',
            ],
            [
                'event_name' => 'Baby Shower Celebration',
                'event_date' => $now->copy()->addDays(rand(25, 35))->format('Y-m-d'),
                'event_time' => '14:30',
                'guest_count' => '26-50',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Standard',
                'venue' => 'Private Residence - Garden Patio',
                'contact_phone' => '+1-555-0852',
                'additional_details' => 'Elegant baby shower with garden theme',
                'special_requests' => 'Baby-themed decorations, gift table setup, games area',
                'menu_preferences' => 'Light lunch with sandwiches, salads, and baby shower cake',
                'status' => 'pending',
            ],
            [
                'event_name' => 'Business Conference Lunch',
                'event_date' => $now->copy()->addDays(rand(45, 60))->format('Y-m-d'),
                'event_time' => '12:30',
                'guest_count' => '51-100',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Deluxe',
                'venue' => 'Business Center Conference Room',
                'contact_phone' => '+1-555-0963',
                'additional_details' => 'Quarterly business conference networking lunch',
                'special_requests' => 'Professional presentation setup, networking tables, name tags',
                'menu_preferences' => 'Business lunch with multiple dietary options',
                'status' => 'pending',
            ],

            // Future Events (Various Statuses)
            [
                'event_name' => 'Summer Music Festival After-Party',
                'event_date' => $now->copy()->addDays(rand(55, 70))->format('Y-m-d'),
                'event_time' => '21:00',
                'guest_count' => '100+',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Premium',
                'venue' => 'Outdoor Amphitheater',
                'contact_phone' => '+1-555-0174',
                'additional_details' => 'Late-night after-party for summer music festival',
                'special_requests' => 'Late-night service, outdoor lighting, sound system coordination',
                'menu_preferences' => 'Late-night snacks, food trucks coordination, beverage service',
                'status' => 'confirmed',
            ],
            [
                'event_name' => 'Holiday Office Party',
                'event_date' => $now->copy()->addDays(rand(70, 90))->format('Y-m-d'),
                'event_time' => '17:30',
                'guest_count' => '51-100',
                'event_type' => $getRandomEventType(),
                'package_type' => 'Deluxe',
                'venue' => 'Office Building - Main Conference Hall',
                'contact_phone' => '+1-555-0285',
                'additional_details' => 'Annual holiday celebration for employees and families',
                'special_requests' => 'Holiday decorations, gift exchange area, family-friendly setup',
                'menu_preferences' => 'Holiday-themed menu with traditional dishes and desserts',
                'status' => 'pending',
            ]
        ];

        // Create bookings and assign to random users
        foreach ($bookings as $index => $bookingData) {
            $user = $users->random();
            
            // Let Laravel handle created_at and updated_at automatically
            Booking::updateOrCreate(
                [
                    'event_name' => $bookingData['event_name'],
                    'event_date' => $bookingData['event_date']
                ],
                array_merge($bookingData, [
                    'user_id' => $user->id
                    // Removed any hardcoded timestamps - Laravel will handle automatically
                ])
            );
        }

        $this->command->info('✅ Created ' . count($bookings) . ' comprehensive bookings');
        $this->command->info('📊 Booking Status Distribution:');
        $this->command->info('   - Completed: ' . collect($bookings)->where('status', 'completed')->count());
        $this->command->info('   - Confirmed: ' . collect($bookings)->where('status', 'confirmed')->count());
        $this->command->info('   - Pending: ' . collect($bookings)->where('status', 'pending')->count());
        
        $this->command->info('');
        $this->command->info('🎯 Event Types Created:');
        $eventTypes = collect($bookings)->pluck('event_type')->unique()->sort();
        foreach ($eventTypes as $type) {
            $count = collect($bookings)->where('event_type', $type)->count();
            $this->command->info("   - {$type}: {$count} events");
        }
        
        $this->command->info('');
        $this->command->info('📊 Bookings created successfully!');
        $this->command->info('');
        $this->command->info('🎉 Booking seeder completed successfully!');
        $this->command->info('📱 Your mobile app will now display rich booking data.');
    }

    private function generateNameFromEmail($email)
    {
        $namePart = explode('@', $email)[0];
        $names = explode('.', $namePart);
        return ucfirst($names[0]) . ' ' . ucfirst($names[1] ?? 'Client');
    }
}
