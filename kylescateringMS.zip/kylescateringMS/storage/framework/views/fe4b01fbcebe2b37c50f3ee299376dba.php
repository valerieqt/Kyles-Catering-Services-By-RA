<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Kyle\'s Catering')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
        <!-- Background Design -->
        <div class="fixed inset-0 bg-gradient-to-br from-maroon-900 via-maroon-800 to-maroon-700">
            <!-- Decorative Pattern -->
            <div class="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.05"%3E%3Ccircle cx="30" cy="30" r="4"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20"></div>
        </div>

        <!-- Navigation -->
        <nav class="relative z-10 bg-white/95 backdrop-blur-md shadow-lg border-b border-maroon-200">
            <div class="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center h-14 sm:h-16">
                    <div class="flex items-center min-w-0 flex-1">
                        <a href="/" class="flex items-center group">
                            <div class="text-lg sm:text-2xl font-bold text-maroon-800 group-hover:text-maroon-900 transition duration-300 truncate">
                                Kyle's Catering
                            </div>
                        </a>
                    </div>
                    <div class="flex items-center ml-2">
                        <a href="/" class="text-gray-600 hover:text-maroon-700 px-2 py-2 sm:px-4 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all duration-200 hover:bg-maroon-50">
                            <svg class="w-3 h-3 sm:w-4 sm:h-4 inline mr-1 sm:mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                            </svg>
                            <span class="hidden sm:inline">Back to Home</span>
                            <span class="sm:hidden">Home</span>
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <div class="relative z-10 min-h-screen flex flex-col justify-center items-center py-4 px-3 sm:px-4">
            <!-- Brand Logo Section -->
            <div class="text-center mb-6 sm:mb-8">
                <div class="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 bg-white/90 backdrop-blur-md rounded-full shadow-2xl mb-3 sm:mb-4">
                    <svg class="w-6 h-6 sm:w-8 sm:h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                    </svg>
                </div>
                <h1 class="text-2xl sm:text-3xl font-bold text-white mb-1 sm:mb-2">Kyle's Catering</h1>
                <p class="text-maroon-200 text-sm sm:text-base">Exceptional catering for every occasion</p>
            </div>

            <!-- Auth Card -->
            <div class="w-full max-w-md sm:max-w-lg lg:max-w-2xl">
                <div class="bg-white/95 backdrop-blur-md shadow-2xl overflow-hidden rounded-xl sm:rounded-2xl border border-white/20 p-6 sm:p-10 lg:p-12">
                    <div class="text-center mb-6 sm:mb-8">
                        <h2 class="text-2xl sm:text-3xl font-bold text-maroon-800 mb-2 sm:mb-3">
                            <?php if(request()->routeIs('login')): ?>
                                Welcome Back
                            <?php elseif(request()->routeIs('register')): ?>
                                Create Account
                            <?php elseif(request()->routeIs('password.request')): ?>
                                Reset Password
                            <?php elseif(request()->routeIs('password.reset')): ?>
                                Reset Password
                            <?php else: ?>
                                Authentication
                            <?php endif; ?>
                        </h2>
                        <p class="text-gray-600 text-sm sm:text-base">
                            <?php if(request()->routeIs('login')): ?>
                                Sign in to your account to manage bookings
                            <?php elseif(request()->routeIs('register')): ?>
                                Join Kyle's Catering family today
                            <?php elseif(request()->routeIs('password.request')): ?>
                                Enter your email to reset your password
                            <?php elseif(request()->routeIs('password.reset')): ?>
                                Create your new password
                            <?php endif; ?>
                        </p>
                    </div>
                    <?php echo e($slot); ?>

                </div>
            </div>

            <!-- Footer -->
            <div class="mt-8 text-center">
                <p class="text-maroon-200 text-sm">
                    © <?php echo e(date('Y')); ?> Kyle's Catering. All rights reserved.
                </p>
            </div>
        </div>

        <!-- Toast Notifications for Auth Pages -->
        <div id="toast-container" class="fixed top-20 right-4 z-50 space-y-2"></div>
        
        <script>
            function showToast(message, type = 'success') {
                const toast = document.createElement('div');
                const bgColor = type === 'success' ? 'bg-green-500' : type === 'error' ? 'bg-red-500' : 'bg-blue-500';
                
                toast.className = `${bgColor} text-white px-6 py-4 rounded-lg shadow-lg transform transition-all duration-300 translate-x-full opacity-0 max-w-sm`;
                toast.innerHTML = `
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                ${type === 'success' ? 
                                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>' :
                                    type === 'error' ?
                                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>' :
                                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>'
                                }
                            </svg>
                            <span>${message}</span>
                        </div>
                        <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                `;
                
                document.getElementById('toast-container').appendChild(toast);
                
                setTimeout(() => {
                    toast.classList.remove('translate-x-full', 'opacity-0');
                    toast.classList.add('translate-x-0', 'opacity-100');
                }, 100);
                
                setTimeout(() => {
                    toast.classList.add('translate-x-full', 'opacity-0');
                    setTimeout(() => {
                        if (toast.parentElement) {
                            toast.parentElement.removeChild(toast);
                        }
                    }, 300);
                }, 5000);
            }
        </script>
    </body>
</html>
<?php /**PATH C:\Users\melemmel2\Downloads\kylesCateringMSlatest2\kylesCateringMS\kylescateringMS\resources\views/layouts/guest.blade.php ENDPATH**/ ?>