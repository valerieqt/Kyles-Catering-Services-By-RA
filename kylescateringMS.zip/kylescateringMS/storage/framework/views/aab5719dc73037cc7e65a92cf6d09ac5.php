<nav x-data="{ open: false }" class="bg-white shadow-lg sticky top-0 z-50" id="main-navigation">
    <!-- Primary Navigation Menu -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex items-center flex-1 min-w-0">
                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="/" class="flex items-center">
                        <div class="text-lg sm:text-2xl font-bold text-maroon-800 truncate">
                            Kyle's Catering
                        </div>
                    </a>
                </div>

                <!-- Navigation Links -->
                <div class="hidden md:flex space-x-4 lg:space-x-8 sm:-my-px sm:ms-10">
                    <a href="/#home" class="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium leading-5 text-gray-500 hover:text-maroon-700 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:border-maroon-300 transition duration-150 ease-in-out">
                        Home
                    </a>
                    <a href="/#services" class="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium leading-5 text-gray-500 hover:text-maroon-700 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:border-maroon-300 transition duration-150 ease-in-out">
                        Services
                    </a>
                    <a href="/#packages" class="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium leading-5 text-gray-500 hover:text-maroon-700 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:border-maroon-300 transition duration-150 ease-in-out">
                        Packages
                    </a>
                    <a href="/#gallery" class="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium leading-5 text-gray-500 hover:text-maroon-700 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:border-maroon-300 transition duration-150 ease-in-out">
                        Gallery
                    </a>
                    <a href="/#book-now" class="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium leading-5 text-gray-500 hover:text-maroon-700 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:border-maroon-300 transition duration-150 ease-in-out">
                        Book Now
                    </a>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('bookings.index')); ?>" class="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium leading-5 text-gray-500 hover:text-maroon-700 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:border-maroon-300 transition duration-150 ease-in-out">
                            My Bookings
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Account/Auth Section -->
            <div class="hidden md:flex md:items-center md:ms-6">
                <?php if(auth()->guard()->check()): ?>
                    <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                         <?php $__env->slot('trigger', null, []); ?> 
                            <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-maroon-700 focus:outline-none transition ease-in-out duration-150">
                                <div><?php echo e(Auth::user()->name); ?></div>
                                <div class="ms-1">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </button>
                         <?php $__env->endSlot(); ?>

                         <?php $__env->slot('content', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
                            Profile
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                Log Out
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                        </form>
                         <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
                <?php else: ?>
                    <div class="space-x-4">
                        <a href="<?php echo e(route('login')); ?>" class="text-gray-500 hover:text-maroon-700 px-3 py-2 rounded-md text-sm font-medium transition duration-150 ease-in-out">
                            Login
                        </a>
                        <a href="<?php echo e(route('register')); ?>" class="bg-maroon-600 hover:bg-maroon-700 text-white px-4 py-2 rounded-md text-sm font-medium transition duration-150 ease-in-out">
                            Register
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Hamburger -->
            <div class="-me-2 flex items-center md:hidden">
                <button @click="open = ! open" onclick="toggleMobileMenu()" class="inline-flex items-center justify-center p-3 rounded-md text-gray-400 hover:text-maroon-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-maroon-500 transition duration-150 ease-in-out touch-manipulation" aria-label="Toggle navigation menu" id="mobile-menu-button">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex hamburger-open" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden hamburger-close" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Responsive Navigation Menu -->
    <div :class="{'block': open, 'hidden': ! open}" class="hidden md:hidden bg-white border-t border-gray-200" id="mobile-menu">
        <div class="pt-2 pb-3 space-y-1">
            <a href="/#home" @click="open = false" onclick="closeMobileMenu()" class="block pl-4 pr-4 py-3 border-l-4 border-transparent text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 focus:border-maroon-300 transition duration-150 ease-in-out touch-manipulation">
                Home
            </a>
            <a href="/#services" @click="open = false" onclick="closeMobileMenu()" class="block pl-4 pr-4 py-3 border-l-4 border-transparent text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 focus:border-maroon-300 transition duration-150 ease-in-out touch-manipulation">
                Services
            </a>
            <a href="/#packages" @click="open = false" onclick="closeMobileMenu()" class="block pl-4 pr-4 py-3 border-l-4 border-transparent text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 focus:border-maroon-300 transition duration-150 ease-in-out touch-manipulation">
                Packages
            </a>
            <a href="/#gallery" @click="open = false" onclick="closeMobileMenu()" class="block pl-4 pr-4 py-3 border-l-4 border-transparent text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 focus:border-maroon-300 transition duration-150 ease-in-out touch-manipulation">
                Gallery
            </a>
            <button @click="open = false; document.getElementById('chatbot-toggle').click()" onclick="closeMobileMenu()" class="block w-full text-left pl-4 pr-4 py-3 border-l-4 border-transparent text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 focus:border-maroon-300 transition duration-150 ease-in-out touch-manipulation">
                FAQ
            </button>
            <a href="/#book-now" @click="open = false" onclick="closeMobileMenu()" class="block pl-4 pr-4 py-3 border-l-4 border-transparent text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 focus:border-maroon-300 transition duration-150 ease-in-out touch-manipulation">
                Book Now
            </a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('bookings.index')); ?>" @click="open = false" onclick="closeMobileMenu()" class="block pl-4 pr-4 py-3 border-l-4 border-transparent text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 hover:border-maroon-300 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 focus:border-maroon-300 transition duration-150 ease-in-out touch-manipulation">
                    My Bookings
                </a>
            <?php endif; ?>
        </div>

        <!-- Responsive Auth Options -->
        <div class="pt-4 pb-1 border-t border-gray-200">
            <?php if(auth()->guard()->check()): ?>
                <div class="px-4">
                    <div class="font-medium text-base text-gray-800"><?php echo e(Auth::user()->name); ?></div>
                    <div class="font-medium text-sm text-gray-500"><?php echo e(Auth::user()->email); ?></div>
                </div>
                <div class="mt-3 space-y-1">
                    <a href="<?php echo e(route('profile.edit')); ?>" @click="open = false" onclick="closeMobileMenu()" class="block px-4 py-3 text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 transition duration-150 ease-in-out touch-manipulation">
                        Profile
                    </a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();" class="block px-4 py-3 text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 transition duration-150 ease-in-out touch-manipulation">
                            Log Out
                        </a>
                    </form>
                </div>
            <?php else: ?>
                <div class="px-4 space-y-2">
                    <a href="<?php echo e(route('login')); ?>" @click="open = false" onclick="closeMobileMenu()" class="block px-4 py-3 text-base font-medium text-gray-500 hover:text-maroon-700 hover:bg-gray-50 focus:outline-none focus:text-maroon-700 focus:bg-gray-50 transition duration-150 ease-in-out rounded-md touch-manipulation">
                        Login
                    </a>
                    <a href="<?php echo e(route('register')); ?>" @click="open = false" onclick="closeMobileMenu()" class="block px-4 py-3 text-base font-medium text-center text-white bg-maroon-600 hover:bg-maroon-700 focus:outline-none focus:bg-maroon-700 transition duration-150 ease-in-out rounded-md touch-manipulation">
                        Register
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Mobile Menu JavaScript (works with or without Alpine.js) -->
<script>
    let mobileMenuOpen = false;
    
    function toggleMobileMenu() {
        const mobileMenu = document.getElementById('mobile-menu');
        const hamburgerOpen = document.querySelector('.hamburger-open');
        const hamburgerClose = document.querySelector('.hamburger-close');
        
        if (mobileMenu) {
            mobileMenuOpen = !mobileMenuOpen;
            
            if (mobileMenuOpen) {
                mobileMenu.classList.remove('hidden');
                mobileMenu.classList.add('block');
                if (hamburgerOpen) {
                    hamburgerOpen.classList.add('hidden');
                    hamburgerOpen.classList.remove('inline-flex');
                }
                if (hamburgerClose) {
                    hamburgerClose.classList.remove('hidden');
                    hamburgerClose.classList.add('inline-flex');
                }
            } else {
                mobileMenu.classList.add('hidden');
                mobileMenu.classList.remove('block');
                if (hamburgerOpen) {
                    hamburgerOpen.classList.remove('hidden');
                    hamburgerOpen.classList.add('inline-flex');
                }
                if (hamburgerClose) {
                    hamburgerClose.classList.add('hidden');
                    hamburgerClose.classList.remove('inline-flex');
                }
            }
        }
    }
    
    function closeMobileMenu() {
        const mobileMenu = document.getElementById('mobile-menu');
        const hamburgerOpen = document.querySelector('.hamburger-open');
        const hamburgerClose = document.querySelector('.hamburger-close');
        
        if (mobileMenu && mobileMenuOpen) {
            mobileMenuOpen = false;
            mobileMenu.classList.add('hidden');
            mobileMenu.classList.remove('block');
            if (hamburgerOpen) {
                hamburgerOpen.classList.remove('hidden');
                hamburgerOpen.classList.add('inline-flex');
            }
            if (hamburgerClose) {
                hamburgerClose.classList.add('hidden');
                hamburgerClose.classList.remove('inline-flex');
            }
        }
    }
    
    // Initialize when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        // Add click listeners to all mobile nav links to close menu
        const mobileNavLinks = document.querySelectorAll('#mobile-menu a');
        mobileNavLinks.forEach(link => {
            link.addEventListener('click', closeMobileMenu);
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(event) {
            const nav = document.getElementById('main-navigation');
            const mobileMenu = document.getElementById('mobile-menu');
            
            if (mobileMenuOpen && nav && !nav.contains(event.target)) {
                closeMobileMenu();
            }
        });
        
        // Close menu on escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && mobileMenuOpen) {
                closeMobileMenu();
            }
        });
    });
</script>
<?php /**PATH C:\Users\melemmel2\Downloads\kylesCateringMS\kylescateringMS\resources\views/components/landing-nav.blade.php ENDPATH**/ ?>