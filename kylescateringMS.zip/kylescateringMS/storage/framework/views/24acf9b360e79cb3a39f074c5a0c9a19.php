<?php if (isset($component)) { $__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('landing-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Hero Section -->
    <section id="home" class="relative bg-gradient-to-r from-maroon-900 via-maroon-800 to-maroon-700 text-white min-h-screen flex items-center">
        <!-- Background Image -->
        <div class="absolute inset-0 bg-cover bg-center bg-no-repeat" style="background-image: url('<?php echo e(asset('images/Galleries/landingpage.jpg')); ?>');"></div>
        <div class="absolute inset-0 bg-black opacity-50"></div>
        <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32">
            <div class="text-center">
                <h1 class="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                    Exceptional Catering
                    <span class="block text-maroon-200">for Every Occasion</span>
                </h1>
                <p class="text-lg sm:text-xl md:text-2xl mb-8 text-maroon-100 max-w-3xl mx-auto leading-relaxed px-4 sm:px-0">
                    From intimate gatherings to grand celebrations, we create memorable experiences
                    through exceptional food and impeccable service.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center px-4 sm:px-0">
                    <a href="#book-now" class="bg-white text-maroon-800 px-6 sm:px-8 py-4 text-base sm:text-lg rounded-lg font-semibold hover:bg-maroon-50 transition duration-300 transform hover:scale-105 touch-manipulation text-center">
                        Book Now
                    </a>
                    <a href="#services" class="border-2 border-white text-white px-6 sm:px-8 py-4 text-base sm:text-lg rounded-lg font-semibold hover:bg-white hover:text-maroon-800 transition duration-300 touch-manipulation text-center">
                        Our Services
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="py-12 sm:py-16 lg:py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 sm:mb-16">
                <h2 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
                <p class="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-4 sm:px-0">
                    We offer comprehensive catering and styling services to make your event perfect
                </p>
            </div>
            
            <!-- Styling Services -->
            <div class="mb-12">
                <h3 class="text-xl sm:text-2xl font-bold text-gray-900 mb-8 text-center">Styling Services</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-lg hover:shadow-xl transition duration-300 border border-gray-100 touch-manipulation">
                        <div class="w-12 h-12 sm:w-16 sm:h-16 bg-maroon-100 rounded-full flex items-center justify-center mb-4 sm:mb-6 mx-auto sm:mx-0">
                            <svg class="w-6 h-6 sm:w-8 sm:h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
                            </svg>
                        </div>
                        <h4 class="text-lg sm:text-xl font-semibold text-gray-900 mb-3 sm:mb-4 text-center sm:text-left">Event Stylist</h4>
                        <p class="text-gray-600 text-sm sm:text-base text-center sm:text-left leading-relaxed">Complete event styling and decoration to transform your venue into a stunning celebration space.</p>
                    </div>
                    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-lg hover:shadow-xl transition duration-300 border border-gray-100 touch-manipulation">
                        <div class="w-12 h-12 sm:w-16 sm:h-16 bg-maroon-100 rounded-full flex items-center justify-center mb-4 sm:mb-6 mx-auto sm:mx-0">
                            <svg class="w-6 h-6 sm:w-8 sm:h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                            </svg>
                        </div>
                        <h4 class="text-lg sm:text-xl font-semibold text-gray-900 mb-3 sm:mb-4 text-center sm:text-left">Wedding Ceremony Stylist</h4>
                        <p class="text-gray-600 text-sm sm:text-base text-center sm:text-left leading-relaxed">Romantic and elegant wedding ceremony styling to create your dream wedding atmosphere.</p>
                    </div>
                    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-lg hover:shadow-xl transition duration-300 border border-gray-100 touch-manipulation">
                        <div class="w-12 h-12 sm:w-16 sm:h-16 bg-maroon-100 rounded-full flex items-center justify-center mb-4 sm:mb-6 mx-auto sm:mx-0">
                            <svg class="w-6 h-6 sm:w-8 sm:h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                            </svg>
                        </div>
                        <h4 class="text-lg sm:text-xl font-semibold text-gray-900 mb-3 sm:mb-4 text-center sm:text-left">Ceiling Treatment Stylist</h4>
                        <p class="text-gray-600 text-sm sm:text-base text-center sm:text-left leading-relaxed">Beautiful ceiling decorations and treatments to add elegance and grandeur to your event.</p>
                    </div>
                </div>
            </div>

            <!-- Catering Services -->
            <div>
                <h3 class="text-xl sm:text-2xl font-bold text-gray-900 mb-8 text-center">We Cater</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-lg hover:shadow-xl transition duration-300 border border-gray-100 touch-manipulation">
                        <div class="w-12 h-12 sm:w-16 sm:h-16 bg-maroon-100 rounded-full flex items-center justify-center mb-4 sm:mb-6 mx-auto sm:mx-0">
                            <svg class="w-6 h-6 sm:w-8 sm:h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                            </svg>
                        </div>
                        <h4 class="text-lg sm:text-xl font-semibold text-gray-900 mb-3 sm:mb-4 text-center sm:text-left">Weddings</h4>
                        <p class="text-gray-600 text-sm sm:text-base text-center sm:text-left leading-relaxed">Elegant wedding catering with romantic menus designed to make your special day unforgettable.</p>
                    </div>
                    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-lg hover:shadow-xl transition duration-300 border border-gray-100 touch-manipulation">
                        <div class="w-12 h-12 sm:w-16 sm:h-16 bg-maroon-100 rounded-full flex items-center justify-center mb-4 sm:mb-6 mx-auto sm:mx-0">
                            <svg class="w-6 h-6 sm:w-8 sm:h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </div>
                        <h4 class="text-lg sm:text-xl font-semibold text-gray-900 mb-3 sm:mb-4 text-center sm:text-left">Debut</h4>
                        <p class="text-gray-600 text-sm sm:text-base text-center sm:text-left leading-relaxed">Sophisticated debut catering services to celebrate this important milestone in style.</p>
                    </div>
                    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-lg hover:shadow-xl transition duration-300 border border-gray-100 touch-manipulation">
                        <div class="w-12 h-12 sm:w-16 sm:h-16 bg-maroon-100 rounded-full flex items-center justify-center mb-4 sm:mb-6 mx-auto sm:mx-0">
                            <svg class="w-6 h-6 sm:w-8 sm:h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h8m-5-10V3a1 1 0 011-1h1a1 1 0 011 1v1M5 7a2 2 0 012-2h10a2 2 0 012 2v11a2 2 0 01-2 2H7a2 2 0 01-2-2V7z"/>
                            </svg>
                        </div>
                        <h4 class="text-lg sm:text-xl font-semibold text-gray-900 mb-3 sm:mb-4 text-center sm:text-left">Kids Party</h4>
                        <p class="text-gray-600 text-sm sm:text-base text-center sm:text-left leading-relaxed">Fun and colorful catering for children's parties with kid-friendly menus and decorations.</p>
                    </div>
                    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-lg hover:shadow-xl transition duration-300 border border-gray-100 touch-manipulation">
                        <div class="w-12 h-12 sm:w-16 sm:h-16 bg-maroon-100 rounded-full flex items-center justify-center mb-4 sm:mb-6 mx-auto sm:mx-0">
                            <svg class="w-6 h-6 sm:w-8 sm:h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                            </svg>
                        </div>
                        <h4 class="text-lg sm:text-xl font-semibold text-gray-900 mb-3 sm:mb-4 text-center sm:text-left">Corporate Events</h4>
                        <p class="text-gray-600 text-sm sm:text-base text-center sm:text-left leading-relaxed">Professional catering for business meetings, conferences, and corporate celebrations.</p>
                    </div>
                    <div class="bg-white p-6 sm:p-8 rounded-lg shadow-lg hover:shadow-xl transition duration-300 border border-gray-100 touch-manipulation">
                        <div class="w-12 h-12 sm:w-16 sm:h-16 bg-maroon-100 rounded-full flex items-center justify-center mb-4 sm:mb-6 mx-auto sm:mx-0">
                            <svg class="w-6 h-6 sm:w-8 sm:h-8 text-maroon-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/>
                            </svg>
                        </div>
                        <h4 class="text-lg sm:text-xl font-semibold text-gray-900 mb-3 sm:mb-4 text-center sm:text-left">Intimate Gatherings</h4>
                        <p class="text-gray-600 text-sm sm:text-base text-center sm:text-left leading-relaxed">Personalized catering for small, intimate celebrations and family gatherings.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Packages Section -->
    <section id="packages" class="py-12 sm:py-16 lg:py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 sm:mb-16">
                <h2 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Event Packages</h2>
                <p class="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-4 sm:px-0">
                    Comprehensive packages designed for weddings, birthdays, and special celebrations
                </p>
            </div>
            <div class="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6 lg:gap-8">
                <!-- All-in-one Wedding Package -->
                <div class="bg-white rounded-lg shadow-lg overflow-hidden border-2 border-maroon-600 relative">
                    <div class="absolute top-0 right-0 bg-maroon-600 text-white px-3 sm:px-4 py-1 text-xs sm:text-sm font-semibold">
                        Premium
                    </div>
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-900 mb-2">All-in-one Wedding Package</h3>
                        <p class="text-gray-600 mb-4">Complete wedding solution with styling, catering, and coordination</p>
                        
                        <!-- Collapsed View -->
                        <div id="wedding-premium-collapsed" class="mb-4">
                            <div class="text-sm text-gray-600 mb-3">Includes professional host, bridal car, 3-tier cake, HMUA, complete venue styling, and more...</div>
                        </div>
                        
                        <!-- Expanded View -->
                        <div id="wedding-premium-expanded" class="hidden mb-4">
                            <div class="space-y-3 text-sm">
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Professional Services:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Professional Host & Photobooth</li>
                                        <li>• Bridal Car & 3-Tier Cake</li>
                                        <li>• HMUA & Photo/Video Coverage</li>
                                        <li>• Lights & Sounds System</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Venue & Styling:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Complete Venue Styling</li>
                                        <li>• Ceremonial Setup & Entrance Flowers</li>
                                        <li>• Bridal Bouquet & Car Bouquet</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Catering & Food:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Full Catering Service</li>
                                        <li>• Coffee & Milktea Cart</li>
                                        <li>• Grazing Table</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <button type="button" onclick="togglePackageDetails('wedding-premium')" class="w-full bg-gray-100 text-gray-700 py-2 px-3 text-sm rounded-lg font-medium hover:bg-gray-200 transition duration-300">
                            <span id="wedding-premium-toggle-text">View Details</span>
                        </button>
                    </div>
                </div>

                <!-- Wedding Package -->
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-900 mb-2">Wedding Package</h3>
                        <p class="text-gray-600 mb-4">Essential wedding catering and coordination services</p>
                        
                        <!-- Collapsed View -->
                        <div id="wedding-basic-collapsed" class="mb-4">
                            <div class="text-sm text-gray-600 mb-3">Includes 4 main courses, venue styling, event coordination, professional host, and more...</div>
                        </div>
                        
                        <!-- Expanded View -->
                        <div id="wedding-basic-expanded" class="hidden mb-4">
                            <div class="space-y-3 text-sm">
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Food & Catering:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• 4 Main Course Options</li>
                                        <li>• Complete Catering Setup</li>
                                        <li>• 2-Layer Wedding Cake</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Venue & Coordination:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Complete Venue Styling</li>
                                        <li>• Event Coordination</li>
                                        <li>• Welcome Arch</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Services:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Lights & Sound System</li>
                                        <li>• Professional Host</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <button type="button" onclick="togglePackageDetails('wedding-basic')" class="w-full bg-gray-100 text-gray-700 py-2 px-3 text-sm rounded-lg font-medium hover:bg-gray-200 transition duration-300">
                            <span id="wedding-basic-toggle-text">View Details</span>
                        </button>
                    </div>
                </div>

                <!-- Catering & Styling Package -->
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-900 mb-2">Catering & Styling Package</h3>
                        <p class="text-gray-600 mb-4">Flexible catering with basic styling options</p>
                        
                        <!-- Collapsed View -->
                        <div id="catering-styling-collapsed" class="mb-4">
                            <div class="text-sm text-gray-600 mb-3">Three tiers available with styling, centerpieces, professional staff, complete dinnerware, and more...</div>
                        </div>
                        
                        <!-- Expanded View -->
                        <div id="catering-styling-expanded" class="hidden mb-4">
                            <div class="space-y-3 text-sm">
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Styling & Setup:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Basic Styling & Backdrop</li>
                                        <li>• Centerpieces & Table Setup</li>
                                        <li>• Venue Entrance Design</li>
                                        <li>• Buffet Setup & Tables</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Service & Equipment:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Professional Staff</li>
                                        <li>• Complete Dinnerware</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Food Options:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Rice, Pasta & Main Entrees</li>
                                        <li>• Dessert & Drinks</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <button type="button" onclick="togglePackageDetails('catering-styling')" class="w-full bg-gray-100 text-gray-700 py-2 px-3 text-sm rounded-lg font-medium hover:bg-gray-200 transition duration-300">
                            <span id="catering-styling-toggle-text">View Details</span>
                        </button>
                    </div>
                </div>

                <!-- All-in-one Birthday Package -->
                <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-900 mb-2">All-in-one Birthday Package</h3>
                        <p class="text-gray-600 mb-4">Complete birthday celebration package</p>
                        
                        <!-- Collapsed View -->
                        <div id="birthday-collapsed" class="mb-4">
                            <div class="text-sm text-gray-600 mb-3">Includes venue styling, entertainment, 2-tier cake, photo/video, tent setup, plus freebies...</div>
                        </div>
                        
                        <!-- Expanded View -->
                        <div id="birthday-expanded" class="hidden mb-4">
                            <div class="space-y-3 text-sm">
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Venue & Setup:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Venue Styling & Backdrop</li>
                                        <li>• Complete Table Setup</li>
                                        <li>• 40x60 Tent with Ceiling Decor</li>
                                        <li>• Complete Dinnerware Set</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Entertainment & Services:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• Professional Host</li>
                                        <li>• Clown/Magician Entertainment</li>
                                        <li>• Photo & Video Coverage</li>
                                        <li>• HMUA & Coffee Bar</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Food & Cake:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• 2-Tier Birthday Cake</li>
                                        <li>• Grazing Table & Food Carts</li>
                                        <li>• Professional Staff</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-maroon-600 mb-2">Freebies:</h4>
                                    <ul class="space-y-1 text-gray-600 text-xs">
                                        <li>• 20pcs Lootbags</li>
                                        <li>• Pinata Gift for Celebrator</li>
                                        <li>• 10 Uniformed Staff</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <button type="button" onclick="togglePackageDetails('birthday')" class="w-full bg-gray-100 text-gray-700 py-2 px-3 text-sm rounded-lg font-medium hover:bg-gray-200 transition duration-300">
                            <span id="birthday-toggle-text">View Details</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section id="gallery" class="py-12 sm:py-16 lg:py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 sm:mb-16">
                <h2 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Gallery</h2>
                <p class="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-4 sm:px-0">
                    Browse through our portfolio of memorable events and delicious creations
                </p>
            </div>
            
            <!-- Category Filter Buttons -->
            <div class="flex flex-wrap justify-center gap-3 mb-8">
                <button onclick="filterGallery('all')" class="gallery-filter-btn active px-4 py-2 rounded-full text-sm font-medium transition duration-300 bg-maroon-600 text-white">
                    All
                </button>
                <button onclick="filterGallery('wedding')" class="gallery-filter-btn px-4 py-2 rounded-full text-sm font-medium transition duration-300 bg-gray-200 text-gray-700 hover:bg-maroon-100">
                    Weddings
                </button>
                <button onclick="filterGallery('birthday')" class="gallery-filter-btn px-4 py-2 rounded-full text-sm font-medium transition duration-300 bg-gray-200 text-gray-700 hover:bg-maroon-100">
                    Birthdays
                </button>
                <button onclick="filterGallery('party')" class="gallery-filter-btn px-4 py-2 rounded-full text-sm font-medium transition duration-300 bg-gray-200 text-gray-700 hover:bg-maroon-100">
                    Parties
                </button>
                <button onclick="filterGallery('food')" class="gallery-filter-btn px-4 py-2 rounded-full text-sm font-medium transition duration-300 bg-gray-200 text-gray-700 hover:bg-maroon-100">
                    Foods
                </button>
            </div>

            <!-- Gallery Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6" id="gallery-grid">
                <!-- Wedding Images -->
                <div class="gallery-item wedding relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Wedding/520309515_1149516917201239_8528927235972369172_n.jpg')); ?>" alt="Wedding Event" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Wedding Celebration</span>
                    </div>
                </div>
                
                <div class="gallery-item wedding relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Wedding/502691062_1106954544790810_2065628122630376607_n.jpg')); ?>" alt="Wedding Setup" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Wedding Setup</span>
                    </div>
                </div>
                
                <div class="gallery-item wedding relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Wedding/540914621_1183175260502071_4694632473244845351_n.jpg')); ?>" alt="Wedding Decor" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Wedding Decor</span>
                    </div>
                </div>
                
                <div class="gallery-item wedding relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Wedding/546569649_1189810933171837_8584359535135791285_n.jpg')); ?>" alt="Wedding Reception" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Wedding Reception</span>
                    </div>
                </div>

                <div class="gallery-item wedding relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Wedding/484170829_1044339247719007_8642569477044368184_n.jpg')); ?>" alt="Wedding Ceremony" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Wedding Ceremony</span>
                    </div>
                </div>

                <div class="gallery-item wedding relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Wedding/509356839_1122349953251269_2884798544593737447_n.jpg')); ?>" alt="Wedding Styling" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Wedding Styling</span>
                    </div>
                </div>

                <div class="gallery-item wedding relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Wedding/545431520_1189811009838496_4495481723909432048_n.jpg')); ?>" alt="Wedding Venue" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Wedding Venue</span>
                    </div>
                </div>

                <!-- Birthday Images -->
                <div class="gallery-item birthday relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Birthdays/483101928_1047539680732297_118993450942313008_n.jpg')); ?>" alt="Birthday Party" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Birthday Celebration</span>
                    </div>
                </div>
                
                <div class="gallery-item birthday relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Birthdays/484348632_1047165137436418_7066968718152542835_n.jpg')); ?>" alt="Birthday Setup" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Birthday Setup</span>
                    </div>
                </div>
                
                <div class="gallery-item birthday relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Birthdays/495037114_1088453976640867_6595336604771982926_n.jpg')); ?>" alt="Birthday Decor" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Birthday Decor</span>
                    </div>
                </div>
                
                <div class="gallery-item birthday relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Birthdays/530851079_1165863378899926_3236040264525254025_n.jpg')); ?>" alt="Birthday Theme" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Birthday Theme</span>
                    </div>
                </div>

                <div class="gallery-item birthday relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Birthdays/482356226_1042622594557339_4255673405112057817_n.jpg')); ?>" alt="Birthday Styling" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Birthday Styling</span>
                    </div>
                </div>

                <div class="gallery-item birthday relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Birthdays/495570374_1088454413307490_8788075031721497699_n.jpg')); ?>" alt="Birthday Decor" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Birthday Decor</span>
                    </div>
                </div>

                <!-- Party Images -->
                <div class="gallery-item party relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Party/482979927_1044329197720012_7769091742015362373_n.jpg')); ?>" alt="Party Event" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Party Event</span>
                    </div>
                </div>
                
                <div class="gallery-item party relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Party/482985623_1044329007720031_4430882306637652221_n.jpg')); ?>" alt="Party Setup" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Party Setup</span>
                    </div>
                </div>
                
                <div class="gallery-item party relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/Party/483769414_1044328787720053_267122493252909918_n.jpg')); ?>" alt="Party Celebration" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Party Celebration</span>
                    </div>
                </div>

                <!-- Food Images -->
                <div class="gallery-item food relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/FOods/482024771_1038671914952407_2075900634142223181_n.jpg')); ?>" alt="Gourmet Food" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Gourmet Dishes</span>
                    </div>
                </div>
                
                <div class="gallery-item food relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/FOods/482219947_1044917787661153_4123856084069123559_n.jpg')); ?>" alt="Food Presentation" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Food Presentation</span>
                    </div>
                </div>
                
                <div class="gallery-item food relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/FOods/485385033_1051212727031659_5663017265214819354_n.jpg')); ?>" alt="Catering Spread" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Catering Spread</span>
                    </div>
                </div>
                
                <div class="gallery-item food relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/FOods/481548809_1032115788941353_642673914851319903_n.jpg')); ?>" alt="Delicious Meals" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Delicious Meals</span>
                    </div>
                </div>

                <div class="gallery-item food relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/FOods/482238655_1044917777661154_8295758225436700083_n.jpg')); ?>" alt="Food Buffet" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Food Buffet</span>
                    </div>
                </div>

                <div class="gallery-item food relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/FOods/481237782_1033976918755240_4602024003574248937_n.jpg')); ?>" alt="Catering Display" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Catering Display</span>
                    </div>
                </div>

                <div class="gallery-item food relative group overflow-hidden rounded-lg shadow-lg touch-manipulation">
                    <img src="<?php echo e(asset('images/Galleries/FOods/480789918_1046668540819411_6125196698080334154_n.jpg')); ?>" alt="Food Plating" class="w-full h-48 sm:h-56 lg:h-64 object-cover group-hover:scale-105 transition duration-300">
                    <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition duration-300 flex items-center justify-center">
                        <span class="text-white text-base sm:text-lg font-semibold px-2 text-center">Food Plating</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Book Now Section -->
    <section id="book-now" class="py-12 sm:py-16 lg:py-20 bg-maroon-800 text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 sm:mb-16">
                <h2 class="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4">Ready to Book Your Event?</h2>
                <p class="text-lg sm:text-xl text-maroon-200 max-w-3xl mx-auto px-4 sm:px-0">
                    Contact us today to discuss your catering needs and let us create an unforgettable experience for your special occasion.
                </p>
            </div>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start">
                <div>
                    <h3 class="text-xl sm:text-2xl font-semibold mb-6">Get a Quote</h3>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(session('success')): ?>
                            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('bookings.store')); ?>" class="space-y-4 sm:space-y-6">
                            <?php echo csrf_field(); ?>
                    <?php else: ?>
                        <div class="bg-maroon-100 border border-maroon-400 text-maroon-700 px-4 py-3 rounded mb-6 text-sm sm:text-base">
                            <div class="flex items-start">
                                <svg class="w-5 h-5 mr-2 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                                </svg>
                                <span class="font-medium">Please <a href="<?php echo e(route('login')); ?>" class="underline hover:text-maroon-800">login</a> or <a href="<?php echo e(route('register')); ?>" class="underline hover:text-maroon-800">register</a> to make a booking.</span>
                            </div>
                        </div>
                        <form class="space-y-4 sm:space-y-6 opacity-50 pointer-events-none">
                    <?php endif; ?>
                        <div>
                            <label class="block text-sm sm:text-base font-medium mb-2">Event Name</label>
                            <input type="text" name="event_name" value="<?php echo e(old('event_name')); ?>" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['event_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation" placeholder="Enter event name">
                            <?php $__errorArgs = ['event_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                            <div>
                                <label class="block text-sm sm:text-base font-medium mb-2">Event Time</label>
                                <input type="time" name="event_time" value="<?php echo e(old('event_time')); ?>" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['event_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation">
                                <?php $__errorArgs = ['event_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label class="block text-sm sm:text-base font-medium mb-2">Contact Phone</label>
                                <input type="tel" name="contact_phone" value="<?php echo e(old('contact_phone')); ?>" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation" placeholder="Enter contact phone" inputmode="tel">
                                <?php $__errorArgs = ['contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm sm:text-base font-medium mb-2">Venue</label>
                            <input type="text" name="venue" value="<?php echo e(old('venue')); ?>" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation" placeholder="Enter venue location">
                            <?php $__errorArgs = ['venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="block text-sm sm:text-base font-medium mb-2">Event Date</label>
                            <input type="date" name="event_date" value="<?php echo e(old('event_date')); ?>" min="<?php echo e(date('Y-m-d', strtotime('tomorrow'))); ?>" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['event_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation">
                            <?php $__errorArgs = ['event_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="block text-sm sm:text-base font-medium mb-2">Number of Guests</label>
                            <select name="guest_count" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['guest_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation">
                                <option value="">Select guest count</option>
                                <option value="1-25" <?php echo e(old('guest_count') == '1-25' ? 'selected' : ''); ?>>1-25</option>
                                <option value="26-50" <?php echo e(old('guest_count') == '26-50' ? 'selected' : ''); ?>>26-50</option>
                                <option value="51-100" <?php echo e(old('guest_count') == '51-100' ? 'selected' : ''); ?>>51-100</option>
                                <option value="100+" <?php echo e(old('guest_count') == '100+' ? 'selected' : ''); ?>>100+</option>
                            </select>
                            <?php $__errorArgs = ['guest_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="block text-sm sm:text-base font-medium mb-2">Event Type</label>
                            <select name="event_type" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['event_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation">
                                <option value="">Select event type</option>
                                <?php
                                    $eventTypes = \App\Models\EventType::active()->ordered()->get();
                                ?>
                                <?php $__currentLoopData = $eventTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($eventType->name); ?>" <?php echo e(old('event_type') == $eventType->name ? 'selected' : ''); ?>>
                                        <?php echo e($eventType->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['event_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="block text-sm sm:text-base font-medium mb-2">Additional Details</label>
                            <textarea name="additional_details" rows="3" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['additional_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation resize-y" placeholder="Tell us about your event..."><?php echo e(old('additional_details')); ?></textarea>
                            <?php $__errorArgs = ['additional_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="block text-sm sm:text-base font-medium mb-2">Special Requests</label>
                            <textarea name="special_requests" rows="2" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['special_requests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation resize-y" placeholder="Any special requests or requirements..."><?php echo e(old('special_requests')); ?></textarea>
                            <?php $__errorArgs = ['special_requests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="block text-sm sm:text-base font-medium mb-2">Menu Preferences</label>
                            <textarea name="menu_preferences" rows="2" class="w-full px-3 sm:px-4 py-3 sm:py-4 text-base rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-maroon-300 focus:outline-none <?php $__errorArgs = ['menu_preferences'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> touch-manipulation resize-y" placeholder="Dietary restrictions, preferred cuisine, etc..."><?php echo e(old('menu_preferences')); ?></textarea>
                            <?php $__errorArgs = ['menu_preferences'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <input type="hidden" name="package_type" id="package_type" value="<?php echo e(old('package_type')); ?>">
                        <div id="selected_package" class="hidden bg-maroon-100 border border-maroon-400 text-maroon-700 px-4 py-3 rounded mb-4">
                            <span class="font-medium">Selected Package: <span id="package_name"></span></span>
                        </div>
                        <button type="submit" class="w-full bg-white text-maroon-800 py-3 sm:py-4 text-base sm:text-lg rounded-lg font-semibold hover:bg-maroon-50 transition duration-300 touch-manipulation">
                            Request Quote
                        </button>
                    </form>
                </div>
                <div class="space-y-6 sm:space-y-8 mt-8 lg:mt-0">
                    <div class="bg-maroon-700 p-4 sm:p-6 rounded-lg">
                        <h4 class="text-lg sm:text-xl font-semibold mb-4">Why Choose Us?</h4>
                        <ul class="space-y-3">
                            <li class="flex items-start">
                                <svg class="w-5 h-5 text-maroon-200 mr-3 mt-1" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                </svg>
                                <span>From intimate gatherings to grand celebrations, our team delivers delicious menus, professional staff, and seamless event coordination.</span>
                            </li>
                            <li class="flex items-start">
                                <svg class="w-5 h-5 text-maroon-200 mr-3 mt-1" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                </svg>
                                <span>Curated packages for every budget</span>
                            </li>
                            <li class="flex items-start">
                                <svg class="w-5 h-5 text-maroon-200 mr-3 mt-1" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                </svg>
                                <span>Easy online booking and rescheduling</span>
                            </li>
                            <li class="flex items-start">
                                <svg class="w-5 h-5 text-maroon-200 mr-3 mt-1" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                </svg>
                                <span>Real-time updates on your event status</span>
                            </li>
                        </ul>
                    </div>
                    <div class="text-center">
                        <p class="text-maroon-200 mb-4 text-sm sm:text-base">Prefer to call us directly?</p>
                        <a href="tel:+09356337433" class="text-xl sm:text-2xl font-bold text-white hover:text-maroon-200 transition duration-300 touch-manipulation block">
                            09356337433
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        function selectPackage(packageName) {
            document.getElementById('package_type').value = packageName;
            document.getElementById('package_name').textContent = packageName;
            document.getElementById('selected_package').classList.remove('hidden');

            // Scroll to booking form
            document.getElementById('book-now').scrollIntoView({ behavior: 'smooth' });
        }

        function togglePackageDetails(packageId) {
            const collapsed = document.getElementById(packageId + '-collapsed');
            const expanded = document.getElementById(packageId + '-expanded');
            const toggleText = document.getElementById(packageId + '-toggle-text');
            
            if (expanded.classList.contains('hidden')) {
                // Show details
                collapsed.classList.add('hidden');
                expanded.classList.remove('hidden');
                toggleText.textContent = 'Hide Details';
            } else {
                // Hide details
                expanded.classList.add('hidden');
                collapsed.classList.remove('hidden');
                toggleText.textContent = 'View Details';
            }
        }

        function filterGallery(category) {
            const items = document.querySelectorAll('.gallery-item');
            const buttons = document.querySelectorAll('.gallery-filter-btn');
            
            // Update button states
            buttons.forEach(btn => {
                btn.classList.remove('active', 'bg-maroon-600', 'text-white');
                btn.classList.add('bg-gray-200', 'text-gray-700');
            });
            
            // Set active button
            event.target.classList.remove('bg-gray-200', 'text-gray-700');
            event.target.classList.add('active', 'bg-maroon-600', 'text-white');
            
            // Filter items
            items.forEach(item => {
                if (category === 'all' || item.classList.contains(category)) {
                    item.style.display = 'block';
                    // Add fade in animation
                    item.style.opacity = '0';
                    setTimeout(() => {
                        item.style.opacity = '1';
                    }, 100);
                } else {
                    item.style.display = 'none';
                }
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9)): ?>
<?php $attributes = $__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9; ?>
<?php unset($__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9)): ?>
<?php $component = $__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9; ?>
<?php unset($__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9); ?>
<?php endif; ?>
<?php /**PATH C:\Users\melemmel2\Downloads\kylesCateringMS\kylescateringMS\resources\views/welcome.blade.php ENDPATH**/ ?>