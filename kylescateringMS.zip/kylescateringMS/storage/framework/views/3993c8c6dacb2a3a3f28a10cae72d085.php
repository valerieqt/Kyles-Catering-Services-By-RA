<?php if (isset($component)) { $__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('landing-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Edit Booking Section -->
    <section class="py-12 sm:py-16 lg:py-20 bg-gray-50 min-h-screen">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-8">
                <h2 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Edit Booking</h2>
                <p class="text-lg text-gray-600">
                    Update your booking details for <?php echo e($booking->event_name); ?>

                </p>
            </div>

            <!-- Success/Error Messages -->
            <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white rounded-lg shadow-lg p-6 sm:p-8">
                <!-- Current Booking Info -->
                <div class="bg-blue-50 rounded-lg p-4 mb-6">
                    <h3 class="text-lg font-semibold text-blue-900 mb-2">Current Booking Details</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div><strong>Event:</strong> <?php echo e($booking->event_name); ?></div>
                        <div><strong>Date:</strong> <?php echo e($booking->event_date->format('F j, Y')); ?></div>
                        <div><strong>Time:</strong> <?php echo e($booking->event_time); ?></div>
                        <div><strong>Guests:</strong> <?php echo e($booking->guest_count); ?></div>
                        <div><strong>Status:</strong> 
                            <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo e($booking->status_badge); ?>">
                                <?php echo e(ucfirst($booking->status)); ?>

                            </span>
                        </div>
                    </div>
                </div>

                <!-- Edit Form -->
                <form method="POST" action="<?php echo e(route('bookings.update', $booking)); ?>" class="space-y-6">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Event Name -->
                        <div>
                            <label for="event_name" class="block text-sm font-medium text-gray-700 mb-2">Event Name *</label>
                            <input type="text" id="event_name" name="event_name" 
                                   value="<?php echo e(old('event_name', $booking->event_name)); ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                   required>
                            <?php $__errorArgs = ['event_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Event Type -->
                        <div>
                            <label for="event_type" class="block text-sm font-medium text-gray-700 mb-2">Event Type *</label>
                            <select id="event_type" name="event_type" 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                    required>
                                <option value="">Select Event Type</option>
                                <option value="Wedding" <?php echo e(old('event_type', $booking->event_type) == 'Wedding' ? 'selected' : ''); ?>>Wedding</option>
                                <option value="Birthday" <?php echo e(old('event_type', $booking->event_type) == 'Birthday' ? 'selected' : ''); ?>>Birthday</option>
                                <option value="Corporate" <?php echo e(old('event_type', $booking->event_type) == 'Corporate' ? 'selected' : ''); ?>>Corporate Event</option>
                                <option value="Anniversary" <?php echo e(old('event_type', $booking->event_type) == 'Anniversary' ? 'selected' : ''); ?>>Anniversary</option>
                                <option value="Graduation" <?php echo e(old('event_type', $booking->event_type) == 'Graduation' ? 'selected' : ''); ?>>Graduation</option>
                                <option value="Other" <?php echo e(old('event_type', $booking->event_type) == 'Other' ? 'selected' : ''); ?>>Other</option>
                            </select>
                            <?php $__errorArgs = ['event_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Event Date -->
                        <div>
                            <label for="event_date" class="block text-sm font-medium text-gray-700 mb-2">Event Date *</label>
                            <input type="date" id="event_date" name="event_date" 
                                   value="<?php echo e(old('event_date', $booking->event_date->format('Y-m-d'))); ?>"
                                   min="<?php echo e(date('Y-m-d', strtotime('+1 day'))); ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                   required>
                            <?php $__errorArgs = ['event_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Event Time -->
                        <div>
                            <label for="event_time" class="block text-sm font-medium text-gray-700 mb-2">Event Time *</label>
                            <input type="time" id="event_time" name="event_time" 
                                   value="<?php echo e(old('event_time', $booking->event_time)); ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                   required>
                            <?php $__errorArgs = ['event_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Guest Count -->
                        <div>
                            <label for="guest_count" class="block text-sm font-medium text-gray-700 mb-2">Number of Guests *</label>
                            <input type="number" id="guest_count" name="guest_count" 
                                   value="<?php echo e(old('guest_count', $booking->guest_count)); ?>"
                                   min="1"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                                   required>
                            <?php $__errorArgs = ['guest_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Package Type -->
                        <div>
                            <label for="package_type" class="block text-sm font-medium text-gray-700 mb-2">Package Type</label>
                            <select id="package_type" name="package_type" 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500">
                                <option value="">Select Package (Optional)</option>
                                <option value="Basic" <?php echo e(old('package_type', $booking->package_type) == 'Basic' ? 'selected' : ''); ?>>Basic Package</option>
                                <option value="Premium" <?php echo e(old('package_type', $booking->package_type) == 'Premium' ? 'selected' : ''); ?>>Premium Package</option>
                                <option value="Deluxe" <?php echo e(old('package_type', $booking->package_type) == 'Deluxe' ? 'selected' : ''); ?>>Deluxe Package</option>
                                <option value="Custom" <?php echo e(old('package_type', $booking->package_type) == 'Custom' ? 'selected' : ''); ?>>Custom Package</option>
                            </select>
                            <?php $__errorArgs = ['package_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Venue -->
                    <div>
                        <label for="venue" class="block text-sm font-medium text-gray-700 mb-2">Venue *</label>
                        <input type="text" id="venue" name="venue" 
                               value="<?php echo e(old('venue', $booking->venue)); ?>"
                               placeholder="Enter venue address or location"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                               required>
                        <?php $__errorArgs = ['venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Contact Phone -->
                    <div>
                        <label for="contact_phone" class="block text-sm font-medium text-gray-700 mb-2">Contact Phone *</label>
                        <input type="tel" id="contact_phone" name="contact_phone" 
                               value="<?php echo e(old('contact_phone', $booking->contact_phone)); ?>"
                               placeholder="Enter your phone number"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"
                               required>
                        <?php $__errorArgs = ['contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Additional Details -->
                    <div>
                        <label for="additional_details" class="block text-sm font-medium text-gray-700 mb-2">Additional Details</label>
                        <textarea id="additional_details" name="additional_details" rows="3"
                                  placeholder="Any additional information about your event"
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"><?php echo e(old('additional_details', $booking->additional_details)); ?></textarea>
                        <?php $__errorArgs = ['additional_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Special Requests -->
                    <div>
                        <label for="special_requests" class="block text-sm font-medium text-gray-700 mb-2">Special Requests</label>
                        <textarea id="special_requests" name="special_requests" rows="3"
                                  placeholder="Any special requests or requirements"
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"><?php echo e(old('special_requests', $booking->special_requests)); ?></textarea>
                        <?php $__errorArgs = ['special_requests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Menu Preferences -->
                    <div>
                        <label for="menu_preferences" class="block text-sm font-medium text-gray-700 mb-2">Menu Preferences</label>
                        <textarea id="menu_preferences" name="menu_preferences" rows="3"
                                  placeholder="Dietary restrictions, preferred cuisines, etc."
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-maroon-500 focus:border-maroon-500"><?php echo e(old('menu_preferences', $booking->menu_preferences)); ?></textarea>
                        <?php $__errorArgs = ['menu_preferences'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Action Buttons -->
                    <div class="flex flex-col sm:flex-row gap-4 pt-6">
                        <button type="submit" 
                                class="flex-1 bg-maroon-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-maroon-700 transition duration-300">
                            Update Booking
                        </button>
                        <a href="<?php echo e(route('bookings.index')); ?>" 
                           class="flex-1 text-center bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-700 transition duration-300">
                            Cancel Changes
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9)): ?>
<?php $attributes = $__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9; ?>
<?php unset($__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9)): ?>
<?php $component = $__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9; ?>
<?php unset($__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9); ?>
<?php endif; ?>
<?php /**PATH C:\Users\melemmel2\Downloads\kylesCateringMSlatest2\kylesCateringMS\kylescateringMS\resources\views/bookings/edit.blade.php ENDPATH**/ ?>