<?php if (isset($component)) { $__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('landing-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- My Bookings Section -->
    <section class="py-12 sm:py-16 lg:py-20 bg-gray-50 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 sm:mb-16">
                <h2 class="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">My Bookings</h2>
                <p class="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-4 sm:px-0">
                    Manage your upcoming events and view booking history
                </p>
            </div>

            <?php if($bookings->count() > 0): ?>
                <!-- Bookings Stats -->
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
                    <div class="bg-white rounded-lg shadow-lg p-4 sm:p-6 text-center">
                        <div class="text-2xl sm:text-3xl font-bold text-maroon-600 mb-2"><?php echo e($bookings->count()); ?></div>
                        <div class="text-gray-600 text-sm sm:text-base">Total Bookings</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-lg p-4 sm:p-6 text-center">
                        <div class="text-2xl sm:text-3xl font-bold text-yellow-600 mb-2"><?php echo e($bookings->where('status', 'pending')->count()); ?></div>
                        <div class="text-gray-600 text-sm sm:text-base">Pending</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-lg p-4 sm:p-6 text-center">
                        <div class="text-2xl sm:text-3xl font-bold text-green-600 mb-2"><?php echo e($bookings->where('status', 'confirmed')->count()); ?></div>
                        <div class="text-gray-600 text-sm sm:text-base">Confirmed</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-lg p-4 sm:p-6 text-center">
                        <div class="text-2xl sm:text-3xl font-bold text-blue-600 mb-2"><?php echo e($bookings->where('status', 'completed')->count()); ?></div>
                        <div class="text-gray-600 text-sm sm:text-base">Completed</div>
                    </div>
                </div>

                <!-- Filter Buttons -->
                <div class="flex flex-wrap gap-2 sm:gap-4 mb-6 sm:mb-8 justify-center">
                    <button onclick="filterBookings('all')" class="filter-btn bg-maroon-600 text-white px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-lg font-semibold hover:bg-maroon-700 transition duration-300 touch-manipulation">
                        All Bookings
                    </button>
                    <button onclick="filterBookings('pending')" class="filter-btn bg-yellow-600 text-white px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-lg font-semibold hover:bg-yellow-700 transition duration-300 touch-manipulation">
                        Pending
                    </button>
                    <button onclick="filterBookings('confirmed')" class="filter-btn bg-green-600 text-white px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-lg font-semibold hover:bg-green-700 transition duration-300 touch-manipulation">
                        Confirmed
                    </button>
                    <button onclick="filterBookings('completed')" class="filter-btn bg-blue-600 text-white px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-base rounded-lg font-semibold hover:bg-blue-700 transition duration-300 touch-manipulation">
                        Completed
                    </button>
                </div>

                <!-- Bookings List -->
                <div class="space-y-4 sm:space-y-6">
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="booking-item bg-white rounded-lg shadow-lg p-4 sm:p-6" data-status="<?php echo e($booking->status); ?>">
                            <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
                                <!-- Booking Details -->
                                <div class="lg:col-span-2">
                                    <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-4">
                                        <div class="flex-1">
                                            <h3 class="text-lg sm:text-xl font-semibold text-gray-900 mb-2">
                                                <?php echo e($booking->event_name); ?>

                                            </h3>
                                            <div class="flex items-center mb-2">
                                                <svg class="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                                </svg>
                                                <span class="text-gray-600"><?php echo e($booking->event_date->format('F j, Y')); ?></span>
                                            </div>
                                            <div class="flex items-center mb-2">
                                                <svg class="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                                                </svg>
                                                <span class="text-gray-600"><?php echo e($booking->guest_count); ?> guests</span>
                                            </div>
                                            <?php if($booking->package_type): ?>
                                                <div class="flex items-center mb-2">
                                                    <svg class="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                                                    </svg>
                                                    <span class="text-gray-600"><?php echo e($booking->package_type); ?> Package</span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex flex-col sm:items-end space-y-2 mt-2 sm:mt-0">
                                            <span class="px-3 py-1 text-xs sm:text-sm font-semibold rounded-full <?php echo e($booking->status_badge); ?> self-start sm:self-end">
                                                <?php echo e(ucfirst($booking->status)); ?>

                                            </span>
                                        </div>
                                    </div>
                                    
                                    <?php if($booking->additional_details): ?>
                                        <div class="bg-gray-50 rounded-lg p-4 mb-4">
                                            <h4 class="text-sm font-semibold text-gray-700 mb-2">Additional Details:</h4>
                                            <p class="text-gray-600"><?php echo e($booking->additional_details); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Contact & Actions -->
                                <div class="lg:col-span-1">
                                    <div class="bg-gray-50 rounded-lg p-4">
                                        <h4 class="text-sm font-semibold text-gray-700 mb-3">Client Information</h4>
                                        <div class="space-y-3">
                                            <div class="flex items-start">
                                                <svg class="w-4 h-4 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                                                </svg>
                                                <div>
                                                    <div class="text-sm font-medium text-gray-900"><?php echo e($booking->user->name); ?></div>
                                                    <div class="text-xs text-gray-500">Client Name</div>
                                                </div>
                                            </div>
                                            <div class="flex items-start">
                                                <svg class="w-4 h-4 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                                </svg>
                                                <div>
                                                    <div class="text-sm text-gray-600"><?php echo e($booking->user->email); ?></div>
                                                    <div class="text-xs text-gray-500">Email Address</div>
                                                </div>
                                            </div>
                                            <div class="flex items-start">
                                                <svg class="w-4 h-4 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                                                </svg>
                                                <div>
                                                    <div class="text-sm text-gray-600"><?php echo e($booking->contact_phone ?? $booking->user->phone ?? 'N/A'); ?></div>
                                                    <div class="text-xs text-gray-500">Phone Number</div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-4 pt-4 border-t border-gray-200">
                                            <div class="text-xs text-gray-500">
                                                Booking Date: <?php echo e($booking->created_at->format('M j, Y')); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            <?php else: ?>
                <!-- Empty State -->
                <div class="bg-white rounded-lg shadow-lg p-6 sm:p-8 lg:p-12 text-center">
                    <svg class="mx-auto h-12 w-12 sm:h-16 sm:w-16 text-gray-400 mb-4 sm:mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                    </svg>
                    <h3 class="text-xl sm:text-2xl font-semibold text-gray-900 mb-4">No bookings yet</h3>
                    <p class="text-gray-600 mb-6 sm:mb-8 max-w-2xl mx-auto px-4 sm:px-0">
                        You haven't made any bookings yet. Start by exploring our packages and book your next event!
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4 sm:space-x-4 justify-center">
                        <a href="/#packages" class="bg-maroon-600 text-white px-6 sm:px-8 py-3 rounded-lg font-semibold hover:bg-maroon-700 transition duration-300 touch-manipulation text-center">
                            View Packages
                        </a>
                        <a href="/#book-now" class="border border-maroon-600 text-maroon-600 px-6 sm:px-8 py-3 rounded-lg font-semibold hover:bg-maroon-50 transition duration-300 touch-manipulation text-center">
                            Book Now
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <script>
        function filterBookings(status) {
            const bookingItems = document.querySelectorAll('.booking-item');
            const filterButtons = document.querySelectorAll('.filter-btn');
            
            // Reset all button styles
            filterButtons.forEach(btn => {
                btn.classList.remove('ring-2', 'ring-offset-2');
            });
            
            // Highlight active button
            event.target.classList.add('ring-2', 'ring-offset-2');
            
            bookingItems.forEach(item => {
                if (status === 'all' || item.dataset.status === status) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9)): ?>
<?php $attributes = $__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9; ?>
<?php unset($__attributesOriginal93de8e0a087f04fe46c2e97bf2f4abc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9)): ?>
<?php $component = $__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9; ?>
<?php unset($__componentOriginal93de8e0a087f04fe46c2e97bf2f4abc9); ?>
<?php endif; ?><?php /**PATH C:\Users\melemmel2\Downloads\kylesCateringMS\kylescateringMS\resources\views/bookings/index.blade.php ENDPATH**/ ?>