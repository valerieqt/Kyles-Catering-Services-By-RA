<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\BookingController;
use App\Http\Controllers\Api\InventoryController;
use App\Http\Controllers\Api\EventInventoryController;
use App\Http\Controllers\Api\EventTypeController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\StaffController;
use App\Http\Controllers\Api\StaffAssignmentController;
use App\Http\Controllers\Api\TaskApiController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\AuditLogController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Public API routes (no authentication required)
Route::prefix('v1')->group(function () {
    // Test route
    Route::get('/test', function () {
        return response()->json(['success' => true, 'message' => 'API is working']);
    });
    
    // Test POST route
    Route::post('/test-upload', function (Request $request) {
        return response()->json([
            'success' => true, 
            'message' => 'POST request working',
            'has_file' => $request->hasFile('test_file'),
            'content_type' => $request->header('Content-Type')
        ]);
    });
    
    // Authentication routes
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);
});

// Protected API routes (authentication required)
Route::prefix('v1')->middleware('auth:sanctum')->group(function () {
    // Authentication routes
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', [AuthController::class, 'user']);
    Route::put('/user', [AuthController::class, 'updateProfile']);
    
    // Booking routes
    Route::get('/bookings', [BookingController::class, 'index']);
    Route::post('/bookings', [BookingController::class, 'store']);
    Route::get('/bookings/{booking}', [BookingController::class, 'show']);
    Route::put('/bookings/{booking}', [BookingController::class, 'update']);
    Route::delete('/bookings/{booking}', [BookingController::class, 'destroy']);
    Route::patch('/bookings/{booking}/reschedule', [BookingController::class, 'reschedule']);
    Route::patch('/bookings/{booking}/cancel', [BookingController::class, 'cancel']);
    Route::patch('/bookings/{booking}/complete', [BookingController::class, 'markCompleted']); // Admin only
    Route::get('/bookings-history', [BookingController::class, 'getBookingHistory']); // Admin only
    
    // Profile routes
    Route::get('/profile', [ProfileController::class, 'show']);
    Route::put('/profile', [ProfileController::class, 'update']);
    Route::post('/profile', [ProfileController::class, 'update']); // For file uploads
    Route::delete('/profile', [ProfileController::class, 'destroy']);
    
    // Staff management routes (Admin only)
    Route::get('/staff', [StaffController::class, 'index']);
    Route::post('/staff', [StaffController::class, 'store']);
    Route::get('/staff/{staff}', [StaffController::class, 'show']);
    Route::put('/staff/{staff}', [StaffController::class, 'update']);
    Route::delete('/staff/{staff}', [StaffController::class, 'destroy']);
    
    // Staff assignment routes
    Route::get('/staff-assignments', [StaffAssignmentController::class, 'index']);
    Route::post('/staff-assignments', [StaffAssignmentController::class, 'store']); // Admin only
    Route::put('/staff-assignments/{id}/status', [StaffAssignmentController::class, 'updateStatus']);
    Route::get('/staff-assignments/date/{date}', [StaffAssignmentController::class, 'getByDate']);
    Route::get('/staff-assignments/booking/{bookingId}', [StaffAssignmentController::class, 'getByBooking']);
    Route::delete('/staff-assignments/{id}', [StaffAssignmentController::class, 'destroy']); // Admin only
    
    // Notification routes
    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::put('/notifications/{id}/read', [NotificationController::class, 'markAsRead']);
    Route::put('/notifications/mark-all-read', [NotificationController::class, 'markAllAsRead']);
    
    // Dashboard stats (for admin/staff)
    Route::get('/dashboard/stats', [AuthController::class, 'dashboardStats']);
    
    // Categories routes
    Route::get('/categories', [InventoryController::class, 'getCategories']);
    Route::post('/categories', [InventoryController::class, 'storeCategory']);
    Route::put('/categories/{id}', [InventoryController::class, 'updateCategory']);
    Route::delete('/categories/{id}', [InventoryController::class, 'destroyCategory']);
    
    // Inventory routes - specific routes must come before resource routes
    Route::get('/inventory/stats', [InventoryController::class, 'stats']);
    Route::get('/inventory/reports', [InventoryController::class, 'reports']);
    Route::get('/inventory/low-stock', [InventoryController::class, 'getLowStockItems']);
    Route::post('/inventory/check-low-stock', [InventoryController::class, 'checkAllLowStock']);
    Route::get('/inventory/debug-allocations', [InventoryController::class, 'debugAllocations']);
    Route::post('/inventory/seed-test-data', [InventoryController::class, 'seedTestData']);
    Route::get('/inventory/{id}/details', [InventoryController::class, 'details']);
    Route::post('/inventory/reserve', [InventoryController::class, 'reserve']);
    Route::post('/inventory/return', [InventoryController::class, 'returnItem']);
    Route::apiResource('inventory', InventoryController::class);
    
    // Event inventory management
    Route::post('/inventory/reserve', [InventoryController::class, 'reserveForEvent']);
    Route::get('/inventory/event/{booking}', [InventoryController::class, 'getEventInventory']);
    Route::post('/inventory/return/{eventInventory}', [InventoryController::class, 'processReturn']);
    
    // Event Type routes
    Route::apiResource('event-types', EventTypeController::class);
    
    // Event inventory allocation routes
    Route::get('/event-inventory/available', [EventInventoryController::class, 'getAvailableInventory']);
    Route::get('/event-inventory/booking/{bookingId}', [EventInventoryController::class, 'getBookingAllocations']);
    Route::post('/event-inventory/allocate', [EventInventoryController::class, 'allocateInventory']);
    Route::post('/event-inventory/return', [EventInventoryController::class, 'returnInventory']);
    Route::get('/event-inventory/return-reports', [EventInventoryController::class, 'getReturnReports']);
    Route::get('/event-inventory/stats', [EventInventoryController::class, 'getAllocationStats']);
    
    // Task/Schedule management routes
    Route::get('/tasks', [TaskApiController::class, 'index']);
    Route::post('/tasks', [TaskApiController::class, 'store']);
    Route::get('/tasks/upcoming', [TaskApiController::class, 'upcoming']);
    Route::get('/tasks/statistics', [TaskApiController::class, 'statistics']);
    Route::get('/tasks/users', [TaskApiController::class, 'getUsers']);
    Route::get('/tasks/{task}', [TaskApiController::class, 'show']);
    Route::put('/tasks/{task}', [TaskApiController::class, 'update']);
    Route::delete('/tasks/{task}', [TaskApiController::class, 'destroy']);
    Route::patch('/tasks/{task}/complete', [TaskApiController::class, 'markComplete']);
    
    // Audit log routes (Admin only)
    Route::get('/audit-logs', [AuditLogController::class, 'index']);
    Route::post('/audit-logs', [AuditLogController::class, 'store']);
    Route::get('/audit-logs/stats', [AuditLogController::class, 'stats']);
});
