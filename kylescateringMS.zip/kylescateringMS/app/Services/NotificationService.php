<?php

namespace App\Services;

use App\Models\Notification;
use App\Models\User;
use App\Models\InventoryItem;
use Illuminate\Support\Facades\Log;

class NotificationService
{
    /**
     * Create a low stock notification for admin users
     */
    public static function createLowStockNotification(InventoryItem $item, $threshold = 10)
    {
        try {
            // Get all admin users
            $adminUsers = User::where('role', 'admin')->get();
            
            if ($adminUsers->isEmpty()) {
                Log::warning('No admin users found to notify about low stock');
                return false;
            }

            // Check if we already have a recent low stock notification for this item
            $recentNotification = Notification::where('type', 'low_stock')
                ->where('data->inventory_item_id', $item->id)
                ->where('created_at', '>=', now()->subHours(24)) // Don't spam notifications
                ->first();

            if ($recentNotification) {
                Log::info("Recent low stock notification already exists for item: {$item->name}");
                return false;
            }

            $title = "Low Stock Alert";
            $message = "'{$item->name}' is running low with only {$item->available_quantity} items remaining.";
            
            $data = [
                'inventory_item_id' => $item->id,
                'item_name' => $item->name,
                'current_quantity' => $item->available_quantity,
                'threshold' => $threshold,
                'category' => $item->category,
                'location' => $item->location
            ];

            // Create notification for each admin
            foreach ($adminUsers as $admin) {
                Notification::create([
                    'user_id' => $admin->id,
                    'from_user_id' => null, // System notification
                    'type' => 'low_stock',
                    'title' => $title,
                    'message' => $message,
                    'data' => $data,
                    'is_read' => false
                ]);
            }

            Log::info("Low stock notification created for item: {$item->name} (Quantity: {$item->available_quantity})");
            return true;

        } catch (\Exception $e) {
            Log::error('Failed to create low stock notification: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Create an out of stock notification for admin users
     */
    public static function createOutOfStockNotification(InventoryItem $item)
    {
        try {
            // Get all admin users
            $adminUsers = User::where('role', 'admin')->get();
            
            if ($adminUsers->isEmpty()) {
                Log::warning('No admin users found to notify about out of stock');
                return false;
            }

            // Check if we already have a recent out of stock notification for this item
            $recentNotification = Notification::where('type', 'out_of_stock')
                ->where('data->inventory_item_id', $item->id)
                ->where('created_at', '>=', now()->subHours(24))
                ->first();

            if ($recentNotification) {
                Log::info("Recent out of stock notification already exists for item: {$item->name}");
                return false;
            }

            $title = "Out of Stock Alert";
            $message = "'{$item->name}' is now out of stock and needs immediate restocking.";
            
            $data = [
                'inventory_item_id' => $item->id,
                'item_name' => $item->name,
                'current_quantity' => $item->available_quantity,
                'category' => $item->category,
                'location' => $item->location,
                'priority' => 'high'
            ];

            // Create notification for each admin
            foreach ($adminUsers as $admin) {
                Notification::create([
                    'user_id' => $admin->id,
                    'from_user_id' => null, // System notification
                    'type' => 'out_of_stock',
                    'title' => $title,
                    'message' => $message,
                    'data' => $data,
                    'is_read' => false
                ]);
            }

            Log::info("Out of stock notification created for item: {$item->name}");
            return true;

        } catch (\Exception $e) {
            Log::error('Failed to create out of stock notification: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Check all inventory items for low stock and create notifications
     */
    public static function checkAndNotifyLowStock($threshold = 10)
    {
        try {
            $lowStockItems = InventoryItem::where('available_quantity', '<=', $threshold)
                ->where('available_quantity', '>', 0)
                ->get();

            $outOfStockItems = InventoryItem::where('available_quantity', '<=', 0)->get();

            $notificationsCreated = 0;

            // Create low stock notifications
            foreach ($lowStockItems as $item) {
                if (self::createLowStockNotification($item, $threshold)) {
                    $notificationsCreated++;
                }
            }

            // Create out of stock notifications
            foreach ($outOfStockItems as $item) {
                if (self::createOutOfStockNotification($item)) {
                    $notificationsCreated++;
                }
            }

            Log::info("Low stock check completed. Created {$notificationsCreated} notifications.");
            
            return [
                'low_stock_items' => $lowStockItems->count(),
                'out_of_stock_items' => $outOfStockItems->count(),
                'notifications_created' => $notificationsCreated
            ];

        } catch (\Exception $e) {
            Log::error('Failed to check low stock items: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Create inventory allocation notification
     */
    public static function createInventoryAllocationNotification($userId, $itemName, $quantity, $eventName)
    {
        try {
            $title = "Inventory Allocated";
            $message = "{$quantity} units of '{$itemName}' have been allocated for event '{$eventName}'.";
            
            $data = [
                'type' => 'allocation',
                'item_name' => $itemName,
                'quantity' => $quantity,
                'event_name' => $eventName
            ];

            return Notification::create([
                'user_id' => $userId,
                'from_user_id' => null,
                'type' => 'inventory_allocation',
                'title' => $title,
                'message' => $message,
                'data' => $data,
                'is_read' => false
            ]);

        } catch (\Exception $e) {
            Log::error('Failed to create inventory allocation notification: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Create inventory return notification
     */
    public static function createInventoryReturnNotification($userId, $itemName, $quantity, $eventName, $damageInfo = null)
    {
        try {
            $title = "Inventory Returned";
            $baseMessage = "{$quantity} units of '{$itemName}' have been returned from event '{$eventName}'.";
            
            $message = $baseMessage;
            if ($damageInfo && ($damageInfo['damaged'] > 0 || $damageInfo['missing'] > 0)) {
                $message .= " Note: {$damageInfo['damaged']} damaged, {$damageInfo['missing']} missing.";
            }
            
            $data = [
                'type' => 'return',
                'item_name' => $itemName,
                'quantity' => $quantity,
                'event_name' => $eventName,
                'damage_info' => $damageInfo
            ];

            return Notification::create([
                'user_id' => $userId,
                'from_user_id' => null,
                'type' => 'inventory_return',
                'title' => $title,
                'message' => $message,
                'data' => $data,
                'is_read' => false
            ]);

        } catch (\Exception $e) {
            Log::error('Failed to create inventory return notification: ' . $e->getMessage());
            return false;
        }
    }
}
