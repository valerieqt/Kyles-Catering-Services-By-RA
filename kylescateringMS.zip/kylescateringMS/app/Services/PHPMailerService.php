<?php

namespace App\Services;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
use Illuminate\Support\Facades\Log;

class PHPMailerService
{
    private $mailer;

    public function __construct()
    {
        $this->mailer = new PHPMailer(true);
        $this->configureMailer();
    }

    private function configureMailer()
    {
        try {
            // Server settings
            $this->mailer->isSMTP();
            $this->mailer->Host = env('MAIL_HOST', 'smtp.gmail.com');
            $this->mailer->SMTPAuth = true;
            $this->mailer->Username = env('MAIL_USERNAME');
            $this->mailer->Password = env('MAIL_PASSWORD');
            $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $this->mailer->Port = env('MAIL_PORT', 587);

            // Recipients
            $this->mailer->setFrom(env('MAIL_FROM_ADDRESS', 'noreply@kylescatering.com'), env('MAIL_FROM_NAME', 'Kyle\'s Catering'));

            // Content
            $this->mailer->isHTML(true);
            $this->mailer->CharSet = 'UTF-8';
        } catch (Exception $e) {
            Log::error('PHPMailer configuration error: ' . $e->getMessage());
            throw $e;
        }
    }

    public function sendPasswordResetEmail($email, $token, $userName = null)
    {
        try {
            // Clear any previous recipients
            $this->mailer->clearAddresses();
            
            // Add recipient
            $this->mailer->addAddress($email);

            // Subject
            $this->mailer->Subject = 'Reset Your Password - Kyle\'s Catering';

            // Generate reset URL
            $resetUrl = url('reset-password/' . $token . '?email=' . urlencode($email));

            // Email content
            $this->mailer->Body = $this->getPasswordResetEmailTemplate($resetUrl, $userName);
            $this->mailer->AltBody = $this->getPasswordResetEmailTextTemplate($resetUrl, $userName);

            $this->mailer->send();
            Log::info('Password reset email sent successfully to: ' . $email);
            return true;
        } catch (Exception $e) {
            Log::error('Failed to send password reset email: ' . $e->getMessage());
            return false;
        }
    }

    private function getPasswordResetEmailTemplate($resetUrl, $userName = null)
    {
        $greeting = $userName ? "Hello {$userName}," : "Hello,";
        
        return "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Password Reset</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #8B0000; color: white; padding: 20px; text-align: center; }
                .content { padding: 30px; background-color: #f9f9f9; }
                .button { 
                    display: inline-block; 
                    padding: 12px 30px; 
                    background-color: #8B0000; 
                    color: white; 
                    text-decoration: none; 
                    border-radius: 5px; 
                    margin: 20px 0;
                }
                .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Kyle's Catering</h1>
                </div>
                <div class='content'>
                    <h2>Password Reset Request</h2>
                    <p>{$greeting}</p>
                    <p>We received a request to reset your password for your Kyle's Catering account. If you made this request, please click the button below to reset your password:</p>
                    
                    <div style='text-align: center;'>
                        <a href='{$resetUrl}' class='button'>Reset Password</a>
                    </div>
                    
                    <p>If the button doesn't work, you can copy and paste this link into your browser:</p>
                    <p style='word-break: break-all; color: #666;'>{$resetUrl}</p>
                    
                    <p><strong>Important:</strong> This link will expire in 60 minutes for security reasons.</p>
                    
                    <p>If you didn't request a password reset, please ignore this email. Your password will remain unchanged.</p>
                    
                    <p>Best regards,<br>The Kyle's Catering Team</p>
                </div>
                <div class='footer'>
                    <p>This is an automated message. Please do not reply to this email.</p>
                    <p>&copy; " . date('Y') . " Kyle's Catering. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>";
    }

    private function getPasswordResetEmailTextTemplate($resetUrl, $userName = null)
    {
        $greeting = $userName ? "Hello {$userName}," : "Hello,";
        
        return "
{$greeting}

We received a request to reset your password for your Kyle's Catering account.

If you made this request, please visit the following link to reset your password:
{$resetUrl}

This link will expire in 60 minutes for security reasons.

If you didn't request a password reset, please ignore this email. Your password will remain unchanged.

Best regards,
The Kyle's Catering Team

---
This is an automated message. Please do not reply to this email.
© " . date('Y') . " Kyle's Catering. All rights reserved.
        ";
    }

    public function sendEmail($to, $subject, $htmlBody, $textBody = null, $fromName = null)
    {
        try {
            // Clear any previous recipients
            $this->mailer->clearAddresses();
            
            // Add recipient
            $this->mailer->addAddress($to);

            // Set from name if provided
            if ($fromName) {
                $this->mailer->setFrom(env('MAIL_FROM_ADDRESS'), $fromName);
            }

            $this->mailer->Subject = $subject;
            $this->mailer->Body = $htmlBody;
            
            if ($textBody) {
                $this->mailer->AltBody = $textBody;
            }

            $this->mailer->send();
            Log::info('Email sent successfully to: ' . $to);
            return true;
        } catch (Exception $e) {
            Log::error('Failed to send email: ' . $e->getMessage());
            return false;
        }
    }
}
