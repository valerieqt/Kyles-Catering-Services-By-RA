<?php

namespace App\Services;

use App\Models\Booking;
use Illuminate\Support\Facades\Log;

class BookingEmailService
{
    private $phpMailerService;

    public function __construct(PHPMailerService $phpMailerService)
    {
        $this->phpMailerService = $phpMailerService;
    }

    public function sendBookingConfirmation(Booking $booking)
    {
        $subject = "Booking Confirmation - {$booking->event_name}";
        $htmlBody = $this->getBookingConfirmationTemplate($booking);
        $textBody = $this->getBookingConfirmationTextTemplate($booking);

        $result = $this->phpMailerService->sendEmail(
            $booking->user->email,
            $subject,
            $htmlBody,
            $textBody,
            "Kyle's Catering"
        );

        if ($result) {
            Log::info("Booking confirmation email sent for booking ID: {$booking->id}");
        }

        return $result;
    }

    public function sendRescheduleConfirmation(Booking $booking, $oldDate, $oldTime)
    {
        $subject = "Booking Rescheduled - {$booking->event_name}";
        $htmlBody = $this->getRescheduleConfirmationTemplate($booking, $oldDate, $oldTime);
        $textBody = $this->getRescheduleConfirmationTextTemplate($booking, $oldDate, $oldTime);

        $result = $this->phpMailerService->sendEmail(
            $booking->user->email,
            $subject,
            $htmlBody,
            $textBody,
            "Kyle's Catering"
        );

        if ($result) {
            Log::info("Reschedule confirmation email sent for booking ID: {$booking->id}");
        }

        return $result;
    }

    public function sendCancellationConfirmation(Booking $booking)
    {
        $subject = "Booking Cancelled - {$booking->event_name}";
        $htmlBody = $this->getCancellationConfirmationTemplate($booking);
        $textBody = $this->getCancellationConfirmationTextTemplate($booking);

        $result = $this->phpMailerService->sendEmail(
            $booking->user->email,
            $subject,
            $htmlBody,
            $textBody,
            "Kyle's Catering"
        );

        if ($result) {
            Log::info("Cancellation confirmation email sent for booking ID: {$booking->id}");
        }

        return $result;
    }

    private function getBookingConfirmationTemplate(Booking $booking)
    {
        $eventDate = $booking->event_date->format('F j, Y');
        $eventTime = $booking->event_time;
        
        return "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Booking Confirmation</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 0 auto; }
                .header { background-color: #7c2d12; color: white; padding: 30px 20px; text-align: center; }
                .content { padding: 30px 20px; background-color: #ffffff; }
                .booking-details { background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #7c2d12; }
                .detail-row { margin: 10px 0; }
                .label { font-weight: bold; color: #7c2d12; }
                .status-badge { display: inline-block; padding: 4px 12px; background-color: #fef3c7; color: #92400e; border-radius: 20px; font-size: 12px; font-weight: bold; }
                .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; background-color: #f9fafb; }
                .contact-info { background-color: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1 style='margin: 0; font-size: 28px;'>Kyle's Catering</h1>
                    <p style='margin: 10px 0 0 0; font-size: 16px;'>Booking Confirmation</p>
                </div>
                <div class='content'>
                    <h2 style='color: #7c2d12; margin-top: 0;'>Thank you for your booking!</h2>
                    <p>Dear {$booking->user->name},</p>
                    <p>We're excited to confirm your booking with Kyle's Catering. Your event details are below:</p>
                    
                    <div class='booking-details'>
                        <h3 style='margin-top: 0; color: #7c2d12;'>Booking Details</h3>
                        <div class='detail-row'><span class='label'>Booking ID:</span> #{$booking->id}</div>
                        <div class='detail-row'><span class='label'>Event Name:</span> {$booking->event_name}</div>
                        <div class='detail-row'><span class='label'>Date:</span> {$eventDate}</div>
                        <div class='detail-row'><span class='label'>Time:</span> {$eventTime}</div>
                        <div class='detail-row'><span class='label'>Guests:</span> {$booking->guest_count}</div>
                        <div class='detail-row'><span class='label'>Venue:</span> {$booking->venue}</div>
                        " . ($booking->event_type ? "<div class='detail-row'><span class='label'>Event Type:</span> {$booking->event_type}</div>" : "") . "
                        " . ($booking->package_type ? "<div class='detail-row'><span class='label'>Package:</span> {$booking->package_type}</div>" : "") . "
                        <div class='detail-row'><span class='label'>Status:</span> <span class='status-badge'>" . ucfirst($booking->status) . "</span></div>
                    </div>
                    
                    " . ($booking->special_requests ? "<div class='detail-row'><strong>Special Requests:</strong><br>{$booking->special_requests}</div>" : "") . "
                    " . ($booking->menu_preferences ? "<div class='detail-row'><strong>Menu Preferences:</strong><br>{$booking->menu_preferences}</div>" : "") . "
                    
                    <div class='contact-info'>
                        <h4 style='margin-top: 0; color: #1e40af;'>Next Steps</h4>
                        <p style='margin: 5px 0;'>• Our team will review your booking and contact you within 24 hours</p>
                        <p style='margin: 5px 0;'>• You can manage your booking online at any time</p>
                        <p style='margin: 5px 0;'>• Questions? Contact us at <strong>09356337433</strong></p>
                    </div>
                    
                    <p>We look forward to making your event memorable!</p>
                    <p>Best regards,<br><strong>The Kyle's Catering Team</strong></p>
                </div>
                <div class='footer'>
                    <p>This is an automated confirmation email.</p>
                    <p>&copy; " . date('Y') . " Kyle's Catering. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>";
    }

    private function getBookingConfirmationTextTemplate(Booking $booking)
    {
        $eventDate = $booking->event_date->format('F j, Y');
        
        return "
KYLE'S CATERING - BOOKING CONFIRMATION

Dear {$booking->user->name},

Thank you for your booking! We're excited to cater your event.

BOOKING DETAILS:
- Booking ID: #{$booking->id}
- Event: {$booking->event_name}
- Date: {$eventDate}
- Time: {$booking->event_time}
- Guests: {$booking->guest_count}
- Venue: {$booking->venue}
- Status: " . ucfirst($booking->status) . "

NEXT STEPS:
• Our team will review your booking and contact you within 24 hours
• You can manage your booking online at any time
• Questions? Contact us at 09356337433

We look forward to making your event memorable!

Best regards,
The Kyle's Catering Team

---
This is an automated confirmation email.
© " . date('Y') . " Kyle's Catering. All rights reserved.
        ";
    }

    private function getRescheduleConfirmationTemplate(Booking $booking, $oldDate, $oldTime)
    {
        $newDate = $booking->event_date->format('F j, Y');
        $oldDateFormatted = $oldDate->format('F j, Y');
        
        return "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Booking Rescheduled</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 0 auto; }
                .header { background-color: #d97706; color: white; padding: 30px 20px; text-align: center; }
                .content { padding: 30px 20px; background-color: #ffffff; }
                .change-highlight { background-color: #fef3c7; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #d97706; }
                .booking-details { background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; }
                .detail-row { margin: 10px 0; }
                .label { font-weight: bold; color: #7c2d12; }
                .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; background-color: #f9fafb; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1 style='margin: 0; font-size: 28px;'>Kyle's Catering</h1>
                    <p style='margin: 10px 0 0 0; font-size: 16px;'>Booking Rescheduled</p>
                </div>
                <div class='content'>
                    <h2 style='color: #d97706; margin-top: 0;'>Your booking has been rescheduled</h2>
                    <p>Dear {$booking->user->name},</p>
                    <p>We've successfully rescheduled your booking as requested.</p>
                    
                    <div class='change-highlight'>
                        <h3 style='margin-top: 0; color: #92400e;'>Schedule Change</h3>
                        <p><strong>Previous:</strong> {$oldDateFormatted} at {$oldTime}</p>
                        <p><strong>New:</strong> {$newDate} at {$booking->event_time}</p>
                    </div>
                    
                    <div class='booking-details'>
                        <h3 style='margin-top: 0; color: #7c2d12;'>Updated Booking Details</h3>
                        <div class='detail-row'><span class='label'>Booking ID:</span> #{$booking->id}</div>
                        <div class='detail-row'><span class='label'>Event:</span> {$booking->event_name}</div>
                        <div class='detail-row'><span class='label'>New Date:</span> {$newDate}</div>
                        <div class='detail-row'><span class='label'>New Time:</span> {$booking->event_time}</div>
                        <div class='detail-row'><span class='label'>Guests:</span> {$booking->guest_count}</div>
                        <div class='detail-row'><span class='label'>Status:</span> Pending Review</div>
                    </div>
                    
                    <p><strong>Important:</strong> Your booking status has been reset to 'Pending' for our team to review the new date and confirm availability.</p>
                    <p>We'll contact you within 24 hours to confirm the new schedule.</p>
                    
                    <p>Thank you for choosing Kyle's Catering!</p>
                    <p>Best regards,<br><strong>The Kyle's Catering Team</strong></p>
                </div>
                <div class='footer'>
                    <p>This is an automated notification email.</p>
                    <p>&copy; " . date('Y') . " Kyle's Catering. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>";
    }

    private function getRescheduleConfirmationTextTemplate(Booking $booking, $oldDate, $oldTime)
    {
        $newDate = $booking->event_date->format('F j, Y');
        $oldDateFormatted = $oldDate->format('F j, Y');
        
        return "
KYLE'S CATERING - BOOKING RESCHEDULED

Dear {$booking->user->name},

Your booking has been successfully rescheduled.

SCHEDULE CHANGE:
Previous: {$oldDateFormatted} at {$oldTime}
New: {$newDate} at {$booking->event_time}

UPDATED BOOKING DETAILS:
- Booking ID: #{$booking->id}
- Event: {$booking->event_name}
- New Date: {$newDate}
- New Time: {$booking->event_time}
- Status: Pending Review

IMPORTANT: Your booking status has been reset to 'Pending' for our team to review the new date and confirm availability.

We'll contact you within 24 hours to confirm the new schedule.

Thank you for choosing Kyle's Catering!

Best regards,
The Kyle's Catering Team

---
This is an automated notification email.
© " . date('Y') . " Kyle's Catering. All rights reserved.
        ";
    }

    private function getCancellationConfirmationTemplate(Booking $booking)
    {
        $eventDate = $booking->event_date->format('F j, Y');
        
        return "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Booking Cancelled</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 0 auto; }
                .header { background-color: #dc2626; color: white; padding: 30px 20px; text-align: center; }
                .content { padding: 30px 20px; background-color: #ffffff; }
                .cancellation-notice { background-color: #fef2f2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #dc2626; }
                .booking-details { background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; }
                .detail-row { margin: 10px 0; }
                .label { font-weight: bold; color: #7c2d12; }
                .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; background-color: #f9fafb; }
                .contact-info { background-color: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1 style='margin: 0; font-size: 28px;'>Kyle's Catering</h1>
                    <p style='margin: 10px 0 0 0; font-size: 16px;'>Booking Cancellation</p>
                </div>
                <div class='content'>
                    <h2 style='color: #dc2626; margin-top: 0;'>Booking Cancelled</h2>
                    <p>Dear {$booking->user->name},</p>
                    <p>We've processed your cancellation request for the following booking:</p>
                    
                    <div class='cancellation-notice'>
                        <h3 style='margin-top: 0; color: #991b1b;'>Cancellation Confirmed</h3>
                        <p>Your booking has been successfully cancelled. We understand that plans can change.</p>
                    </div>
                    
                    <div class='booking-details'>
                        <h3 style='margin-top: 0; color: #7c2d12;'>Cancelled Booking Details</h3>
                        <div class='detail-row'><span class='label'>Booking ID:</span> #{$booking->id}</div>
                        <div class='detail-row'><span class='label'>Event:</span> {$booking->event_name}</div>
                        <div class='detail-row'><span class='label'>Date:</span> {$eventDate}</div>
                        <div class='detail-row'><span class='label'>Time:</span> {$booking->event_time}</div>
                        <div class='detail-row'><span class='label'>Guests:</span> {$booking->guest_count}</div>
                        <div class='detail-row'><span class='label'>Status:</span> Cancelled</div>
                    </div>
                    
                    <div class='contact-info'>
                        <h4 style='margin-top: 0; color: #1e40af;'>Need Help?</h4>
                        <p style='margin: 5px 0;'>• If you need to make a new booking, visit our website</p>
                        <p style='margin: 5px 0;'>• Questions about cancellation? Contact us at <strong>09356337433</strong></p>
                        <p style='margin: 5px 0;'>• We're here to help with future events</p>
                    </div>
                    
                    <p>Thank you for considering Kyle's Catering. We hope to serve you again in the future!</p>
                    <p>Best regards,<br><strong>The Kyle's Catering Team</strong></p>
                </div>
                <div class='footer'>
                    <p>This is an automated cancellation confirmation.</p>
                    <p>&copy; " . date('Y') . " Kyle's Catering. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>";
    }

    private function getCancellationConfirmationTextTemplate(Booking $booking)
    {
        $eventDate = $booking->event_date->format('F j, Y');
        
        return "
KYLE'S CATERING - BOOKING CANCELLED

Dear {$booking->user->name},

Your booking cancellation has been processed.

CANCELLED BOOKING DETAILS:
- Booking ID: #{$booking->id}
- Event: {$booking->event_name}
- Date: {$eventDate}
- Time: {$booking->event_time}
- Status: Cancelled

We understand that plans can change. If you need to make a new booking or have questions, please contact us at 09356337433.

Thank you for considering Kyle's Catering. We hope to serve you again in the future!

Best regards,
The Kyle's Catering Team

---
This is an automated cancellation confirmation.
© " . date('Y') . " Kyle's Catering. All rights reserved.
        ";
    }
}
