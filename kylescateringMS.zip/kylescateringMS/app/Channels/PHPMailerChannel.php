<?php

namespace App\Channels;

use Illuminate\Notifications\Notification;

class PHPMailerChannel
{
    public function send($notifiable, Notification $notification)
    {
        if (method_exists($notification, 'toPhpMailer')) {
            return $notification->toPhpMailer($notifiable);
        }

        throw new \Exception('Notification does not support PHPMailer channel');
    }
}
