<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class ValidateMailConfig extends Command
{
    protected $signature = 'validate:mail-config';
    protected $description = 'Validate mail configuration for PHPMailer';

    public function handle()
    {
        $this->info('🔍 Validating Mail Configuration...');
        $this->newLine();

        $required = [
            'MAIL_HOST' => env('MAIL_HOST'),
            'MAIL_PORT' => env('MAIL_PORT'),
            'MAIL_USERNAME' => env('MAIL_USERNAME'),
            'MAIL_PASSWORD' => env('MAIL_PASSWORD'),
            'MAIL_FROM_ADDRESS' => env('MAIL_FROM_ADDRESS'),
            'MAIL_FROM_NAME' => env('MAIL_FROM_NAME'),
        ];

        $allValid = true;

        foreach ($required as $key => $value) {
            if (empty($value)) {
                $this->error("❌ {$key} is not set or empty");
                $allValid = false;
            } else {
                if ($key === 'MAIL_PASSWORD') {
                    $displayValue = str_repeat('*', strlen($value));
                } else {
                    $displayValue = $value;
                }
                $this->info("✅ {$key}: {$displayValue}");
            }
        }

        $this->newLine();

        if ($allValid) {
            $this->info('🎉 All required mail configuration variables are set!');
            $this->newLine();
            $this->info('Next steps:');
            $this->info('1. Test the configuration: php artisan test:phpmailer');
            $this->info('2. Or visit: /test-phpmailer in your browser');
        } else {
            $this->error('❌ Some mail configuration variables are missing.');
            $this->newLine();
            $this->info('Please add the missing variables to your .env file:');
            $this->newLine();
            
            foreach ($required as $key => $value) {
                if (empty($value)) {
                    switch ($key) {
                        case 'MAIL_HOST':
                            $this->info("{$key}=smtp.gmail.com");
                            break;
                        case 'MAIL_PORT':
                            $this->info("{$key}=587");
                            break;
                        case 'MAIL_USERNAME':
                            $this->info("{$key}=your-email@gmail.com");
                            break;
                        case 'MAIL_PASSWORD':
                            $this->info("{$key}=your-app-password");
                            break;
                        case 'MAIL_FROM_ADDRESS':
                            $this->info("{$key}=noreply@kylescatering.com");
                            break;
                        case 'MAIL_FROM_NAME':
                            $this->info("{$key}=\"Kyle's Catering\"");
                            break;
                    }
                }
            }
            
            $this->newLine();
            $this->info('📖 See PHPMAILER_SETUP.md for detailed configuration instructions.');
        }

        return $allValid ? 0 : 1;
    }
}
