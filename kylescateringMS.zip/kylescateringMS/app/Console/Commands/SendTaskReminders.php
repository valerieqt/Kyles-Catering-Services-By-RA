<?php

namespace App\Console\Commands;

use App\Models\Task;
use App\Models\Notification;
use Illuminate\Console\Command;
use Carbon\Carbon;

class SendTaskReminders extends Command
{
    protected $signature = 'tasks:send-reminders';
    protected $description = 'Send reminder notifications for upcoming tasks';

    public function handle()
    {
        $this->info('Checking for tasks that need reminders...');

        // Get tasks that are due within the next 24 hours and haven't had reminders sent
        $upcomingTasks = Task::with(['user', 'creator'])
            ->where('reminder_sent', false)
            ->where('status', '!=', 'completed')
            ->where('status', '!=', 'cancelled')
            ->whereDate('task_date', '>=', now()->toDateString())
            ->whereDate('task_date', '<=', now()->addDay()->toDateString())
            ->get();

        $remindersSent = 0;

        foreach ($upcomingTasks as $task) {
            $taskDateTime = Carbon::parse($task->task_date->format('Y-m-d') . ' ' . $task->task_time);
            
            // Send reminder if task is within 24 hours
            if ($taskDateTime->diffInHours(now()) <= 24 && $taskDateTime->isFuture()) {
                $this->sendTaskReminder($task);
                $task->update(['reminder_sent' => true]);
                $remindersSent++;
            }
        }

        $this->info("Sent {$remindersSent} task reminders.");
        return 0;
    }

    private function sendTaskReminder(Task $task)
    {
        $taskDateTime = Carbon::parse($task->task_date->format('Y-m-d') . ' ' . $task->task_time);
        
        // Create notification for the task creator
        Notification::create([
            'user_id' => $task->created_by,
            'type' => 'task_reminder',
            'title' => 'Task Reminder: ' . $task->title,
            'message' => "Don't forget about your {$task->type} scheduled for {$taskDateTime->format('M j, Y \a\t g:i A')}.",
            'data' => json_encode([
                'task_id' => $task->id,
                'task_title' => $task->title,
                'task_date' => $task->task_date->format('Y-m-d'),
                'task_time' => $task->task_time,
                'task_type' => $task->type
            ]),
            'read_at' => null
        ]);

        // If task is assigned to a different user, also notify them
        if ($task->user_id && $task->user_id !== $task->created_by) {
            Notification::create([
                'user_id' => $task->user_id,
                'type' => 'task_reminder',
                'title' => 'Task Reminder: ' . $task->title,
                'message' => "You have a {$task->type} scheduled for {$taskDateTime->format('M j, Y \a\t g:i A')}.",
                'data' => json_encode([
                    'task_id' => $task->id,
                    'task_title' => $task->title,
                    'task_date' => $task->task_date->format('Y-m-d'),
                    'task_time' => $task->task_time,
                    'task_type' => $task->type
                ]),
                'read_at' => null
            ]);
        }

        $this->line("Reminder sent for task: {$task->title}");
    }
}
