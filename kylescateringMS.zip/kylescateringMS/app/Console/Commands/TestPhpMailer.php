<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Services\PHPMailerService;

class TestPhpMailer extends Command
{
    protected $signature = 'test:phpmailer {email?}';
    protected $description = 'Test PHPMailer configuration by sending a test email';

    public function handle()
    {
        $email = $this->argument('email');
        
        if (!$email) {
            $user = User::first();
            if (!$user) {
                $this->error('No users found in database and no email provided.');
                $this->info('Usage: php artisan test:phpmailer your-email@example.com');
                return 1;
            }
            $email = $user->email;
            $userName = $user->name;
        } else {
            $userName = null;
        }

        $this->info("Testing PHPMailer with email: {$email}");

        try {
            $phpMailerService = new PHPMailerService();
            $testToken = 'test-token-' . time();
            
            $result = $phpMailerService->sendPasswordResetEmail($email, $testToken, $userName);
            
            if ($result) {
                $this->info('✅ Test email sent successfully!');
                $this->info("Check the inbox for: {$email}");
                $this->info('Also check storage/logs/laravel.log for detailed logs.');
            } else {
                $this->error('❌ Failed to send test email.');
                $this->info('Check storage/logs/laravel.log for error details.');
            }
            
        } catch (\Exception $e) {
            $this->error('❌ Error: ' . $e->getMessage());
            $this->info('Make sure your .env file has the correct mail configuration.');
            return 1;
        }

        return 0;
    }
}
