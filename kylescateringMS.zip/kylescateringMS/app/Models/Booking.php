<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $fillable = [
        'user_id',
        'event_name',
        'event_date',
        'event_time',
        'guest_count',
        'event_type',
        'package_type',
        'venue',
        'contact_phone',
        'additional_details',
        'special_requests',
        'menu_preferences',
        'status',
        'completed_at',
        'completion_notes'
    ];

    protected $casts = [
        'event_date' => 'date',
        'completed_at' => 'datetime'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function eventType()
    {
        return $this->belongsTo(EventType::class, 'event_type', 'name');
    }

    public function eventInventory()
    {
        return $this->hasMany(EventInventory::class);
    }

    public function inventoryTransactions()
    {
        return $this->hasMany(InventoryTransaction::class);
    }

    public function staffAssignments()
    {
        return $this->hasMany(StaffAssignment::class);
    }

    public function inventoryAllocations()
    {
        return $this->hasMany(EventInventoryAllocation::class);
    }

    public function returnReports()
    {
        return $this->hasMany(InventoryReturnReport::class);
    }

    public function getStatusBadgeAttribute()
    {
        $badges = [
            'pending' => 'bg-yellow-100 text-yellow-800',
            'confirmed' => 'bg-green-100 text-green-800',
            'completed' => 'bg-blue-100 text-blue-800',
            'cancelled' => 'bg-red-100 text-red-800'
        ];

        return $badges[$this->status] ?? 'bg-gray-100 text-gray-800';
    }

    public function getTotalInventoryValueAttribute()
    {
        return $this->eventInventory->sum(function ($eventInventory) {
            return $eventInventory->quantity_reserved * ($eventInventory->inventoryItem->unit_cost ?? 0);
        });
    }

    public function getInventoryStatusAttribute()
    {
        $totalItems = $this->eventInventory->count();
        if ($totalItems === 0) return 'no_inventory';
        
        $returnedItems = $this->eventInventory->where('status', 'returned')->count();
        $partiallyReturnedItems = $this->eventInventory->where('status', 'partially_returned')->count();
        $inUseItems = $this->eventInventory->where('status', 'in_use')->count();
        
        if ($returnedItems === $totalItems) return 'all_returned';
        if ($inUseItems > 0 || $partiallyReturnedItems > 0) return 'pending_return';
        return 'reserved';
    }
}
