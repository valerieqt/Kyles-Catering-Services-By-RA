<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Task extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'title',
        'description',
        'task_date',
        'task_time',
        'type',
        'status',
        'reminder_sent',
        'created_by'
    ];

    protected $casts = [
        'task_date' => 'date',
        'task_time' => 'datetime',
        'reminder_sent' => 'boolean'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function getStatusBadgeAttribute()
    {
        $badges = [
            'pending' => 'bg-yellow-100 text-yellow-800',
            'in_progress' => 'bg-blue-100 text-blue-800',
            'completed' => 'bg-green-100 text-green-800',
            'cancelled' => 'bg-red-100 text-red-800'
        ];

        return $badges[$this->status] ?? 'bg-gray-100 text-gray-800';
    }

    public function getFormattedDateTimeAttribute()
    {
        return $this->task_date->format('M d, Y') . ' at ' . $this->task_time->format('g:i A');
    }

    public function scopeUpcoming($query)
    {
        return $query->where('task_date', '>=', now()->toDateString())
                    ->where('status', '!=', 'completed')
                    ->orderBy('task_date')
                    ->orderBy('task_time');
    }

    public function scopeForDate($query, $date)
    {
        return $query->whereDate('task_date', $date);
    }
}
