<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EventInventory extends Model
{
    use HasFactory;

    protected $table = 'event_inventory';

    protected $fillable = [
        'booking_id',
        'inventory_item_id',
        'quantity_reserved',
        'quantity_used',
        'quantity_returned',
        'quantity_damaged',
        'quantity_lost',
        'damage_notes',
        'status',
        'reserved_at',
        'used_at',
        'returned_at'
    ];

    protected $casts = [
        'quantity_reserved' => 'integer',
        'quantity_used' => 'integer',
        'quantity_returned' => 'integer',
        'quantity_damaged' => 'integer',
        'quantity_lost' => 'integer',
        'reserved_at' => 'datetime',
        'used_at' => 'datetime',
        'returned_at' => 'datetime',
    ];

    // Relationships
    public function booking()
    {
        return $this->belongsTo(Booking::class);
    }

    public function inventoryItem()
    {
        return $this->belongsTo(InventoryItem::class);
    }

    // Accessors
    public function getQuantityOutstandingAttribute()
    {
        return $this->quantity_reserved - $this->quantity_returned - $this->quantity_damaged - $this->quantity_lost;
    }

    public function getReturnRateAttribute()
    {
        if ($this->quantity_reserved == 0) return 0;
        return round(($this->quantity_returned / $this->quantity_reserved) * 100, 2);
    }

    public function getDamageRateAttribute()
    {
        if ($this->quantity_reserved == 0) return 0;
        return round(($this->quantity_damaged / $this->quantity_reserved) * 100, 2);
    }

    public function getLossRateAttribute()
    {
        if ($this->quantity_reserved == 0) return 0;
        return round(($this->quantity_lost / $this->quantity_reserved) * 100, 2);
    }

    // Methods
    public function markAsUsed($userId = null)
    {
        $this->status = 'in_use';
        $this->used_at = now();
        $this->quantity_used = $this->quantity_reserved;
        $this->save();

        // Log transaction
        if ($userId) {
            $this->inventoryItem->logTransaction('use', $this->quantity_reserved, $this->booking_id, $userId);
        }

        return true;
    }

    public function processReturn($quantityReturned, $quantityDamaged = 0, $quantityLost = 0, $damageNotes = null, $userId = null)
    {
        $this->quantity_returned += $quantityReturned;
        $this->quantity_damaged += $quantityDamaged;
        $this->quantity_lost += $quantityLost;
        $this->damage_notes = $damageNotes;
        $this->returned_at = now();

        // Update status
        $totalProcessed = $this->quantity_returned + $this->quantity_damaged + $this->quantity_lost;
        if ($totalProcessed >= $this->quantity_reserved) {
            $this->status = 'returned';
        } else {
            $this->status = 'partially_returned';
        }

        $this->save();

        // Update inventory item quantities
        if ($quantityReturned > 0) {
            $this->inventoryItem->returnItems($quantityReturned, $this->booking_id, $userId);
        }
        if ($quantityDamaged > 0) {
            $this->inventoryItem->markDamaged($quantityDamaged, $this->booking_id, $userId, $damageNotes);
        }
        if ($quantityLost > 0) {
            $this->inventoryItem->markLost($quantityLost, $this->booking_id, $userId, $damageNotes);
        }

        return true;
    }
}
