<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InventoryItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'category',
        'total_quantity',
        'available_quantity',
        'reserved_quantity',
        'damaged_quantity',
        'lost_quantity',
        'unit_cost',
        'condition',
        'location',
        'last_maintenance',
        'notes'
    ];

    protected $casts = [
        'unit_cost' => 'decimal:2',
        'last_maintenance' => 'date',
        'total_quantity' => 'integer',
        'available_quantity' => 'integer',
        'reserved_quantity' => 'integer',
        'damaged_quantity' => 'integer',
        'lost_quantity' => 'integer',
    ];

    protected $appends = [
        'status',
        'utilization_rate'
    ];

    // Relationships
    public function eventInventory()
    {
        return $this->hasMany(EventInventory::class);
    }

    public function transactions()
    {
        return $this->hasMany(InventoryTransaction::class);
    }

    public function allocations()
    {
        return $this->hasMany(EventInventoryAllocation::class);
    }

    // Scopes
    public function scopeAvailable($query)
    {
        return $query->where('available_quantity', '>', 0);
    }

    public function scopeByCategory($query, $category)
    {
        return $query->where('category', $category);
    }

    public function scopeLowStock($query, $threshold = 10)
    {
        return $query->where('available_quantity', '<=', $threshold);
    }

    // Accessors
    public function getUtilizationRateAttribute()
    {
        if ($this->total_quantity == 0) return 0;
        return round((($this->total_quantity - $this->available_quantity) / $this->total_quantity) * 100, 2);
    }

    public function getStatusAttribute()
    {
        if ($this->available_quantity <= 0) {
            return 'out_of_stock';
        } elseif ($this->available_quantity <= 10) {
            return 'low_stock';
        } else {
            return 'in_stock';
        }
    }

    // Methods
    public function canReserve($quantity)
    {
        return $this->available_quantity >= $quantity;
    }

    public function reserve($quantity, $bookingId = null, $userId = null)
    {
        if (!$this->canReserve($quantity)) {
            return false;
        }

        $this->available_quantity -= $quantity;
        $this->reserved_quantity += $quantity;
        $this->save();

        // Log transaction
        if ($userId) {
            $this->logTransaction('reserve', $quantity, $bookingId, $userId);
        }

        return true;
    }

    public function returnItems($quantity, $bookingId = null, $userId = null)
    {
        $this->available_quantity += $quantity;
        $this->reserved_quantity = max(0, $this->reserved_quantity - $quantity);
        $this->save();

        // Log transaction
        if ($userId) {
            $this->logTransaction('return', $quantity, $bookingId, $userId);
        }

        return true;
    }

    public function markDamaged($quantity, $bookingId = null, $userId = null, $notes = null)
    {
        $this->damaged_quantity += $quantity;
        $this->reserved_quantity = max(0, $this->reserved_quantity - $quantity);
        $this->total_quantity -= $quantity; // Remove from total inventory
        $this->save();

        // Log transaction
        if ($userId) {
            $this->logTransaction('damage', $quantity, $bookingId, $userId, $notes);
        }

        return true;
    }

    public function markLost($quantity, $bookingId = null, $userId = null, $notes = null)
    {
        $this->lost_quantity += $quantity;
        $this->reserved_quantity = max(0, $this->reserved_quantity - $quantity);
        $this->total_quantity -= $quantity; // Remove from total inventory
        $this->save();

        // Log transaction
        if ($userId) {
            $this->logTransaction('loss', $quantity, $bookingId, $userId, $notes);
        }

        return true;
    }

    private function logTransaction($type, $quantity, $bookingId = null, $userId = null, $notes = null)
    {
        $quantityBefore = $this->getOriginal('available_quantity') ?? $this->available_quantity;
        
        InventoryTransaction::create([
            'inventory_item_id' => $this->id,
            'booking_id' => $bookingId,
            'user_id' => $userId,
            'type' => $type,
            'quantity' => $quantity,
            'quantity_before' => $quantityBefore,
            'quantity_after' => $this->available_quantity,
            'notes' => $notes
        ]);
    }
}
