<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StaffAssignment extends Model
{
    use HasFactory;

    protected $fillable = [
        'staff_id',
        'booking_id',
        'role',
        'status',
        'notes',
        'requirements',
        'assigned_at',
        'responded_at',
    ];

    protected $casts = [
        'requirements' => 'array',
        'assigned_at' => 'datetime',
        'responded_at' => 'datetime',
    ];

    /**
     * Get the staff member assigned to this assignment.
     */
    public function staff(): BelongsTo
    {
        return $this->belongsTo(User::class, 'staff_id');
    }

    /**
     * Get the booking for this assignment.
     */
    public function booking(): BelongsTo
    {
        return $this->belongsTo(Booking::class);
    }

    /**
     * Scope to get assignments for a specific staff member.
     */
    public function scopeForStaff($query, $staffId)
    {
        return $query->where('staff_id', $staffId);
    }

    /**
     * Scope to get assignments with a specific status.
     */
    public function scopeWithStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope to get assignments for a specific date.
     */
    public function scopeForDate($query, $date)
    {
        return $query->whereHas('booking', function ($q) use ($date) {
            $q->whereDate('event_date', $date);
        });
    }
}
