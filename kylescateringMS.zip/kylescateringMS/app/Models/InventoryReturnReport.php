<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InventoryReturnReport extends Model
{
    use HasFactory;

    protected $fillable = [
        'booking_id',
        'event_inventory_allocation_id',
        'returned_by',
        'quantity_returned',
        'quantity_damaged',
        'quantity_missing',
        'damage_description',
        'missing_description',
        'general_notes',
        'damage_photos',
        'damage_cost',
        'replacement_cost',
        'condition',
        'returned_at',
    ];

    protected $casts = [
        'damage_photos' => 'array',
        'damage_cost' => 'decimal:2',
        'replacement_cost' => 'decimal:2',
        'returned_at' => 'datetime',
    ];

    /**
     * Get the booking for this return report.
     */
    public function booking(): BelongsTo
    {
        return $this->belongsTo(Booking::class);
    }

    /**
     * Get the allocation for this return report.
     */
    public function allocation(): BelongsTo
    {
        return $this->belongsTo(EventInventoryAllocation::class, 'event_inventory_allocation_id');
    }

    /**
     * Get the user who returned the items.
     */
    public function returnedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'returned_by');
    }

    /**
     * Get the inventory item through allocation.
     */
    public function inventoryItem()
    {
        return $this->allocation->inventoryItem();
    }

    /**
     * Get total cost impact (damage + replacement).
     */
    public function getTotalCostImpactAttribute(): float
    {
        return $this->damage_cost + $this->replacement_cost;
    }

    /**
     * Check if there are any issues (damage or missing items).
     */
    public function hasIssues(): bool
    {
        return $this->quantity_damaged > 0 || $this->quantity_missing > 0;
    }

    /**
     * Get condition color for UI.
     */
    public function getConditionColorAttribute(): string
    {
        return match($this->condition) {
            'excellent' => '#10b981',
            'good' => '#22c55e',
            'fair' => '#f59e0b',
            'poor' => '#ef4444',
            'damaged' => '#dc2626',
            default => '#6b7280'
        };
    }

    /**
     * Scope for reports with issues.
     */
    public function scopeWithIssues($query)
    {
        return $query->where(function($q) {
            $q->where('quantity_damaged', '>', 0)
              ->orWhere('quantity_missing', '>', 0);
        });
    }

    /**
     * Scope for reports by date range.
     */
    public function scopeInDateRange($query, $startDate, $endDate)
    {
        return $query->whereBetween('returned_at', [$startDate, $endDate]);
    }

    /**
     * Scope for reports by condition.
     */
    public function scopeByCondition($query, $condition)
    {
        return $query->where('condition', $condition);
    }
}
