<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class EventInventoryAllocation extends Model
{
    use HasFactory;

    protected $fillable = [
        'booking_id',
        'inventory_item_id',
        'quantity_allocated',
        'quantity_returned',
        'quantity_damaged',
        'quantity_missing',
        'status',
        'notes',
        'allocated_at',
        'returned_at',
    ];

    protected $casts = [
        'allocated_at' => 'datetime',
        'returned_at' => 'datetime',
    ];

    /**
     * Get the booking that owns this allocation.
     */
    public function booking(): BelongsTo
    {
        return $this->belongsTo(Booking::class);
    }

    /**
     * Get the inventory item for this allocation.
     */
    public function inventoryItem(): BelongsTo
    {
        return $this->belongsTo(InventoryItem::class);
    }

    /**
     * Get the return reports for this allocation.
     */
    public function returnReports(): HasMany
    {
        return $this->hasMany(InventoryReturnReport::class);
    }

    /**
     * Get the quantity still in use (allocated - returned).
     */
    public function getQuantityInUseAttribute(): int
    {
        return $this->quantity_allocated - $this->quantity_returned;
    }

    /**
     * Get the quantity outstanding (including damaged and missing).
     */
    public function getQuantityOutstandingAttribute(): int
    {
        return $this->quantity_allocated - ($this->quantity_returned + $this->quantity_damaged + $this->quantity_missing);
    }

    /**
     * Check if allocation is fully returned.
     */
    public function isFullyReturned(): bool
    {
        return $this->quantity_returned + $this->quantity_damaged + $this->quantity_missing >= $this->quantity_allocated;
    }

    /**
     * Update allocation status based on return quantities.
     */
    public function updateStatus(): void
    {
        if ($this->isFullyReturned()) {
            $this->status = 'returned';
        } elseif ($this->quantity_returned > 0) {
            $this->status = 'partially_returned';
        } elseif ($this->booking->status === 'confirmed' || $this->booking->status === 'in_progress') {
            $this->status = 'in_use';
        } else {
            $this->status = 'allocated';
        }
        
        $this->save();
    }

    /**
     * Scope for active allocations.
     */
    public function scopeActive($query)
    {
        return $query->whereIn('status', ['allocated', 'in_use', 'partially_returned']);
    }

    /**
     * Scope for allocations by booking.
     */
    public function scopeForBooking($query, $bookingId)
    {
        return $query->where('booking_id', $bookingId);
    }

    /**
     * Scope for allocations by inventory item.
     */
    public function scopeForItem($query, $itemId)
    {
        return $query->where('inventory_item_id', $itemId);
    }
}
