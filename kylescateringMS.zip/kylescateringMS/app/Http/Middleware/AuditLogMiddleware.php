<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\AuditLog;
use Illuminate\Support\Facades\Auth;

class AuditLogMiddleware
{
    /**
     * Handle an incoming request and log API activities.
     */
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);

        // Only log authenticated requests to avoid spam
        if (Auth::check()) {
            $this->logApiActivity($request, $response);
        }

        return $response;
    }

    /**
     * Log API activity based on request patterns.
     */
    private function logApiActivity(Request $request, $response)
    {
        $user = Auth::user();
        $method = $request->method();
        $path = $request->path();
        $statusCode = $response->getStatusCode();

        // Skip logging for certain endpoints to avoid noise
        $skipPaths = [
            'api/v1/notifications',
            'api/v1/user',
            'api/v1/dashboard/stats'
        ];

        foreach ($skipPaths as $skipPath) {
            if (str_contains($path, $skipPath)) {
                return;
            }
        }

        // Determine action and description based on request
        $action = $this->determineAction($method, $path, $statusCode);
        $description = $this->generateDescription($method, $path, $statusCode, $request);

        if ($action && $description) {
            AuditLog::log($action, $description, [
                'method' => $method,
                'path' => $path,
                'status_code' => $statusCode,
                'request_data' => $this->sanitizeRequestData($request)
            ]);
        }
    }

    /**
     * Determine the audit action based on request details.
     */
    private function determineAction(string $method, string $path, int $statusCode): ?string
    {
        // Only log successful operations (2xx status codes)
        if ($statusCode < 200 || $statusCode >= 300) {
            return null;
        }

        // Booking actions
        if (str_contains($path, 'bookings')) {
            if ($method === 'POST') return 'booking_created';
            if ($method === 'PUT' || $method === 'PATCH') return 'booking_updated';
            if ($method === 'DELETE') return 'booking_deleted';
        }

        // Staff actions
        if (str_contains($path, 'staff')) {
            if ($method === 'POST') return 'staff_created';
            if ($method === 'PUT' || $method === 'PATCH') return 'staff_updated';
            if ($method === 'DELETE') return 'staff_deleted';
        }

        // Inventory actions
        if (str_contains($path, 'inventory')) {
            if ($method === 'POST' && !str_contains($path, 'reserve') && !str_contains($path, 'return')) {
                return 'inventory_created';
            }
            if ($method === 'PUT' || $method === 'PATCH') return 'inventory_updated';
            if ($method === 'DELETE') return 'inventory_deleted';
            if (str_contains($path, 'reserve')) return 'inventory_reserved';
            if (str_contains($path, 'return')) return 'inventory_returned';
        }

        // Profile actions
        if (str_contains($path, 'profile') && ($method === 'PUT' || $method === 'PATCH' || $method === 'POST')) {
            return 'profile_updated';
        }

        return null;
    }

    /**
     * Generate a human-readable description.
     */
    private function generateDescription(string $method, string $path, int $statusCode, Request $request): ?string
    {
        $user = Auth::user();

        // Booking descriptions
        if (str_contains($path, 'bookings')) {
            if ($method === 'POST') {
                $eventName = $request->input('event_name', 'Unknown Event');
                return "Created new booking: {$eventName}";
            }
            if ($method === 'PUT' || $method === 'PATCH') {
                return "Updated booking details";
            }
            if ($method === 'DELETE') {
                return "Deleted a booking";
            }
        }

        // Staff descriptions
        if (str_contains($path, 'staff')) {
            if ($method === 'POST') {
                $staffName = $request->input('name', 'Unknown Staff');
                return "Created new staff member: {$staffName}";
            }
            if ($method === 'PUT' || $method === 'PATCH') {
                return "Updated staff member details";
            }
            if ($method === 'DELETE') {
                return "Deleted a staff member";
            }
        }

        // Inventory descriptions
        if (str_contains($path, 'inventory')) {
            if ($method === 'POST' && !str_contains($path, 'reserve') && !str_contains($path, 'return')) {
                $itemName = $request->input('name', 'Unknown Item');
                return "Created new inventory item: {$itemName}";
            }
            if ($method === 'PUT' || $method === 'PATCH') {
                return "Updated inventory item";
            }
            if ($method === 'DELETE') {
                return "Deleted inventory item";
            }
            if (str_contains($path, 'reserve')) {
                return "Reserved inventory items for event";
            }
            if (str_contains($path, 'return')) {
                return "Processed inventory return";
            }
        }

        // Profile descriptions
        if (str_contains($path, 'profile') && ($method === 'PUT' || $method === 'PATCH' || $method === 'POST')) {
            return "Updated profile information";
        }

        return null;
    }

    /**
     * Sanitize request data for logging (remove sensitive information).
     */
    private function sanitizeRequestData(Request $request): array
    {
        $data = $request->except([
            'password',
            'password_confirmation',
            'current_password',
            'token',
            '_token'
        ]);

        // Limit data size to prevent large logs
        $jsonData = json_encode($data);
        if (strlen($jsonData) > 1000) {
            return ['note' => 'Request data too large to log'];
        }

        return $data;
    }
}
