<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class TaskApiController extends Controller
{
    /**
     * Get all tasks for a specific date or date range
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'date' => 'nullable|date',
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
                'status' => 'nullable|in:pending,in_progress,completed,cancelled',
                'type' => 'nullable|in:meeting,food_tasting,client_meeting,consultation,other',
                'limit' => 'nullable|integer|min:1|max:100'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $query = Task::with(['user:id,first_name,last_name,email', 'creator:id,first_name,last_name,email']);

            // Filter by specific date
            if ($request->has('date')) {
                $query->whereDate('task_date', $request->date);
            }
            // Filter by date range
            elseif ($request->has('start_date') && $request->has('end_date')) {
                $query->whereBetween('task_date', [$request->start_date, $request->end_date]);
            }
            // Default to upcoming tasks (next 30 days)
            else {
                $query->whereBetween('task_date', [now()->toDateString(), now()->addDays(30)->toDateString()]);
            }

            // Additional filters
            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('type')) {
                $query->where('type', $request->type);
            }

            // Order by date and time
            $query->orderBy('task_date')->orderBy('task_time');

            // Apply limit
            $limit = $request->get('limit', 50);
            $tasks = $query->limit($limit)->get();

            // Format tasks for mobile app
            $formattedTasks = $tasks->map(function ($task) {
                return $this->formatTaskForApi($task);
            });

            return response()->json([
                'success' => true,
                'data' => [
                    'tasks' => $formattedTasks,
                    'count' => $formattedTasks->count(),
                    'filters_applied' => $request->only(['date', 'start_date', 'end_date', 'status', 'type'])
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve tasks',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Create a new task
     */
    public function store(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'title' => 'required|string|max:255',
                'description' => 'nullable|string|max:1000',
                'task_date' => 'required|date|after_or_equal:today',
                'task_time' => 'required|date_format:H:i',
                'type' => 'required|string|in:meeting,food_tasting,client_meeting,consultation,other',
                'user_id' => 'nullable|exists:users,id'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $taskData = $validator->validated();
            $taskData['created_by'] = Auth::id();
            $taskData['status'] = 'pending';

            // Combine date and time for proper datetime storage
            $taskDateTime = Carbon::createFromFormat('Y-m-d H:i', $taskData['task_date'] . ' ' . $taskData['task_time']);
            $taskData['task_time'] = $taskDateTime->format('H:i:s');

            $task = Task::create($taskData);
            $task->load(['user:id,first_name,last_name,email', 'creator:id,first_name,last_name,email']);

            return response()->json([
                'success' => true,
                'message' => 'Task created successfully',
                'data' => [
                    'task' => $this->formatTaskForApi($task)
                ]
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create task',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Get a specific task
     */
    public function show(Task $task): JsonResponse
    {
        try {
            $task->load(['user:id,first_name,last_name,email', 'creator:id,first_name,last_name,email']);

            return response()->json([
                'success' => true,
                'data' => [
                    'task' => $this->formatTaskForApi($task)
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve task',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Update a task
     */
    public function update(Request $request, Task $task): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'title' => 'sometimes|required|string|max:255',
                'description' => 'nullable|string|max:1000',
                'task_date' => 'sometimes|required|date',
                'task_time' => 'sometimes|required|date_format:H:i',
                'type' => 'sometimes|required|string|in:meeting,food_tasting,client_meeting,consultation,other',
                'status' => 'sometimes|required|string|in:pending,in_progress,completed,cancelled',
                'user_id' => 'nullable|exists:users,id'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $updateData = $validator->validated();

            // Handle time formatting if provided
            if (isset($updateData['task_date']) && isset($updateData['task_time'])) {
                $taskDateTime = Carbon::createFromFormat('Y-m-d H:i', $updateData['task_date'] . ' ' . $updateData['task_time']);
                $updateData['task_time'] = $taskDateTime->format('H:i:s');
            } elseif (isset($updateData['task_time'])) {
                $taskDateTime = Carbon::createFromFormat('Y-m-d H:i', $task->task_date->format('Y-m-d') . ' ' . $updateData['task_time']);
                $updateData['task_time'] = $taskDateTime->format('H:i:s');
            }

            $task->update($updateData);
            $task->load(['user:id,first_name,last_name,email', 'creator:id,first_name,last_name,email']);

            return response()->json([
                'success' => true,
                'message' => 'Task updated successfully',
                'data' => [
                    'task' => $this->formatTaskForApi($task)
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update task',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Delete a task
     */
    public function destroy(Task $task): JsonResponse
    {
        try {
            $task->delete();

            return response()->json([
                'success' => true,
                'message' => 'Task deleted successfully'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete task',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Mark task as complete
     */
    public function markComplete(Task $task): JsonResponse
    {
        try {
            $task->update(['status' => 'completed']);
            $task->load(['user:id,first_name,last_name,email', 'creator:id,first_name,last_name,email']);

            return response()->json([
                'success' => true,
                'message' => 'Task marked as completed',
                'data' => [
                    'task' => $this->formatTaskForApi($task)
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to complete task',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Get upcoming tasks (next 7 days)
     */
    public function upcoming(): JsonResponse
    {
        try {
            $tasks = Task::with(['user:id,first_name,last_name,email', 'creator:id,first_name,last_name,email'])
                ->upcoming()
                ->limit(20)
                ->get();

            $formattedTasks = $tasks->map(function ($task) {
                return $this->formatTaskForApi($task);
            });

            return response()->json([
                'success' => true,
                'data' => [
                    'tasks' => $formattedTasks,
                    'count' => $formattedTasks->count()
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve upcoming tasks',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Get task statistics
     */
    public function statistics(): JsonResponse
    {
        try {
            $stats = [
                'total_tasks' => Task::count(),
                'pending_tasks' => Task::where('status', 'pending')->count(),
                'in_progress_tasks' => Task::where('status', 'in_progress')->count(),
                'completed_tasks' => Task::where('status', 'completed')->count(),
                'cancelled_tasks' => Task::where('status', 'cancelled')->count(),
                'upcoming_tasks' => Task::upcoming()->count(),
                'overdue_tasks' => Task::where('task_date', '<', now()->toDateString())
                    ->whereNotIn('status', ['completed', 'cancelled'])
                    ->count(),
                'tasks_by_type' => [
                    'meeting' => Task::where('type', 'meeting')->count(),
                    'client_meeting' => Task::where('type', 'client_meeting')->count(),
                    'food_tasting' => Task::where('type', 'food_tasting')->count(),
                    'consultation' => Task::where('type', 'consultation')->count(),
                    'other' => Task::where('type', 'other')->count(),
                ]
            ];

            return response()->json([
                'success' => true,
                'data' => $stats
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve statistics',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Get available users for task assignment
     */
    public function getUsers(): JsonResponse
    {
        try {
            $users = User::select('id', 'first_name', 'last_name', 'email', 'role')
                ->where('role', '!=', 'customer')
                ->orderBy('first_name')
                ->get();

            return response()->json([
                'success' => true,
                'data' => [
                    'users' => $users
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve users',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Format task data for API response
     */
    private function formatTaskForApi(Task $task): array
    {
        return [
            'id' => $task->id,
            'title' => $task->title,
            'description' => $task->description,
            'task_date' => $task->task_date->format('Y-m-d'),
            'task_time' => Carbon::parse($task->task_time)->format('H:i'),
            'formatted_date' => $task->task_date->format('M j, Y'),
            'formatted_time' => Carbon::parse($task->task_time)->format('g:i A'),
            'formatted_datetime' => $task->task_date->format('M j, Y') . ' at ' . Carbon::parse($task->task_time)->format('g:i A'),
            'type' => $task->type,
            'type_label' => ucfirst(str_replace('_', ' ', $task->type)),
            'status' => $task->status,
            'status_label' => ucfirst($task->status),
            'reminder_sent' => $task->reminder_sent,
            'user' => $task->user ? [
                'id' => $task->user->id,
                'name' => $task->user->first_name . ' ' . $task->user->last_name,
                'email' => $task->user->email
            ] : null,
            'creator' => [
                'id' => $task->creator->id,
                'name' => $task->creator->first_name . ' ' . $task->creator->last_name,
                'email' => $task->creator->email
            ],
            'created_at' => $task->created_at->toISOString(),
            'updated_at' => $task->updated_at->toISOString(),
        ];
    }
}
