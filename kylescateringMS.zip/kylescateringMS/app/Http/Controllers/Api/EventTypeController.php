<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\EventType;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class EventTypeController extends Controller
{
    /**
     * Display a listing of event types.
     */
    public function index(Request $request): JsonResponse
    {
        $query = EventType::query();

        // Filter by active status if requested
        if ($request->has('active_only') && $request->active_only) {
            $query->active();
        }

        // Order by sort_order and name
        $eventTypes = $query->ordered()->get();

        return response()->json([
            'success' => true,
            'event_types' => $eventTypes
        ]);
    }

    /**
     * Store a newly created event type.
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255|unique:event_types',
            'icon' => 'nullable|string|max:100',
            'color' => 'nullable|string|max:7',
            'description' => 'nullable|string|max:1000',
            'is_active' => 'boolean',
            'sort_order' => 'integer|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $eventType = EventType::create($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Event type created successfully',
            'event_type' => $eventType
        ], 201);
    }

    /**
     * Display the specified event type.
     */
    public function show(EventType $eventType): JsonResponse
    {
        return response()->json([
            'success' => true,
            'event_type' => $eventType
        ]);
    }

    /**
     * Update the specified event type.
     */
    public function update(Request $request, EventType $eventType): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|string|max:255|unique:event_types,name,' . $eventType->id,
            'icon' => 'nullable|string|max:100',
            'color' => 'nullable|string|max:7',
            'description' => 'nullable|string|max:1000',
            'is_active' => 'boolean',
            'sort_order' => 'integer|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $eventType->update($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Event type updated successfully',
            'event_type' => $eventType
        ]);
    }

    /**
     * Remove the specified event type.
     */
    public function destroy(EventType $eventType): JsonResponse
    {
        // Check if event type is being used by any bookings
        $bookingCount = $eventType->bookings()->count();
        
        if ($bookingCount > 0) {
            return response()->json([
                'success' => false,
                'message' => "Cannot delete event type. It is being used by {$bookingCount} booking(s)."
            ], 422);
        }

        $eventType->delete();

        return response()->json([
            'success' => true,
            'message' => 'Event type deleted successfully'
        ]);
    }
}
