<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class StaffController extends Controller
{
    /**
     * Display a listing of staff members (Admin only).
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        // Only admin can view staff list
        if ($user->role !== 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Admin access required.'
            ], 403);
        }

        $staff = User::where('role', 'staff')
            ->select('id', 'name', 'first_name', 'last_name', 'email', 'phone', 'department', 'address', 'role', 'is_first_login', 'profile_picture', 'email_verified_at', 'created_at', 'updated_at')
            ->latest()
            ->paginate(15);

        return response()->json([
            'success' => true,
            'staff' => $staff->items(),
            'pagination' => [
                'current_page' => $staff->currentPage(),
                'last_page' => $staff->lastPage(),
                'per_page' => $staff->perPage(),
                'total' => $staff->total(),
            ]
        ]);
    }

    /**
     * Store a newly created staff member (Admin only).
     */
    public function store(Request $request): JsonResponse
    {
        $user = $request->user();

        // Only admin can create staff
        if ($user->role !== 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Admin access required.'
            ], 403);
        }

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'first_name' => 'nullable|string|max:255',
            'last_name' => 'nullable|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $staff = User::create([
            'name' => $request->name,
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'staff',
            'email_verified_at' => now(), // Auto-verify staff accounts
        ]);

        // Log staff creation
        AuditLog::log(
            'staff_created',
            "New staff member created: {$staff->name} ({$staff->email})",
            [
                'staff_id' => $staff->id,
                'staff_name' => $staff->name,
                'staff_email' => $staff->email
            ]
        );

        return response()->json([
            'success' => true,
            'message' => 'Staff member created successfully',
            'staff' => [
                'id' => $staff->id,
                'name' => $staff->name,
                'first_name' => $staff->first_name,
                'last_name' => $staff->last_name,
                'email' => $staff->email,
                'role' => $staff->role,
                'created_at' => $staff->created_at,
            ]
        ], 201);
    }

    /**
     * Display the specified staff member (Admin only).
     */
    public function show(Request $request, User $staff): JsonResponse
    {
        $user = $request->user();

        // Only admin can view staff details
        if ($user->role !== 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Admin access required.'
            ], 403);
        }

        // Ensure the user is actually a staff member
        if ($staff->role !== 'staff') {
            return response()->json([
                'success' => false,
                'message' => 'User is not a staff member'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'staff' => [
                'id' => $staff->id,
                'name' => $staff->name,
                'first_name' => $staff->first_name,
                'last_name' => $staff->last_name,
                'email' => $staff->email,
                'role' => $staff->role,
                'created_at' => $staff->created_at,
                'email_verified_at' => $staff->email_verified_at,
            ]
        ]);
    }

    /**
     * Update the specified staff member (Admin only).
     */
    public function update(Request $request, User $staff): JsonResponse
    {
        $user = $request->user();

        // Only admin can update staff
        if ($user->role !== 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Admin access required.'
            ], 403);
        }

        // Ensure the user is actually a staff member
        if ($staff->role !== 'staff') {
            return response()->json([
                'success' => false,
                'message' => 'User is not a staff member'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|string|max:255',
            'first_name' => 'sometimes|nullable|string|max:255',
            'last_name' => 'sometimes|nullable|string|max:255',
            'email' => 'sometimes|string|email|max:255|unique:users,email,' . $staff->id,
            'password' => 'sometimes|string|min:8',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $updateData = $request->only(['name', 'first_name', 'last_name', 'email']);

        if ($request->has('password')) {
            $updateData['password'] = Hash::make($request->password);
        }

        // Store old values for audit log
        $oldValues = $staff->only(array_keys($updateData));
        $staff->update($updateData);

        // Log staff update
        $changedFields = array_keys(array_diff_assoc($updateData, $oldValues));
        if (!empty($changedFields)) {
            // Don't log password in audit
            $logFields = array_filter($changedFields, fn($field) => $field !== 'password');
            if ($request->has('password')) {
                $logFields[] = 'password';
            }
            
            AuditLog::log(
                'staff_updated',
                "Staff member updated: {$staff->name} - Changed fields: " . implode(', ', $logFields),
                [
                    'staff_id' => $staff->id,
                    'staff_name' => $staff->name,
                    'changed_fields' => $logFields
                ]
            );
        }

        return response()->json([
            'success' => true,
            'message' => 'Staff member updated successfully',
            'staff' => [
                'id' => $staff->id,
                'name' => $staff->name,
                'first_name' => $staff->first_name,
                'last_name' => $staff->last_name,
                'email' => $staff->email,
                'role' => $staff->role,
                'created_at' => $staff->created_at,
            ]
        ]);
    }

    /**
     * Remove the specified staff member (Admin only).
     */
    public function destroy(Request $request, User $staff): JsonResponse
    {
        $user = $request->user();

        // Only admin can delete staff
        if ($user->role !== 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Admin access required.'
            ], 403);
        }

        // Ensure the user is actually a staff member
        if ($staff->role !== 'staff') {
            return response()->json([
                'success' => false,
                'message' => 'User is not a staff member'
            ], 404);
        }

        // Don't allow deletion if staff has bookings or assignments
        $bookingsCount = $staff->bookings()->count();
        $assignmentsCount = $staff->staffAssignments()->count();
        
        if ($bookingsCount > 0 || $assignmentsCount > 0) {
            $message = 'Cannot delete staff member with existing ';
            if ($bookingsCount > 0 && $assignmentsCount > 0) {
                $message .= 'bookings and assignments';
            } elseif ($bookingsCount > 0) {
                $message .= 'bookings';
            } else {
                $message .= 'assignments';
            }
            
            return response()->json([
                'success' => false,
                'message' => $message
            ], 422);
        }

        // Log staff deletion before deleting
        AuditLog::log(
            'staff_deleted',
            "Staff member deleted: {$staff->name} ({$staff->email})",
            [
                'staff_id' => $staff->id,
                'staff_name' => $staff->name,
                'staff_email' => $staff->email
            ]
        );

        $staff->delete();

        return response()->json([
            'success' => true,
            'message' => 'Staff member deleted successfully'
        ]);
    }
}
