<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /**
     * Login user and return token
     */
    public function login(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $credentials = $request->only('email', 'password');

        if (!Auth::attempt($credentials)) {
            // Log failed login attempt
            $user = User::where('email', $request->email)->first();
            if ($user) {
                AuditLog::create([
                    'user_id' => $user->id,
                    'user_name' => $user->name,
                    'action' => 'login_failed',
                    'description' => "Failed login attempt for user: {$user->name} ({$user->email})",
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->userAgent(),
                    'metadata' => ['email' => $request->email]
                ]);
            } else {
                // Log attempt with non-existent email
                AuditLog::create([
                    'user_id' => 0, // Use 0 for system/unknown user
                    'user_name' => 'Unknown',
                    'action' => 'login_failed',
                    'description' => "Failed login attempt with non-existent email: {$request->email}",
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->userAgent(),
                    'metadata' => ['email' => $request->email]
                ]);
            }
            
            return response()->json([
                'success' => false,
                'message' => 'Invalid credentials'
            ], 401);
        }

        $user = Auth::user();
        $token = $user->createToken('mobile-app')->plainTextToken;

        // Log successful login
        AuditLog::log(
            'login',
            "User {$user->name} logged in successfully",
            ['user_id' => $user->id, 'login_method' => 'mobile_app']
        );

        return response()->json([
            'success' => true,
            'message' => 'Login successful',
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role ?? 'staff', // Default to staff if no role set
                'is_first_login' => $user->is_first_login ?? true,
                'profile_picture' => $user->profile_picture,
                'email_verified_at' => $user->email_verified_at,
                'created_at' => $user->created_at,
            ]
        ]);
    }

    /**
     * Register a new user
     */
    public function register(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'role' => 'sometimes|string|in:admin,staff,customer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => $request->role ?? 'customer',
        ]);

        // Log user registration
        AuditLog::log(
            'user_registered',
            "New user registered: {$user->name} ({$user->email}) with role: {$user->role}",
            [
                'user_id' => $user->id,
                'user_name' => $user->name,
                'user_email' => $user->email,
                'user_role' => $user->role
            ]
        );

        $token = $user->createToken('mobile-app')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Registration successful',
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
                'is_first_login' => $user->is_first_login ?? true,
                'profile_picture' => $user->profile_picture,
                'email_verified_at' => $user->email_verified_at,
                'created_at' => $user->created_at,
            ]
        ], 201);
    }

    /**
     * Logout user (revoke token)
     */
    public function logout(Request $request): JsonResponse
    {
        $user = $request->user();
        
        // Log logout before deleting token
        AuditLog::log(
            'logout',
            "User {$user->name} logged out",
            ['user_id' => $user->id]
        );
        
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'success' => true,
            'message' => 'Logout successful'
        ]);
    }

    /**
     * Get authenticated user
     */
    public function user(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'success' => true,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role ?? 'staff',
                'is_first_login' => $user->is_first_login ?? true,
                'profile_picture' => $user->profile_picture,
                'email_verified_at' => $user->email_verified_at,
                'created_at' => $user->created_at,
            ]
        ]);
    }

    /**
     * Update user profile
     */
    public function updateProfile(Request $request): JsonResponse
    {
        $user = $request->user();

        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|string|email|max:255|unique:users,email,' . $user->id,
            'password' => 'sometimes|string|min:8|confirmed',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $updateData = [];
        
        if ($request->has('name')) {
            $updateData['name'] = $request->name;
        }
        
        if ($request->has('email')) {
            $updateData['email'] = $request->email;
            $updateData['email_verified_at'] = null; // Reset email verification
        }
        
        if ($request->has('password')) {
            $updateData['password'] = Hash::make($request->password);
        }

        $user->update($updateData);

        return response()->json([
            'success' => true,
            'message' => 'Profile updated successfully',
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role ?? 'staff',
                'email_verified_at' => $user->email_verified_at,
                'created_at' => $user->created_at,
            ]
        ]);
    }

    /**
     * Send password reset link using PHPMailer
     */
    public function forgotPassword(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            // Find the user
            $user = User::where('email', $request->email)->first();
            
            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found'
                ], 404);
            }

            // Generate password reset token
            $token = Str::random(60);
            
            // Store token in password_reset_tokens table
            DB::table('password_reset_tokens')->updateOrInsert(
                ['email' => $request->email],
                [
                    'email' => $request->email,
                    'token' => Hash::make($token),
                    'created_at' => Carbon::now()
                ]
            );

            // Send password reset email using our custom notification
            $user->sendPasswordResetNotification($token);

            // Log password reset request
            AuditLog::log(
                'password_reset_requested',
                "Password reset requested for user: {$user->name} ({$user->email})",
                [
                    'user_id' => $user->id,
                    'email' => $user->email,
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->userAgent()
                ]
            );

            return response()->json([
                'success' => true,
                'message' => 'Password reset link sent to your email'
            ]);

        } catch (\Exception $e) {
            \Log::error('Forgot password error: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Unable to send password reset link. Please try again later.'
            ], 500);
        }
    }

    /**
     * Reset password using custom token validation
     */
    public function resetPassword(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            // Find the user
            $user = User::where('email', $request->email)->first();
            
            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found'
                ], 404);
            }

            // Check if token exists and is valid
            $passwordReset = DB::table('password_reset_tokens')
                ->where('email', $request->email)
                ->first();

            if (!$passwordReset) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid or expired token'
                ], 400);
            }

            // Check if token matches
            if (!Hash::check($request->token, $passwordReset->token)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid token'
                ], 400);
            }

            // Check if token is not expired (60 minutes)
            $tokenAge = Carbon::parse($passwordReset->created_at)->diffInMinutes(Carbon::now());
            if ($tokenAge > 60) {
                // Delete expired token
                DB::table('password_reset_tokens')->where('email', $request->email)->delete();
                
                return response()->json([
                    'success' => false,
                    'message' => 'Token has expired. Please request a new password reset.'
                ], 400);
            }

            // Update user password
            $user->forceFill([
                'password' => Hash::make($request->password),
                'remember_token' => Str::random(60),
            ])->save();

            // Delete the used token
            DB::table('password_reset_tokens')->where('email', $request->email)->delete();

            // Log password reset
            AuditLog::log(
                'password_reset',
                "Password reset successful for user: {$user->name} ({$user->email})",
                [
                    'user_id' => $user->id,
                    'email' => $user->email,
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->userAgent()
                ]
            );

            return response()->json([
                'success' => true,
                'message' => 'Password reset successful. You can now login with your new password.'
            ]);

        } catch (\Exception $e) {
            \Log::error('Password reset error: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Password reset failed. Please try again.'
            ], 500);
        }
    }

    /**
     * Get dashboard statistics (for admin/staff)
     */
    public function dashboardStats(Request $request): JsonResponse
    {
        $user = $request->user();
        
        // Import Booking model
        $bookingModel = new \App\Models\Booking();
        
        // Get booking statistics
        if ($user->role === 'admin') {
            // Admin can see all bookings
            $totalBookings = \App\Models\Booking::count();
            $pendingBookings = \App\Models\Booking::where('status', 'pending')->count();
            $confirmedBookings = \App\Models\Booking::where('status', 'confirmed')->count();
            $completedBookings = \App\Models\Booking::where('status', 'completed')->count();
            $cancelledBookings = \App\Models\Booking::where('status', 'cancelled')->count();
            $totalRevenue = \App\Models\Booking::whereIn('status', ['confirmed', 'completed'])
                ->sum('estimated_cost') ?? 0;
        } else {
            // Staff can only see their own bookings
            $totalBookings = $user->bookings()->count();
            $pendingBookings = $user->bookings()->where('status', 'pending')->count();
            $confirmedBookings = $user->bookings()->where('status', 'confirmed')->count();
            $completedBookings = $user->bookings()->where('status', 'completed')->count();
            $cancelledBookings = $user->bookings()->where('status', 'cancelled')->count();
            $totalRevenue = $user->bookings()->whereIn('status', ['confirmed', 'completed'])
                ->sum('estimated_cost') ?? 0;
        }
        
        $stats = [
            'total_events' => $totalBookings,
            'pending_events' => $pendingBookings,
            'confirmed_events' => $confirmedBookings,
            'completed_events' => $completedBookings,
            'cancelled_events' => $cancelledBookings,
            'total_revenue' => (float) $totalRevenue,
        ];

        // Add role-specific stats for admin
        if ($user->role === 'admin') {
            $stats['total_staff'] = User::where('role', 'staff')->count();
            $stats['total_users'] = User::count();
            $stats['recent_bookings'] = \App\Models\Booking::with('user')
                ->latest()
                ->limit(5)
                ->get()
                ->map(function ($booking) {
                    return [
                        'id' => $booking->id,
                        'event_name' => $booking->event_name,
                        'event_date' => $booking->event_date,
                        'status' => $booking->status,
                        'estimated_cost' => $booking->estimated_cost,
                        'user_name' => $booking->user->name ?? 'Unknown',
                    ];
                });
        }

        return response()->json([
            'success' => true,
            'stats' => $stats
        ]);
    }
}
