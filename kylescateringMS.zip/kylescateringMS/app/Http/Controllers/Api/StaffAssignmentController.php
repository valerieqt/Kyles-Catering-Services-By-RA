<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\NotificationController;
use App\Models\StaffAssignment;
use App\Models\Booking;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class StaffAssignmentController extends Controller
{
    /**
     * Get all assignments for the authenticated staff member
     */
    public function index(Request $request)
    {
        try {
            $user = Auth::user();
            
            // If user is staff, get their assignments
            if ($user->role === 'staff') {
                $assignments = StaffAssignment::with(['booking', 'staff'])
                    ->forStaff($user->id)
                    ->orderBy('assigned_at', 'desc')
                    ->get();
            } 
            // If user is admin, get all assignments
            else if ($user->role === 'admin') {
                $assignments = StaffAssignment::with(['booking', 'staff'])
                    ->orderBy('assigned_at', 'desc')
                    ->get();
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized access'
                ], 403);
            }

            // Transform assignments to match frontend interface
            $transformedAssignments = $assignments->map(function ($assignment) {
                return [
                    'id' => $assignment->id,
                    'eventTitle' => $assignment->booking->event_name,
                    'eventType' => $assignment->booking->event_type ?? 'other',
                    'date' => $assignment->booking->event_date->format('Y-m-d'),
                    'startTime' => $assignment->booking->event_time,
                    'endTime' => $this->calculateEndTime($assignment->booking->event_time),
                    'location' => $assignment->booking->venue,
                    'guests' => $assignment->booking->guest_count,
                    'role' => $assignment->role,
                    'status' => $assignment->status,
                    'description' => $assignment->booking->additional_details,
                    'requirements' => $assignment->requirements ?? [],
                    'contactPerson' => $assignment->booking->user->name ?? 'N/A',
                    'contactPhone' => $assignment->booking->contact_phone,
                    'notes' => $assignment->notes,
                ];
            });

            return response()->json([
                'success' => true,
                'assignments' => $transformedAssignments
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error fetching assignments: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Create a new staff assignment (Admin only)
     */
    public function store(Request $request)
    {
        try {
            $user = Auth::user();
            
            if ($user->role !== 'admin') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only administrators can create staff assignments'
                ], 403);
            }

            $validated = $request->validate([
                'staff_id' => 'required|exists:users,id',
                'booking_id' => 'required|exists:bookings,id',
                'role' => 'required|string|max:255',
                'notes' => 'nullable|string',
                'requirements' => 'nullable|array',
            ]);

            // Check if staff member has the correct role
            $staff = User::find($validated['staff_id']);
            if ($staff->role !== 'staff') {
                return response()->json([
                    'success' => false,
                    'message' => 'Selected user is not a staff member'
                ], 400);
            }

            // Check if assignment already exists with the same role
            $existingAssignment = StaffAssignment::where('staff_id', $validated['staff_id'])
                ->where('booking_id', $validated['booking_id'])
                ->where('role', $validated['role'])
                ->first();

            if ($existingAssignment) {
                return response()->json([
                    'success' => false,
                    'message' => 'Staff member is already assigned to this event with the same role'
                ], 400);
            }

            $assignment = StaffAssignment::create($validated);

            // Create notification for the assigned staff member
            $booking = Booking::find($validated['booking_id']);
            NotificationController::createNotification(
                $validated['staff_id'], // to staff member
                $user->id, // from admin
                'staff_assignment',
                'New Event Assignment',
                "You have been assigned to '{$booking->event_name}' as {$validated['role']} on {$booking->event_date}.",
                [
                    'assignment_id' => $assignment->id,
                    'booking_id' => $booking->id,
                    'role' => $validated['role']
                ]
            );

            return response()->json([
                'success' => true,
                'message' => 'Staff assignment created successfully',
                'assignment' => $assignment->load(['booking', 'staff'])
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error creating assignment: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update assignment status (Staff can confirm/decline)
     */
    public function updateStatus(Request $request, $id)
    {
        try {
            $user = Auth::user();
            $assignment = StaffAssignment::findOrFail($id);

            // Staff can only update their own assignments
            if ($user->role === 'staff' && $assignment->staff_id !== $user->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'You can only update your own assignments'
                ], 403);
            }

            $validated = $request->validate([
                'status' => ['required', Rule::in(['pending', 'confirmed', 'declined', 'completed'])],
                'notes' => 'nullable|string',
            ]);

            $assignment->update([
                'status' => $validated['status'],
                'notes' => $validated['notes'] ?? $assignment->notes,
                'responded_at' => now(),
            ]);

            // Create notification for admin when staff declines assignment
            if ($validated['status'] === 'declined') {
                $booking = $assignment->booking;
                $staff = $assignment->staff;
                
                // Find admin users to notify
                $admins = User::where('role', 'admin')->get();
                foreach ($admins as $admin) {
                    NotificationController::createNotification(
                        $admin->id, // to admin
                        $user->id, // from staff member
                        'assignment_declined',
                        'Staff Assignment Declined',
                        "{$staff->name} has declined the assignment for '{$booking->event_name}' on {$booking->event_date}.",
                        [
                            'assignment_id' => $assignment->id,
                            'booking_id' => $booking->id,
                            'staff_name' => $staff->name,
                            'role' => $assignment->role,
                            'decline_reason' => $validated['notes']
                        ]
                    );
                }
            }
            // Create notification for admin when staff confirms assignment
            elseif ($validated['status'] === 'confirmed') {
                $booking = $assignment->booking;
                $staff = $assignment->staff;
                
                // Find admin users to notify
                $admins = User::where('role', 'admin')->get();
                foreach ($admins as $admin) {
                    NotificationController::createNotification(
                        $admin->id, // to admin
                        $user->id, // from staff member
                        'assignment_confirmed',
                        'Staff Assignment Confirmed',
                        "{$staff->name} has confirmed the assignment for '{$booking->event_name}' on {$booking->event_date}.",
                        [
                            'assignment_id' => $assignment->id,
                            'booking_id' => $booking->id,
                            'staff_name' => $staff->name,
                            'role' => $assignment->role
                        ]
                    );
                }
            }

            return response()->json([
                'success' => true,
                'message' => 'Assignment status updated successfully',
                'assignment' => $assignment->load(['booking', 'staff'])
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error updating assignment: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get assignments for a specific date
     */
    public function getByDate(Request $request, $date)
    {
        try {
            $user = Auth::user();
            
            if ($user->role === 'staff') {
                $assignments = StaffAssignment::with(['booking', 'staff'])
                    ->forStaff($user->id)
                    ->forDate($date)
                    ->get();
            } else if ($user->role === 'admin') {
                $assignments = StaffAssignment::with(['booking', 'staff'])
                    ->forDate($date)
                    ->get();
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized access'
                ], 403);
            }

            return response()->json([
                'success' => true,
                'assignments' => $assignments
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error fetching assignments: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get assignments for a specific booking
     */
    public function getByBooking(Request $request, $bookingId)
    {
        try {
            $user = Auth::user();
            
            if ($user->role !== 'admin') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only administrators can view booking assignments'
                ], 403);
            }

            $assignments = StaffAssignment::with(['booking', 'staff'])
                ->where('booking_id', $bookingId)
                ->get();

            return response()->json([
                'success' => true,
                'assignments' => $assignments
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error fetching assignments: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete an assignment (Admin only)
     */
    public function destroy($id)
    {
        try {
            $user = Auth::user();
            
            if ($user->role !== 'admin') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only administrators can delete assignments'
                ], 403);
            }

            $assignment = StaffAssignment::findOrFail($id);
            $assignment->delete();

            return response()->json([
                'success' => true,
                'message' => 'Assignment deleted successfully'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error deleting assignment: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Calculate end time based on start time (helper method)
     */
    private function calculateEndTime($startTime)
    {
        // Default to 4 hours duration if not specified
        $start = \Carbon\Carbon::createFromFormat('H:i', $startTime);
        return $start->addHours(4)->format('H:i');
    }
}
