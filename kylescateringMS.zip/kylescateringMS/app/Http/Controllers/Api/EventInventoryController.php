<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\EventInventoryAllocation;
use App\Models\InventoryItem;
use App\Models\InventoryReturnReport;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class EventInventoryController extends Controller
{
    /**
     * Get inventory allocations for a specific booking.
     */
    public function getBookingAllocations(Request $request, $bookingId): JsonResponse
    {
        try {
            $allocations = EventInventoryAllocation::with(['inventoryItem', 'returnReports'])
                ->forBooking($bookingId)
                ->get();

            return response()->json([
                'success' => true,
                'allocations' => $allocations
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch allocations: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Allocate inventory items to an event.
     */
    public function allocateInventory(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'booking_id' => 'required|exists:bookings,id',
            'items' => 'required|array|min:1',
            'items.*.inventory_item_id' => 'required|exists:inventory_items,id',
            'items.*.quantity' => 'required|integer|min:1',
            'items.*.notes' => 'nullable|string|max:500'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            DB::beginTransaction();

            $booking = Booking::findOrFail($request->booking_id);
            $allocatedItems = [];

            foreach ($request->items as $item) {
                $inventoryItem = InventoryItem::findOrFail($item['inventory_item_id']);
                
                // Check if enough quantity is available
                if ($inventoryItem->available_quantity < $item['quantity']) {
                    throw new \Exception("Insufficient quantity for {$inventoryItem->name}. Available: {$inventoryItem->available_quantity}, Requested: {$item['quantity']}");
                }

                // Create allocation
                $allocation = EventInventoryAllocation::create([
                    'booking_id' => $booking->id,
                    'inventory_item_id' => $inventoryItem->id,
                    'quantity_allocated' => $item['quantity'],
                    'notes' => $item['notes'] ?? null,
                    'allocated_at' => now(),
                    'status' => 'allocated'
                ]);

                // Update inventory quantities
                $inventoryItem->available_quantity -= $item['quantity'];
                $inventoryItem->reserved_quantity += $item['quantity'];
                $inventoryItem->save();

                $allocatedItems[] = $allocation->load('inventoryItem');

                // Log the allocation
                AuditLog::log(
                    'inventory_allocated',
                    "Allocated {$item['quantity']} units of {$inventoryItem->name} to event: {$booking->event_name}",
                    [
                        'booking_id' => $booking->id,
                        'inventory_item_id' => $inventoryItem->id,
                        'quantity_allocated' => $item['quantity'],
                        'allocation_id' => $allocation->id
                    ]
                );
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Inventory allocated successfully',
                'allocations' => $allocatedItems
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to allocate inventory: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Return inventory items from an event.
     */
    public function returnInventory(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'allocation_id' => 'required|exists:event_inventory_allocations,id',
            'quantity_returned' => 'required|integer|min:0',
            'quantity_damaged' => 'integer|min:0',
            'quantity_missing' => 'integer|min:0',
            'damage_description' => 'nullable|string|max:1000',
            'missing_description' => 'nullable|string|max:1000',
            'general_notes' => 'nullable|string|max:1000',
            'condition' => 'required|in:excellent,good,fair,poor,damaged',
            'damage_cost' => 'numeric|min:0',
            'replacement_cost' => 'numeric|min:0',
            'damage_photos' => 'nullable|array',
            'damage_photos.*' => 'string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            DB::beginTransaction();

            $allocation = EventInventoryAllocation::with(['inventoryItem', 'booking'])->findOrFail($request->allocation_id);
            $inventoryItem = $allocation->inventoryItem;
            
            $quantityReturned = $request->quantity_returned ?? 0;
            $quantityDamaged = $request->quantity_damaged ?? 0;
            $quantityMissing = $request->quantity_missing ?? 0;
            
            $totalProcessed = $quantityReturned + $quantityDamaged + $quantityMissing;
            $maxAllowed = $allocation->quantity_allocated - $allocation->quantity_returned - $allocation->quantity_damaged - $allocation->quantity_missing;

            if ($totalProcessed > $maxAllowed) {
                throw new \Exception("Total return quantity ({$totalProcessed}) exceeds available quantity ({$maxAllowed})");
            }

            // Create return report
            $returnReport = InventoryReturnReport::create([
                'booking_id' => $allocation->booking_id,
                'event_inventory_allocation_id' => $allocation->id,
                'returned_by' => Auth::id(),
                'quantity_returned' => $quantityReturned,
                'quantity_damaged' => $quantityDamaged,
                'quantity_missing' => $quantityMissing,
                'damage_description' => $request->damage_description,
                'missing_description' => $request->missing_description,
                'general_notes' => $request->general_notes,
                'damage_photos' => $request->damage_photos,
                'damage_cost' => $request->damage_cost ?? 0,
                'replacement_cost' => $request->replacement_cost ?? 0,
                'condition' => $request->condition,
                'returned_at' => now()
            ]);

            // Update allocation quantities
            $allocation->quantity_returned += $quantityReturned;
            $allocation->quantity_damaged += $quantityDamaged;
            $allocation->quantity_missing += $quantityMissing;
            
            if ($allocation->isFullyReturned()) {
                $allocation->returned_at = now();
            }
            
            $allocation->updateStatus();

            // Update inventory quantities
            $inventoryItem->available_quantity += $quantityReturned;
            $inventoryItem->reserved_quantity -= ($quantityReturned + $quantityDamaged + $quantityMissing);
            $inventoryItem->damaged_quantity += $quantityDamaged;
            $inventoryItem->lost_quantity += $quantityMissing;
            $inventoryItem->save();

            // Log the return
            AuditLog::log(
                'inventory_returned',
                "Returned inventory for {$inventoryItem->name} from event: {$allocation->booking->event_name}",
                [
                    'booking_id' => $allocation->booking_id,
                    'inventory_item_id' => $inventoryItem->id,
                    'quantity_returned' => $quantityReturned,
                    'quantity_damaged' => $quantityDamaged,
                    'quantity_missing' => $quantityMissing,
                    'condition' => $request->condition,
                    'return_report_id' => $returnReport->id
                ]
            );

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Inventory returned successfully',
                'return_report' => $returnReport->load(['allocation.inventoryItem', 'returnedBy'])
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to return inventory: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get return reports with optional filters.
     */
    public function getReturnReports(Request $request): JsonResponse
    {
        try {
            $query = InventoryReturnReport::with(['booking', 'allocation.inventoryItem', 'returnedBy']);

            // Apply filters
            if ($request->has('booking_id')) {
                $query->where('booking_id', $request->booking_id);
            }

            if ($request->has('condition')) {
                $query->byCondition($request->condition);
            }

            if ($request->has('with_issues') && $request->with_issues) {
                $query->withIssues();
            }

            if ($request->has('start_date') && $request->has('end_date')) {
                $query->inDateRange($request->start_date, $request->end_date);
            }

            $reports = $query->orderBy('returned_at', 'desc')->paginate(20);

            return response()->json([
                'success' => true,
                'reports' => $reports
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch return reports: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get inventory allocation statistics.
     */
    public function getAllocationStats(Request $request): JsonResponse
    {
        try {
            $stats = [
                'total_allocations' => EventInventoryAllocation::count(),
                'active_allocations' => EventInventoryAllocation::active()->count(),
                'total_items_allocated' => EventInventoryAllocation::sum('quantity_allocated'),
                'total_items_returned' => EventInventoryAllocation::sum('quantity_returned'),
                'total_items_damaged' => EventInventoryAllocation::sum('quantity_damaged'),
                'total_items_missing' => EventInventoryAllocation::sum('quantity_missing'),
                'total_damage_cost' => InventoryReturnReport::sum('damage_cost'),
                'total_replacement_cost' => InventoryReturnReport::sum('replacement_cost'),
            ];

            // Recent activity
            $recentAllocations = EventInventoryAllocation::with(['booking', 'inventoryItem'])
                ->orderBy('allocated_at', 'desc')
                ->limit(5)
                ->get();

            $recentReturns = InventoryReturnReport::with(['booking', 'allocation.inventoryItem'])
                ->orderBy('returned_at', 'desc')
                ->limit(5)
                ->get();

            return response()->json([
                'success' => true,
                'stats' => $stats,
                'recent_allocations' => $recentAllocations,
                'recent_returns' => $recentReturns
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch statistics: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get available inventory for allocation.
     */
    public function getAvailableInventory(Request $request): JsonResponse
    {
        try {
            $query = InventoryItem::where('available_quantity', '>', 0);

            if ($request->has('category')) {
                $query->byCategory($request->category);
            }

            if ($request->has('search')) {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('description', 'like', "%{$search}%");
                });
            }

            $items = $query->orderBy('name')->get();

            return response()->json([
                'success' => true,
                'items' => $items
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch available inventory: ' . $e->getMessage()
            ], 500);
        }
    }
}
