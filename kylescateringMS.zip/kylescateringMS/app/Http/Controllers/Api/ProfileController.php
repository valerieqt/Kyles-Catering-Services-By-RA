<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class ProfileController extends Controller
{
    /**
     * Display the user's profile information.
     */
    public function show(Request $request): JsonResponse
    {
        $user = $request->user();

        return response()->json([
            'success' => true,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'phone' => $user->phone,
                'company' => $user->company,
                'address' => $user->address,
                'department' => $user->department,
                'role' => $user->role ?? 'staff',
                'is_first_login' => $user->is_first_login ?? true,
                'profile_picture' => $user->profile_picture,
                'email_verified_at' => $user->email_verified_at,
                'created_at' => $user->created_at,
                'updated_at' => $user->updated_at,
            ]
        ]);
    }

    /**
     * Update the user's profile information.
     */
    public function update(Request $request): JsonResponse
    {
        $user = $request->user();

        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|string|email|max:255|unique:users,email,' . $user->id,
            'phone' => 'sometimes|string|max:20|nullable',
            'company' => 'sometimes|string|max:255|nullable',
            'address' => 'sometimes|string|max:500|nullable',
            'department' => 'sometimes|string|max:255|nullable',
            'current_password' => 'sometimes|required_with:password|string',
            'password' => 'sometimes|string|min:8|confirmed',
            'profile_picture' => 'sometimes|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $updateData = [];

        // Update name if provided
        if ($request->has('name')) {
            $updateData['name'] = $request->name;
        }

        // Update email if provided
        if ($request->has('email')) {
            $updateData['email'] = $request->email;
            $updateData['email_verified_at'] = null; // Reset email verification
        }

        // Update additional profile fields if provided
        if ($request->has('phone')) {
            $updateData['phone'] = $request->phone;
        }

        if ($request->has('company')) {
            $updateData['company'] = $request->company;
        }

        if ($request->has('address')) {
            $updateData['address'] = $request->address;
        }

        if ($request->has('department')) {
            $updateData['department'] = $request->department;
        }

        // Handle profile picture upload
        if ($request->hasFile('profile_picture')) {
            $file = $request->file('profile_picture');
            $filename = time() . '_' . $user->id . '.' . $file->getClientOriginalExtension();
            
            // Store in public/storage/profile_pictures directory
            $path = $file->storeAs('profile_pictures', $filename, 'public');
            $updateData['profile_picture'] = $path;
            
            // Delete old profile picture if exists
            if ($user->profile_picture && \Storage::disk('public')->exists($user->profile_picture)) {
                \Storage::disk('public')->delete($user->profile_picture);
            }
        }

        // Update password if provided
        if ($request->has('password')) {
            // Verify current password
            if (!Hash::check($request->current_password, $user->password)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Current password is incorrect'
                ], 422);
            }

            $updateData['password'] = Hash::make($request->password);
            // Mark first login as complete when password is changed
            $updateData['is_first_login'] = false;
        }

        // Store old values for audit log
        $oldValues = $user->only(array_keys($updateData));
        
        // Update user
        $user->update($updateData);

        // Log profile update
        $changedFields = array_keys(array_diff_assoc($updateData, $oldValues));
        if (!empty($changedFields)) {
            // Don't log password in audit, but note that it was changed
            $logFields = array_filter($changedFields, fn($field) => $field !== 'password');
            if (in_array('password', $changedFields)) {
                $logFields[] = 'password';
            }
            
            AuditLog::log(
                'profile_updated',
                "Profile updated - Changed fields: " . implode(', ', $logFields),
                [
                    'changed_fields' => $logFields,
                    'password_changed' => in_array('password', $changedFields)
                ]
            );
        }

        return response()->json([
            'success' => true,
            'message' => 'Profile updated successfully',
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'phone' => $user->phone,
                'company' => $user->company,
                'address' => $user->address,
                'department' => $user->department,
                'role' => $user->role ?? 'staff',
                'is_first_login' => $user->is_first_login ?? true,
                'profile_picture' => $user->profile_picture,
                'email_verified_at' => $user->email_verified_at,
                'created_at' => $user->created_at,
                'updated_at' => $user->updated_at,
            ]
        ]);
    }

    /**
     * Delete the user's account.
     */
    public function destroy(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $user = $request->user();

        // Verify password before deletion
        if (!Hash::check($request->password, $user->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Password is incorrect'
            ], 422);
        }

        // Delete all user's tokens
        $user->tokens()->delete();

        // Delete user account
        $user->delete();

        return response()->json([
            'success' => true,
            'message' => 'Account deleted successfully'
        ]);
    }
}
