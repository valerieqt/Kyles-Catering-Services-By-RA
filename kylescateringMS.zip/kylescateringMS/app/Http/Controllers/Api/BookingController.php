<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\AuditLog;
use App\Services\BookingEmailService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class BookingController extends Controller
{
    protected $bookingEmailService;

    public function __construct(BookingEmailService $bookingEmailService)
    {
        $this->bookingEmailService = $bookingEmailService;
    }

    /**
     * Display a listing of the user's bookings.
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();
        
        // Admin can see all bookings, staff/users can only see their own
        if ($user->role === 'admin') {
            $bookings = Booking::with('user')->latest()->paginate(15);
        } else {
            $bookings = $user->bookings()->latest()->paginate(15);
        }

        return response()->json([
            'success' => true,
            'bookings' => $bookings->items(),
            'pagination' => [
                'current_page' => $bookings->currentPage(),
                'last_page' => $bookings->lastPage(),
                'per_page' => $bookings->perPage(),
                'total' => $bookings->total(),
            ]
        ]);
    }

    /**
     * Store a newly created booking.
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'event_name' => 'required|string|max:255',
            'event_date' => 'required|date|after:today',
            'event_time' => 'required|string',
            'guest_count' => 'required|integer|min:1',
            'venue' => 'required|string|max:255',
            'contact_phone' => 'required|string|max:20',
            'special_requests' => 'nullable|string|max:1000',
            'menu_preferences' => 'nullable|string|max:1000',
            'event_type' => 'nullable|string|max:100',
            'package_type' => 'nullable|string|max:100',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $booking = $request->user()->bookings()->create([
            'event_name' => $request->event_name,
            'event_date' => $request->event_date,
            'event_time' => $request->event_time,
            'guest_count' => $request->guest_count,
            'venue' => $request->venue,
            'contact_phone' => $request->contact_phone,
            'special_requests' => $request->special_requests,
            'menu_preferences' => $request->menu_preferences,
            'event_type' => $request->event_type,
            'package_type' => $request->package_type,
            'status' => 'pending',
        ]);

        // Log booking creation
        AuditLog::log(
            'booking_created',
            "New booking created: {$booking->event_name} for {$booking->guest_count} guests on {$booking->event_date}",
            [
                'booking_id' => $booking->id,
                'event_name' => $booking->event_name,
                'event_date' => $booking->event_date,
                'guest_count' => $booking->guest_count,
                'venue' => $booking->venue
            ]
        );

        // Send confirmation email
        $this->bookingEmailService->sendBookingConfirmation($booking);

        return response()->json([
            'success' => true,
            'message' => 'Booking created successfully. Confirmation email sent.',
            'booking' => $booking
        ], 201);
    }

    /**
     * Display the specified booking.
     */
    public function show(Request $request, Booking $booking): JsonResponse
    {
        $user = $request->user();

        // Check if user can view this booking
        if ($user->role !== 'admin' && $booking->user_id !== $user->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized to view this booking'
            ], 403);
        }

        $booking->load('user');

        return response()->json([
            'success' => true,
            'booking' => $booking
        ]);
    }

    /**
     * Update the specified booking.
     */
    public function update(Request $request, Booking $booking): JsonResponse
    {
        $user = $request->user();

        // Check if user can update this booking
        if ($user->role !== 'admin' && $booking->user_id !== $user->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized to update this booking'
            ], 403);
        }

        // Don't allow updates to confirmed/completed bookings unless admin
        if ($user->role !== 'admin' && in_array($booking->status, ['confirmed', 'completed'])) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot update confirmed or completed bookings'
            ], 422);
        }

        $validator = Validator::make($request->all(), [
            'event_name' => 'sometimes|string|max:255',
            'event_date' => 'sometimes|date',
            'event_time' => 'sometimes|string',
            'guest_count' => 'sometimes|integer|min:1',
            'venue' => 'sometimes|string|max:255',
            'contact_phone' => 'sometimes|string|max:20',
            'special_requests' => 'nullable|string|max:1000',
            'menu_preferences' => 'nullable|string|max:1000',
            'event_type' => 'sometimes|string|max:100',
            'package_type' => 'sometimes|string|max:100',
            'status' => 'sometimes|string|in:pending,confirmed,cancelled,completed',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $updateData = $request->only([
            'event_name', 'event_date', 'event_time', 'guest_count',
            'venue', 'contact_phone', 'special_requests', 'menu_preferences',
            'event_type', 'package_type', 'status'
        ]);

        // Only admin can update status
        if ($user->role === 'admin' && $request->has('status')) {
            $updateData['status'] = $request->status;
        }

        // Store old values for audit log
        $oldValues = $booking->only(array_keys($updateData));
        $booking->update($updateData);

        // Log booking update
        $changedFields = array_keys(array_diff_assoc($updateData, $oldValues));
        if (!empty($changedFields)) {
            AuditLog::log(
                'booking_updated',
                "Booking updated: {$booking->event_name} - Changed fields: " . implode(', ', $changedFields),
                [
                    'booking_id' => $booking->id,
                    'changed_fields' => $changedFields,
                    'old_values' => $oldValues,
                    'new_values' => $updateData
                ]
            );
        }

        return response()->json([
            'success' => true,
            'message' => 'Booking updated successfully',
            'booking' => $booking
        ]);
    }

    /**
     * Remove the specified booking.
     */
    public function destroy(Request $request, Booking $booking): JsonResponse
    {
        $user = $request->user();

        // Check if user can delete this booking
        if ($user->role !== 'admin' && $booking->user_id !== $user->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized to delete this booking'
            ], 403);
        }

        // Don't allow deletion of confirmed/completed bookings unless admin
        if ($user->role !== 'admin' && in_array($booking->status, ['confirmed', 'completed'])) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot delete confirmed or completed bookings'
            ], 422);
        }

        // Log booking deletion before deleting
        AuditLog::log(
            'booking_deleted',
            "Booking deleted: {$booking->event_name} scheduled for {$booking->event_date}",
            [
                'booking_id' => $booking->id,
                'event_name' => $booking->event_name,
                'event_date' => $booking->event_date,
                'status' => $booking->status
            ]
        );

        $booking->delete();

        return response()->json([
            'success' => true,
            'message' => 'Booking deleted successfully'
        ]);
    }

    /**
     * Reschedule a booking.
     */
    public function reschedule(Request $request, Booking $booking): JsonResponse
    {
        $user = $request->user();

        // Check if user can reschedule this booking
        if ($user->role !== 'admin' && $booking->user_id !== $user->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized to reschedule this booking'
            ], 403);
        }

        // Don't allow rescheduling of completed bookings
        if ($booking->status === 'completed') {
            return response()->json([
                'success' => false,
                'message' => 'Cannot reschedule completed bookings'
            ], 422);
        }

        $validator = Validator::make($request->all(), [
            'event_date' => 'required|date|after:today',
            'event_time' => 'required|string',
            'reschedule_reason' => 'nullable|string|max:500'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $oldDate = $booking->event_date;
        $oldTime = $booking->event_time;

        $booking->update([
            'event_date' => $request->event_date,
            'event_time' => $request->event_time,
            'status' => 'pending' // Reset to pending for admin review
        ]);

        // Log booking reschedule
        AuditLog::log(
            'booking_rescheduled',
            "Booking rescheduled: {$booking->event_name} from {$oldDate} {$oldTime} to {$booking->event_date} {$booking->event_time}",
            [
                'booking_id' => $booking->id,
                'old_date' => $oldDate,
                'old_time' => $oldTime,
                'new_date' => $booking->event_date,
                'new_time' => $booking->event_time,
                'reason' => $request->reschedule_reason ?? 'No reason provided'
            ]
        );

        // Send reschedule confirmation email
        $this->bookingEmailService->sendRescheduleConfirmation($booking, $oldDate, $oldTime);

        return response()->json([
            'success' => true,
            'message' => 'Booking rescheduled successfully. Confirmation email sent.',
            'booking' => $booking
        ]);
    }

    /**
     * Cancel a booking.
     */
    public function cancel(Request $request, Booking $booking): JsonResponse
    {
        $user = $request->user();

        // Check if user can cancel this booking
        if ($user->role !== 'admin' && $booking->user_id !== $user->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized to cancel this booking'
            ], 403);
        }

        // Don't allow cancellation of completed bookings
        if ($booking->status === 'completed') {
            return response()->json([
                'success' => false,
                'message' => 'Cannot cancel completed bookings'
            ], 422);
        }

        $validator = Validator::make($request->all(), [
            'cancellation_reason' => 'nullable|string|max:500'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $booking->update([
            'status' => 'cancelled'
        ]);

        // Log booking cancellation
        AuditLog::log(
            'booking_cancelled',
            "Booking cancelled: {$booking->event_name} scheduled for {$booking->event_date}",
            [
                'booking_id' => $booking->id,
                'event_name' => $booking->event_name,
                'event_date' => $booking->event_date,
                'reason' => $request->cancellation_reason ?? 'No reason provided'
            ]
        );

        // Send cancellation confirmation email
        $this->bookingEmailService->sendCancellationConfirmation($booking);

        return response()->json([
            'success' => true,
            'message' => 'Booking cancelled successfully. Confirmation email sent.',
            'booking' => $booking
        ]);
    }

    /**
     * Mark a booking as completed (Admin only).
     */
    public function markCompleted(Request $request, Booking $booking): JsonResponse
    {
        $user = $request->user();

        // Only admins can mark bookings as completed
        if ($user->role !== 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Only admins can mark bookings as completed.'
            ], 403);
        }

        // Don't allow completing already completed or cancelled bookings
        if ($booking->status === 'completed') {
            return response()->json([
                'success' => false,
                'message' => 'Booking is already marked as completed.'
            ], 422);
        }

        if ($booking->status === 'cancelled') {
            return response()->json([
                'success' => false,
                'message' => 'Cannot complete a cancelled booking.'
            ], 422);
        }

        $validator = Validator::make($request->all(), [
            'completion_notes' => 'nullable|string|max:1000'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $oldStatus = $booking->status;
        $completedAt = now();

        $booking->update([
            'status' => 'completed',
            'completed_at' => $completedAt,
            'completion_notes' => $request->completion_notes
        ]);

        // Log booking completion
        AuditLog::log(
            'booking_completed',
            "Booking marked as completed: {$booking->event_name} on {$booking->event_date}",
            [
                'booking_id' => $booking->id,
                'event_name' => $booking->event_name,
                'event_date' => $booking->event_date,
                'old_status' => $oldStatus,
                'completed_by' => $user->id,
                'completed_by_name' => $user->name,
                'completed_at' => $completedAt,
                'completion_notes' => $request->completion_notes ?? 'No notes provided'
            ]
        );

        return response()->json([
            'success' => true,
            'message' => 'Booking marked as completed successfully.',
            'booking' => $booking->fresh(),
            'completed_at' => $completedAt->format('Y-m-d H:i:s'),
            'completed_by' => $user->name
        ]);
    }

    /**
     * Get booking history and statistics (Admin only).
     */
    public function getBookingHistory(Request $request): JsonResponse
    {
        $user = $request->user();

        // Only admins can view booking history
        if ($user->role !== 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Only admins can view booking history.'
            ], 403);
        }

        $validator = Validator::make($request->all(), [
            'status' => 'nullable|in:pending,confirmed,completed,cancelled',
            'date_from' => 'nullable|date',
            'date_to' => 'nullable|date|after_or_equal:date_from',
            'per_page' => 'nullable|integer|min:1|max:100'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $query = Booking::with(['user']);

        // Filter by status
        if ($request->status) {
            $query->where('status', $request->status);
        }

        // Filter by date range
        if ($request->date_from) {
            $query->where('event_date', '>=', $request->date_from);
        }
        if ($request->date_to) {
            $query->where('event_date', '<=', $request->date_to);
        }

        $perPage = $request->per_page ?? 20;
        $bookings = $query->orderBy('event_date', 'desc')->paginate($perPage);

        // Get statistics
        $stats = [
            'total_bookings' => Booking::count(),
            'pending_bookings' => Booking::where('status', 'pending')->count(),
            'confirmed_bookings' => Booking::where('status', 'confirmed')->count(),
            'completed_bookings' => Booking::where('status', 'completed')->count(),
            'cancelled_bookings' => Booking::where('status', 'cancelled')->count(),
            'this_month_completed' => Booking::where('status', 'completed')
                ->whereMonth('completed_at', now()->month)
                ->whereYear('completed_at', now()->year)
                ->count()
        ];

        return response()->json([
            'success' => true,
            'bookings' => $bookings,
            'statistics' => $stats
        ]);
    }
}
