<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\InventoryItem;
use App\Models\Category;
use App\Models\AuditLog;
use App\Models\EventInventory;
use App\Models\EventInventoryAllocation;
use App\Models\InventoryTransaction;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
class InventoryController extends Controller
{
    /**
     * Get all inventory items
     */
    public function index(Request $request): JsonResponse
    {
        try {
            // Check if inventory_items table exists
            if (!DB::getSchemaBuilder()->hasTable('inventory_items')) {
                return response()->json([
                    'success' => true,
                    'items' => [],
                    'pagination' => [
                        'current_page' => 1,
                        'last_page' => 1,
                        'per_page' => 15,
                        'total' => 0,
                    ],
                    'summary' => [
                        'total_items' => 0,
                        'total_value' => 0,
                        'low_stock_items' => 0,
                        'out_of_stock_items' => 0,
                    ],
                    'message' => 'Inventory tables not yet created. Please run migrations first.'
                ]);
            }

            $query = InventoryItem::query();

            // Apply filters
            if ($request->has('category') && $request->category !== '') {
                $query->where('category', $request->category);
            }

            // Note: status is an accessor, so we can't filter by it directly in the database
            // We'll filter after getting the results if needed
            
            if ($request->has('search') && $request->search !== '') {
                $search = $request->search;
                $query->where(function($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('description', 'like', "%{$search}%")
                      ->orWhere('location', 'like', "%{$search}%");
                });
            }

            // Apply sorting
            $sortBy = $request->get('sort', 'name');
            $sortOrder = $request->get('order', 'asc');
            
            // Validate sort parameters
            $allowedSorts = ['name', 'created_at', 'updated_at', 'category', 'total_quantity', 'available_quantity'];
            $sortBy = in_array($sortBy, $allowedSorts) ? $sortBy : 'name';
            $sortOrder = in_array($sortOrder, ['asc', 'desc']) ? $sortOrder : 'asc';
            
            // Get paginated results
            $perPage = $request->get('per_page', 15);
            $items = $query->orderBy($sortBy, $sortOrder)->paginate($perPage);

            // Apply status filter after getting results (since status is an accessor)
            if ($request->has('status') && $request->status !== '') {
                $filteredItems = $items->getCollection()->filter(function($item) use ($request) {
                    return $item->status === $request->status;
                });
                $items->setCollection($filteredItems);
            }

            // Calculate summary statistics using database queries (not accessors)
            $totalItems = InventoryItem::count();
            $totalValue = InventoryItem::sum(DB::raw('total_quantity * COALESCE(unit_cost, 0)'));
            $lowStockItems = InventoryItem::where('available_quantity', '<=', 10)->count();
            $outOfStockItems = InventoryItem::where('available_quantity', '<=', 0)->count();

            return response()->json([
                'success' => true,
                'items' => $items->items(),
                'pagination' => [
                    'current_page' => $items->currentPage(),
                    'last_page' => $items->lastPage(),
                    'per_page' => $items->perPage(),
                    'total' => $items->total(),
                ],
                'summary' => [
                    'total_items' => $totalItems,
                    'total_value' => $totalValue,
                    'low_stock_items' => $lowStockItems,
                    'out_of_stock_items' => $outOfStockItems,
                ]
            ]);
        } catch (\Exception $e) {
            \Log::error('Inventory index error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch inventory items',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get inventory statistics
     */
    public function stats(): JsonResponse
    {
        try {
            // Check if inventory_items table exists
            if (!DB::getSchemaBuilder()->hasTable('inventory_items')) {
                return response()->json([
                    'success' => true,
                    'stats' => [
                        'total_items' => 0,
                        'total_value' => 0,
                        'low_stock_items' => 0,
                        'out_of_stock_items' => 0,
                        'categories' => [],
                        'recent_transactions' => []
                    ],
                    'message' => 'Inventory tables not yet created. Please run migrations first.'
                ]);
            }

            $totalItems = InventoryItem::count();
            $totalValue = InventoryItem::sum(DB::raw('total_quantity * COALESCE(unit_cost, 0)'));
            $lowStockItems = InventoryItem::where('available_quantity', '<=', 10)->where('available_quantity', '>', 0)->count();
            $outOfStockItems = InventoryItem::where('available_quantity', '<=', 0)->count();
            
            // Get categories with metadata from categories table if it exists
            $categories = [];
            try {
                if (DB::getSchemaBuilder()->hasTable('categories') && class_exists('App\Models\Category')) {
                    $categories = Category::active()
                        ->ordered()
                        ->get()
                        ->map(function($category) {
                            return [
                                'name' => $category->name,
                                'icon' => $category->icon,
                                'color' => $category->color,
                                'description' => $category->description,
                                'item_count' => InventoryItem::where('category', $category->name)->count()
                            ];
                        });
                } else {
                    // Fallback to existing categories from inventory items
                    $categories = InventoryItem::select('category')
                        ->whereNotNull('category')
                        ->groupBy('category')
                        ->get()
                        ->pluck('category')
                        ->map(function($categoryName) {
                            return [
                                'name' => $categoryName,
                                'icon' => 'cube-outline',
                                'color' => '#7c2d12',
                                'description' => null,
                                'item_count' => InventoryItem::where('category', $categoryName)->count()
                            ];
                        });
                }
            } catch (\Exception $categoryError) {
                \Log::warning('Category loading error in stats: ' . $categoryError->getMessage());
                // Fallback to basic categories from inventory items
                $categories = InventoryItem::select('category')
                    ->whereNotNull('category')
                    ->groupBy('category')
                    ->get()
                    ->pluck('category')
                    ->map(function($categoryName) {
                        return [
                            'name' => $categoryName,
                            'icon' => 'cube-outline',
                            'color' => '#7c2d12',
                            'description' => null,
                            'item_count' => InventoryItem::where('category', $categoryName)->count()
                        ];
                    });
            }

            // Recent transactions (placeholder for future implementation)
            $recentTransactions = [];

            // Debug information
            $debugInfo = [
                'table_exists' => DB::getSchemaBuilder()->hasTable('inventory_items'),
                'categories_table_exists' => DB::getSchemaBuilder()->hasTable('categories'),
                'category_model_exists' => class_exists('App\Models\Category'),
                'raw_counts' => [
                    'total_items' => $totalItems,
                    'total_value_raw' => $totalValue,
                    'low_stock_items' => $lowStockItems,
                    'out_of_stock_items' => $outOfStockItems,
                ],
                'sample_items' => InventoryItem::limit(3)->get(['id', 'name', 'total_quantity', 'available_quantity', 'unit_cost'])
            ];

            return response()->json([
                'success' => true,
                'stats' => [
                    'total_items' => $totalItems,
                    'total_value' => round($totalValue ?? 0, 2),
                    'low_stock_items' => $lowStockItems,
                    'out_of_stock_items' => $outOfStockItems,
                    'categories' => $categories,
                    'recent_transactions' => $recentTransactions
                ],
                'debug' => $debugInfo
            ]);
        } catch (\Exception $e) {
            \Log::error('Inventory stats error: ' . $e->getMessage());
            \Log::error('Stack trace: ' . $e->getTraceAsString());
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch inventory statistics',
                'error' => $e->getMessage(),
                'debug' => [
                    'line' => $e->getLine(),
                    'file' => basename($e->getFile())
                ]
            ], 500);
        }
    }

    /**
     * Create new inventory item
     */
    public function store(Request $request): JsonResponse
    {
        try {
            // Check if inventory_items table exists
            if (!DB::getSchemaBuilder()->hasTable('inventory_items')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Inventory tables not yet created. Please run migrations first.',
                    'error' => 'Database tables missing'
                ], 500);
            }

            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'description' => 'nullable|string',
                'category' => 'required|string|max:255',
                'total_quantity' => 'required|integer|min:0',
                'unit_cost' => 'nullable|numeric|min:0',
                'condition' => 'nullable|string|in:good,fair,poor',
                'location' => 'nullable|string|max:255',
                'notes' => 'nullable|string'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $item = InventoryItem::create([
                'name' => $request->name,
                'description' => $request->description,
                'category' => $request->category,
                'total_quantity' => $request->total_quantity,
                'available_quantity' => $request->total_quantity, // Initially all available
                'unit_cost' => $request->unit_cost,
                'condition' => $request->condition ?? 'good',
                'location' => $request->location,
                'notes' => $request->notes
            ]);

            // Log the addition transaction (only if table exists)
            if (DB::getSchemaBuilder()->hasTable('inventory_transactions')) {
                InventoryTransaction::create([
                    'inventory_item_id' => $item->id,
                    'user_id' => $request->user()->id ?? null,
                    'type' => 'add',
                    'quantity' => $request->total_quantity,
                    'quantity_before' => 0,
                    'quantity_after' => $request->total_quantity,
                    'notes' => 'Initial inventory addition'
                ]);
            }

            // Log inventory item creation
            AuditLog::log(
                'inventory_created',
                "New inventory item created: {$item->name} (Qty: {$item->total_quantity})",
                [
                    'inventory_id' => $item->id,
                    'item_name' => $item->name,
                    'category' => $item->category,
                    'quantity' => $item->total_quantity,
                    'unit_cost' => $item->unit_cost
                ]
            );

            // Check for low stock notifications
            $this->checkLowStockNotifications($item);

            return response()->json([
                'success' => true,
                'message' => 'Inventory item created successfully',
                'item' => $item
            ], 201);
        } catch (\Exception $e) {
            \Log::error('Inventory store error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to create inventory item',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get specific inventory item
     */
    public function show($id): JsonResponse
    {
        try {
            // Check if inventory_items table exists
            if (!DB::getSchemaBuilder()->hasTable('inventory_items')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Inventory tables not yet created. Please run migrations first.',
                    'error' => 'Database tables missing'
                ], 500);
            }

            $item = InventoryItem::findOrFail($id);

            // Get recent activity from audit logs and event allocations
            $recentActivity = [];
            
            // Get audit logs related to this inventory item (limit search scope for performance)
            $auditLogs = AuditLog::where('metadata->inventory_item_id', $id)
            ->with('user')
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

            foreach ($auditLogs as $log) {
                $recentActivity[] = [
                    'id' => 'audit_' . $log->id,
                    'type' => $this->mapAuditActionToTransactionType($log->action),
                    'description' => $log->description,
                    'quantity' => $log->metadata['quantity'] ?? null,
                    'quantity_before' => null,
                    'quantity_after' => null,
                    'notes' => $log->description,
                    'created_at' => $log->created_at,
                    'user' => $log->user ? ['name' => $log->user->name] : null,
                    'booking' => isset($log->metadata['booking_id']) ? 
                        ['event_name' => $log->metadata['event_name'] ?? 'Event'] : null
                ];
            }

            // Get event allocations for this item
            if (DB::getSchemaBuilder()->hasTable('event_inventory_allocations')) {
                $allocations = \App\Models\EventInventoryAllocation::where('inventory_item_id', $id)
                    ->with(['booking', 'returnReports.returnedBy'])
                    ->orderBy('created_at', 'desc')
                    ->limit(5)
                    ->get();

                foreach ($allocations as $allocation) {
                    $recentActivity[] = [
                        'id' => 'allocation_' . $allocation->id,
                        'type' => 'reserve',
                        'description' => "Allocated {$allocation->quantity_allocated} items for {$allocation->booking->event_name}",
                        'quantity' => $allocation->quantity_allocated,
                        'quantity_before' => null,
                        'quantity_after' => null,
                        'notes' => $allocation->notes,
                        'created_at' => $allocation->created_at,
                        'user' => null,
                        'booking' => ['event_name' => $allocation->booking->event_name]
                    ];

                    // Add return activities
                    foreach ($allocation->returnReports as $return) {
                        $recentActivity[] = [
                            'id' => 'return_' . $return->id,
                            'type' => 'return',
                            'description' => "Returned {$return->quantity_returned} items from {$allocation->booking->event_name}",
                            'quantity' => $return->quantity_returned,
                            'quantity_before' => null,
                            'quantity_after' => null,
                            'notes' => $return->general_notes,
                            'created_at' => $return->created_at,
                            'user' => $return->returnedBy ? ['name' => $return->returnedBy->name] : null,
                            'booking' => ['event_name' => $allocation->booking->event_name]
                        ];
                    }
                }
            }

            // Sort all activities by date
            usort($recentActivity, function($a, $b) {
                return strtotime($b['created_at']) - strtotime($a['created_at']);
            });

            $item->transactions = array_slice($recentActivity, 0, 10);

            return response()->json([
                'success' => true,
                'item' => $item
            ]);
        } catch (\Exception $e) {
            \Log::error('Inventory show error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Inventory item not found',
                'error' => $e->getMessage()
            ], 404);
        }
    }

    /**
     * Update inventory item
     */
    public function update(Request $request, $id): JsonResponse
    {
        try {
            // Check if inventory_items table exists
            if (!DB::getSchemaBuilder()->hasTable('inventory_items')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Inventory tables not yet created. Please run migrations first.',
                    'error' => 'Database tables missing'
                ], 500);
            }

            $validator = Validator::make($request->all(), [
                'name' => 'sometimes|string|max:255',
                'description' => 'nullable|string',
                'category' => 'sometimes|string|max:255',
                'total_quantity' => 'sometimes|integer|min:0',
                'unit_cost' => 'nullable|numeric|min:0',
                'condition' => 'nullable|string|in:good,fair,poor',
                'location' => 'nullable|string|max:255',
                'notes' => 'nullable|string'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $item = InventoryItem::findOrFail($id);
            $oldQuantity = $item->total_quantity;
            $oldValues = $item->only(['name', 'description', 'category', 'total_quantity', 'unit_cost', 'condition', 'location', 'notes']);
            
            // Check if reducing total quantity below reserved quantity
            if ($request->has('total_quantity') && $request->total_quantity < $item->reserved_quantity) {
                return response()->json([
                    'success' => false,
                    'message' => "Cannot reduce total quantity below reserved quantity ({$item->reserved_quantity}). Please return equipment first."
                ], 400);
            }
            
            $updateData = $request->only([
                'name', 'description', 'category', 'total_quantity', 
                'unit_cost', 'condition', 'location', 'notes'
            ]);
            
            $item->update($updateData);

            // Log inventory update
            $changedFields = array_keys(array_diff_assoc($updateData, $oldValues));
            if (!empty($changedFields)) {
                AuditLog::log(
                    'inventory_updated',
                    "Inventory item updated: {$item->name} - Changed fields: " . implode(', ', $changedFields),
                    [
                        'inventory_id' => $item->id,
                        'item_name' => $item->name,
                        'changed_fields' => $changedFields,
                        'old_values' => array_intersect_key($oldValues, array_flip($changedFields)),
                        'new_values' => array_intersect_key($updateData, array_flip($changedFields))
                    ]
                );
            }

            // If total quantity changed, adjust available quantity and log transaction
            if ($request->has('total_quantity') && $request->total_quantity != $oldQuantity) {
                $quantityDiff = $request->total_quantity - $oldQuantity;
                $newAvailableQuantity = $item->available_quantity + $quantityDiff;
                
                // Ensure available quantity doesn't go negative
                $item->available_quantity = max(0, $newAvailableQuantity);
                $item->save();

                // Log transaction (only if table exists)
                if (DB::getSchemaBuilder()->hasTable('inventory_transactions')) {
                    InventoryTransaction::create([
                        'inventory_item_id' => $item->id,
                        'user_id' => $request->user()->id ?? null,
                        'type' => $quantityDiff > 0 ? 'add' : 'remove',
                        'quantity' => abs($quantityDiff),
                        'quantity_before' => $oldQuantity,
                        'quantity_after' => $request->total_quantity,
                        'notes' => 'Inventory quantity adjustment'
                    ]);
                }
            }

            // Check for low stock notifications after update
            $this->checkLowStockNotifications($item->fresh());

            return response()->json([
                'success' => true,
                'message' => 'Inventory item updated successfully',
                'item' => $item->fresh()
            ]);
        } catch (\Exception $e) {
            \Log::error('Inventory update error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to update inventory item',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete inventory item
     */
    public function destroy($id): JsonResponse
    {
        try {
            // Check if inventory_items table exists
            if (!DB::getSchemaBuilder()->hasTable('inventory_items')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Inventory tables not yet created. Please run migrations first.',
                    'error' => 'Database tables missing'
                ], 500);
            }

            $item = InventoryItem::findOrFail($id);
            
            // Check if item is currently reserved
            if ($item->reserved_quantity > 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot delete item with active reservations'
                ], 400);
            }

            // Log inventory deletion before deleting
            AuditLog::log(
                'inventory_deleted',
                "Inventory item deleted: {$item->name} (Category: {$item->category})",
                [
                    'inventory_id' => $item->id,
                    'item_name' => $item->name,
                    'category' => $item->category,
                    'total_quantity' => $item->total_quantity,
                    'available_quantity' => $item->available_quantity
                ]
            );

            $item->delete();

            return response()->json([
                'success' => true,
                'message' => 'Inventory item deleted successfully'
            ]);
        } catch (\Exception $e) {
            \Log::error('Inventory delete error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete inventory item',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Reserve items for an event
     */
    public function reserveForEvent(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'booking_id' => 'required|exists:bookings,id',
            'items' => 'required|array',
            'items.*.inventory_item_id' => 'required|exists:inventory_items,id',
            'items.*.quantity' => 'required|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            DB::beginTransaction();

            $reservations = [];
            
            foreach ($request->items as $itemData) {
                $item = InventoryItem::findOrFail($itemData['inventory_item_id']);
                
                if (!$item->canReserve($itemData['quantity'])) {
                    DB::rollBack();
                    return response()->json([
                        'success' => false,
                        'message' => "Insufficient quantity for {$item->name}. Available: {$item->available_quantity}, Requested: {$itemData['quantity']}"
                    ], 400);
                }

                // Reserve the item
                $item->reserve($itemData['quantity'], $request->booking_id, $request->user()->id);

                // Create event inventory record
                $reservation = EventInventory::create([
                    'booking_id' => $request->booking_id,
                    'inventory_item_id' => $item->id,
                    'quantity_reserved' => $itemData['quantity'],
                    'status' => 'reserved',
                    'reserved_at' => now()
                ]);

                // Check for low stock notifications after reservation
                $this->checkLowStockNotifications($item->fresh());

                $reservations[] = $reservation->load('inventoryItem');
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Items reserved successfully',
                'reservations' => $reservations
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to reserve items',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get event inventory
     */
    public function getEventInventory($bookingId): JsonResponse
    {
        try {
            $eventInventory = EventInventory::with('inventoryItem')
                ->where('booking_id', $bookingId)
                ->get();

            return response()->json([
                'success' => true,
                'event_inventory' => $eventInventory
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch event inventory',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Process equipment return
     */
    public function processReturn(Request $request, $eventInventoryId): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'quantity_returned' => 'required|integer|min:0',
            'quantity_damaged' => 'nullable|integer|min:0',
            'quantity_lost' => 'nullable|integer|min:0',
            'damage_notes' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $eventInventory = EventInventory::findOrFail($eventInventoryId);
            
            $quantityReturned = $request->quantity_returned ?? 0;
            $quantityDamaged = $request->quantity_damaged ?? 0;
            $quantityLost = $request->quantity_lost ?? 0;
            
            $totalProcessed = $quantityReturned + $quantityDamaged + $quantityLost;
            $outstanding = $eventInventory->quantity_outstanding;
            
            if ($totalProcessed > $outstanding) {
                return response()->json([
                    'success' => false,
                    'message' => "Total processed quantity ({$totalProcessed}) exceeds outstanding quantity ({$outstanding})"
                ], 400);
            }

            $eventInventory->processReturn(
                $quantityReturned,
                $quantityDamaged,
                $quantityLost,
                $request->damage_notes,
                $request->user()->id
            );

            return response()->json([
                'success' => true,
                'message' => 'Equipment return processed successfully',
                'event_inventory' => $eventInventory->fresh()
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to process return',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get inventory reports
     */
    public function reports(Request $request): JsonResponse
    {
        try {
            $startDate = $request->start_date ?? now()->subMonth()->format('Y-m-d');
            $endDate = $request->end_date ?? now()->format('Y-m-d');
            
            // Convert to datetime format for better querying
            $startDateTime = $startDate . ' 00:00:00';
            $endDateTime = $endDate . ' 23:59:59';

            // Check if tables exist
            if (!DB::getSchemaBuilder()->hasTable('inventory_items')) {
                return response()->json([
                    'success' => true,
                    'reports' => [
                        'damage_and_loss' => [],
                        'utilization' => [],
                        'period' => [
                            'start_date' => $startDate,
                            'end_date' => $endDate
                        ]
                    ],
                    'message' => 'Inventory tables not yet created. Please run migrations first.'
                ]);
            }

            // Damage and loss report from event inventory allocations
            $damageReport = collect([]);
            if (DB::getSchemaBuilder()->hasTable('event_inventory_allocations')) {
                // Get all allocations with damage/missing items, regardless of when damage was recorded
                $damageReport = EventInventoryAllocation::with('inventoryItem')
                    ->where(function($query) {
                        $query->where('quantity_damaged', '>', 0)
                              ->orWhere('quantity_missing', '>', 0);
                    })
                    // Filter by when the event was allocated (or returned if returned_at exists)
                    ->where(function($query) use ($startDateTime, $endDateTime) {
                        $query->whereBetween('allocated_at', [$startDateTime, $endDateTime])
                              ->orWhereBetween('returned_at', [$startDateTime, $endDateTime]);
                    })
                    ->get()
                    ->groupBy('inventory_item_id')
                    ->map(function($allocations) {
                        $item = $allocations->first()->inventoryItem;
                        return [
                            'item_name' => $item->name,
                            'category' => $item->category,
                            'total_damaged' => $allocations->sum('quantity_damaged'),
                            'total_lost' => $allocations->sum('quantity_missing'),
                            'total_cost' => ($allocations->sum('quantity_damaged') + $allocations->sum('quantity_missing')) * ($item->unit_cost ?? 0)
                        ];
                    });
            }

            // Utilization report from event inventory allocations
            $utilizationReport = InventoryItem::get()
                ->map(function($item) use ($startDateTime, $endDateTime) {
                    $totalAllocatedInPeriod = 0;
                    $totalAllocatedOverall = 0;
                    $currentlyReserved = $item->reserved_quantity ?? 0;
                    
                    if (DB::getSchemaBuilder()->hasTable('event_inventory_allocations')) {
                        // Allocations in the specific period
                        $totalAllocatedInPeriod = EventInventoryAllocation::where('inventory_item_id', $item->id)
                            ->whereBetween('allocated_at', [$startDateTime, $endDateTime])
                            ->sum('quantity_allocated');
                            
                        // Overall allocations (for comparison)
                        $totalAllocatedOverall = EventInventoryAllocation::where('inventory_item_id', $item->id)
                            ->sum('quantity_allocated');
                    }
                    
                    // Calculate utilization based on period allocations vs total quantity
                    $utilizationRate = $item->total_quantity > 0 ? ($totalAllocatedInPeriod / $item->total_quantity) * 100 : 0;
                    
                    // Current utilization based on what's currently reserved
                    $currentUtilization = $item->total_quantity > 0 ? ($currentlyReserved / $item->total_quantity) * 100 : 0;
                    
                    return [
                        'item_name' => $item->name,
                        'category' => $item->category,
                        'total_quantity' => $item->total_quantity,
                        'available_quantity' => $item->available_quantity,
                        'reserved_quantity' => $currentlyReserved,
                        'total_reserved' => $totalAllocatedInPeriod,
                        'total_allocated_overall' => $totalAllocatedOverall,
                        'utilization_rate' => round($utilizationRate, 2),
                        'current_utilization' => round($currentUtilization, 2)
                    ];
                })
                ->sortByDesc('utilization_rate')
                ->values();

            // Debug information
            $debugInfo = [];
            if (DB::getSchemaBuilder()->hasTable('event_inventory_allocations')) {
                $debugInfo = [
                    'total_allocations' => EventInventoryAllocation::count(),
                    'allocations_with_damage' => EventInventoryAllocation::where('quantity_damaged', '>', 0)->count(),
                    'allocations_with_missing' => EventInventoryAllocation::where('quantity_missing', '>', 0)->count(),
                    'allocations_in_period' => EventInventoryAllocation::whereBetween('allocated_at', [$startDateTime, $endDateTime])->count(),
                    'sample_allocation' => EventInventoryAllocation::with('inventoryItem')->first()
                ];
            }

            return response()->json([
                'success' => true,
                'reports' => [
                    'damage_and_loss' => $damageReport->values(),
                    'utilization' => $utilizationReport,
                    'period' => [
                        'start_date' => $startDate,
                        'end_date' => $endDate
                    ]
                ],
                'debug' => $debugInfo
            ]);
        } catch (\Exception $e) {
            \Log::error('Inventory reports error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate reports',
                'error' => $e->getMessage()
            ], 500);
        }
    }


    /**
     * Get activity type for display
     */
    private function getActivityType(string $action): string
    {
        if (str_contains($action, 'allocated')) {
            return 'allocation';
        } elseif (str_contains($action, 'returned')) {
            return 'return';
        } elseif (str_contains($action, 'inventory_created')) {
            return 'created';
        } elseif (str_contains($action, 'inventory_updated')) {
            return 'updated';
        } elseif (str_contains($action, 'inventory_deleted')) {
            return 'deleted';
        } else {
            return 'other';
        }
    }

    /**
     * Map audit log action to transaction type for inventory details
     */
    private function mapAuditActionToTransactionType(string $action): string
    {
        if (str_contains($action, 'allocated') || str_contains($action, 'inventory_allocated')) {
            return 'reserve';
        } elseif (str_contains($action, 'returned') || str_contains($action, 'inventory_returned')) {
            return 'return';
        } elseif (str_contains($action, 'inventory_created')) {
            return 'add';
        } elseif (str_contains($action, 'inventory_updated')) {
            return 'update';
        } elseif (str_contains($action, 'inventory_deleted')) {
            return 'delete';
        } elseif (str_contains($action, 'damage')) {
            return 'damage';
        } elseif (str_contains($action, 'loss') || str_contains($action, 'missing')) {
            return 'loss';
        } else {
            return 'other';
        }
    }

    /**
     * Get all categories
     */
    public function getCategories(): JsonResponse
    {
        try {
            // Check if categories table exists
            $tableExists = DB::getSchemaBuilder()->hasTable('categories');
            \Log::info('Categories table exists: ' . ($tableExists ? 'yes' : 'no'));
            
            if (!$tableExists) {
                return response()->json([
                    'success' => false,
                    'message' => 'Categories table not found. Please run migrations first.',
                    'debug' => [
                        'table_exists' => false,
                        'suggestion' => 'Run: php artisan migrate'
                    ]
                ], 404);
            }

            // Check if Category model exists and has the required methods
            if (!class_exists('App\Models\Category')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Category model not found.',
                    'debug' => [
                        'model_exists' => false
                    ]
                ], 500);
            }

            $categories = Category::active()->ordered()->get();
            \Log::info('Categories loaded: ' . $categories->count());

            return response()->json([
                'success' => true,
                'categories' => $categories,
                'debug' => [
                    'table_exists' => true,
                    'model_exists' => true,
                    'count' => $categories->count()
                ]
            ]);
        } catch (\Exception $e) {
            \Log::error('Categories error: ' . $e->getMessage());
            \Log::error('Stack trace: ' . $e->getTraceAsString());
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch categories: ' . $e->getMessage(),
                'debug' => [
                    'error_line' => $e->getLine(),
                    'error_file' => basename($e->getFile()),
                    'error_message' => $e->getMessage()
                ]
            ], 500);
        }
    }

    /**
     * Store a new category
     */
    public function storeCategory(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255|unique:categories,name',
                'icon' => 'required|string|max:255',
                'color' => 'required|string|max:7',
                'description' => 'nullable|string',
                'sort_order' => 'nullable|integer'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $category = Category::create([
                'name' => $request->name,
                'icon' => $request->icon,
                'color' => $request->color,
                'description' => $request->description,
                'sort_order' => $request->sort_order ?? 0,
                'is_active' => true
            ]);

            return response()->json([
                'success' => true,
                'category' => $category,
                'message' => 'Category created successfully'
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create category: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update a category
     */
    public function updateCategory(Request $request, $id): JsonResponse
    {
        try {
            $category = Category::findOrFail($id);

            $validator = Validator::make($request->all(), [
                'name' => 'sometimes|string|max:255|unique:categories,name,' . $id,
                'icon' => 'sometimes|string|max:255',
                'color' => 'sometimes|string|max:7',
                'description' => 'nullable|string',
                'sort_order' => 'nullable|integer',
                'is_active' => 'sometimes|boolean'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $category->update($request->only([
                'name', 'icon', 'color', 'description', 'sort_order', 'is_active'
            ]));

            return response()->json([
                'success' => true,
                'category' => $category,
                'message' => 'Category updated successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update category: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete a category
     */
    public function destroyCategory($id): JsonResponse
    {
        try {
            $category = Category::findOrFail($id);

            // Check if category has inventory items
            $itemCount = InventoryItem::where('category', $category->name)->count();
            if ($itemCount > 0) {
                return response()->json([
                    'success' => false,
                    'message' => "Cannot delete category '{$category->name}' because it has {$itemCount} inventory items. Please reassign or delete the items first."
                ], 400);
            }

            $category->delete();

            return response()->json([
                'success' => true,
                'message' => 'Category deleted successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete category: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Debug allocations data
     */
    public function debugAllocations(): JsonResponse
    {
        try {
            if (!DB::getSchemaBuilder()->hasTable('event_inventory_allocations')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Event inventory allocations table does not exist'
                ]);
            }

            $allocations = EventInventoryAllocation::with('inventoryItem')
                ->orderBy('created_at', 'desc')
                ->limit(10)
                ->get();

            $summary = [
                'total_allocations' => EventInventoryAllocation::count(),
                'with_damage' => EventInventoryAllocation::where('quantity_damaged', '>', 0)->count(),
                'with_missing' => EventInventoryAllocation::where('quantity_missing', '>', 0)->count(),
                'recent_allocations' => $allocations->map(function($allocation) {
                    return [
                        'id' => $allocation->id,
                        'item_name' => $allocation->inventoryItem->name ?? 'Unknown',
                        'quantity_allocated' => $allocation->quantity_allocated,
                        'quantity_damaged' => $allocation->quantity_damaged,
                        'quantity_missing' => $allocation->quantity_missing,
                        'allocated_at' => $allocation->allocated_at,
                        'returned_at' => $allocation->returned_at,
                        'created_at' => $allocation->created_at,
                    ];
                })
            ];

            return response()->json([
                'success' => true,
                'data' => $summary
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Seed test inventory data
     */
    public function seedTestData(): JsonResponse
    {
        try {
            if (!DB::getSchemaBuilder()->hasTable('inventory_items')) {
                return response()->json([
                    'success' => false,
                    'message' => 'Inventory items table does not exist. Please run migrations first.'
                ]);
            }

            // Check if data already exists
            if (InventoryItem::count() > 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'Inventory data already exists. Use this endpoint only on empty database.'
                ]);
            }

            // Create sample inventory items
            $sampleItems = [
                [
                    'name' => 'Round Tables (8-person)',
                    'description' => 'Large round tables for 8 people',
                    'category' => 'Tables',
                    'total_quantity' => 20,
                    'available_quantity' => 15,
                    'reserved_quantity' => 5,
                    'unit_cost' => 150.00,
                    'condition' => 'good',
                    'location' => 'Warehouse A'
                ],
                [
                    'name' => 'Chiavari Chairs',
                    'description' => 'Gold chiavari chairs',
                    'category' => 'Chairs',
                    'total_quantity' => 100,
                    'available_quantity' => 80,
                    'reserved_quantity' => 20,
                    'unit_cost' => 25.00,
                    'condition' => 'good',
                    'location' => 'Warehouse A'
                ],
                [
                    'name' => 'White Tablecloths',
                    'description' => 'Premium white tablecloths',
                    'category' => 'Linens',
                    'total_quantity' => 50,
                    'available_quantity' => 45,
                    'reserved_quantity' => 5,
                    'unit_cost' => 15.00,
                    'condition' => 'good',
                    'location' => 'Storage Room B'
                ],
                [
                    'name' => 'Sound System',
                    'description' => 'Professional sound system with microphones',
                    'category' => 'Audio/Visual',
                    'total_quantity' => 3,
                    'available_quantity' => 2,
                    'reserved_quantity' => 1,
                    'unit_cost' => 500.00,
                    'condition' => 'good',
                    'location' => 'Equipment Room'
                ],
                [
                    'name' => 'LED String Lights',
                    'description' => 'Warm white LED string lights',
                    'category' => 'Lighting',
                    'total_quantity' => 25,
                    'available_quantity' => 20,
                    'reserved_quantity' => 5,
                    'unit_cost' => 30.00,
                    'condition' => 'good',
                    'location' => 'Storage Room C'
                ]
            ];

            foreach ($sampleItems as $item) {
                InventoryItem::create($item);
            }

            return response()->json([
                'success' => true,
                'message' => 'Test inventory data created successfully',
                'items_created' => count($sampleItems)
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error creating test data: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Check for low stock and create notifications
     */
    private function checkLowStockNotifications(InventoryItem $item, $threshold = 10)
    {
        try {
            if ($item->available_quantity <= 0) {
                // Out of stock
                NotificationService::createOutOfStockNotification($item);
            } elseif ($item->available_quantity <= $threshold) {
                // Low stock
                NotificationService::createLowStockNotification($item, $threshold);
            }
        } catch (\Exception $e) {
            \Log::error('Error checking low stock notifications: ' . $e->getMessage());
        }
    }

    /**
     * Check all inventory for low stock and create notifications
     */
    public function checkAllLowStock(Request $request): JsonResponse
    {
        try {
            $threshold = $request->get('threshold', 10);
            $result = NotificationService::checkAndNotifyLowStock($threshold);

            if ($result === false) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to check low stock items'
                ], 500);
            }

            return response()->json([
                'success' => true,
                'message' => 'Low stock check completed',
                'data' => $result
            ]);
        } catch (\Exception $e) {
            \Log::error('Low stock check error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to check low stock items',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get low stock items for dashboard
     */
    public function getLowStockItems(Request $request): JsonResponse
    {
        try {
            $threshold = $request->get('threshold', 10);
            
            $lowStockItems = InventoryItem::where('available_quantity', '<=', $threshold)
                ->where('available_quantity', '>', 0)
                ->orderBy('available_quantity', 'asc')
                ->get();

            $outOfStockItems = InventoryItem::where('available_quantity', '<=', 0)
                ->orderBy('name', 'asc')
                ->get();

            return response()->json([
                'success' => true,
                'data' => [
                    'low_stock_items' => $lowStockItems,
                    'out_of_stock_items' => $outOfStockItems,
                    'threshold' => $threshold,
                    'counts' => [
                        'low_stock' => $lowStockItems->count(),
                        'out_of_stock' => $outOfStockItems->count(),
                        'total_critical' => $lowStockItems->count() + $outOfStockItems->count()
                    ]
                ]
            ]);
        } catch (\Exception $e) {
            \Log::error('Get low stock items error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to get low stock items',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
