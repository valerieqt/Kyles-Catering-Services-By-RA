<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Services\BookingEmailService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{
    protected $bookingEmailService;

    public function __construct(BookingEmailService $bookingEmailService)
    {
        $this->bookingEmailService = $bookingEmailService;
    }

    public function index()
    {
        $bookings = Auth::user()->bookings()->with('user')->orderBy('event_date', 'desc')->get();
        return view('bookings.index', compact('bookings'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'event_name' => 'required|string|max:255',
            'event_date' => 'required|date|after:today',
            'event_time' => 'required|string',
            'guest_count' => 'required|string',
            'event_type' => 'required|string',
            'package_type' => 'nullable|string',
            'venue' => 'required|string|max:255',
            'contact_phone' => 'required|string|max:20',
            'additional_details' => 'nullable|string|max:1000',
            'special_requests' => 'nullable|string|max:1000',
            'menu_preferences' => 'nullable|string|max:1000'
        ]);

        $validated['user_id'] = Auth::id();
        $validated['status'] = 'pending';

        $booking = Booking::create($validated);

        // Send confirmation email
        $this->bookingEmailService->sendBookingConfirmation($booking);

        return redirect('/#book-now')->with('success', 'Your booking request has been submitted successfully! A confirmation email has been sent to you.');
    }

    public function show(Booking $booking)
    {
        // Ensure user can only view their own bookings
        if ($booking->user_id !== Auth::id()) {
            abort(403);
        }

        return view('bookings.show', compact('booking'));
    }

    public function edit(Booking $booking)
    {
        // Ensure user can only edit their own bookings
        if ($booking->user_id !== Auth::id()) {
            abort(403);
        }

        // Don't allow editing of confirmed or completed bookings
        if (in_array($booking->status, ['confirmed', 'completed'])) {
            return redirect()->route('bookings.index')
                ->with('error', 'Cannot edit confirmed or completed bookings. Please contact us for changes.');
        }

        return view('bookings.edit', compact('booking'));
    }

    public function update(Request $request, Booking $booking)
    {
        // Ensure user can only update their own bookings
        if ($booking->user_id !== Auth::id()) {
            abort(403);
        }

        // Don't allow updates to confirmed or completed bookings
        if (in_array($booking->status, ['confirmed', 'completed'])) {
            return redirect()->route('bookings.index')
                ->with('error', 'Cannot update confirmed or completed bookings. Please contact us for changes.');
        }

        $validated = $request->validate([
            'event_name' => 'required|string|max:255',
            'event_date' => 'required|date|after:today',
            'event_time' => 'required|string',
            'guest_count' => 'required|string',
            'event_type' => 'required|string',
            'package_type' => 'nullable|string',
            'venue' => 'required|string|max:255',
            'contact_phone' => 'required|string|max:20',
            'additional_details' => 'nullable|string|max:1000',
            'special_requests' => 'nullable|string|max:1000',
            'menu_preferences' => 'nullable|string|max:1000'
        ]);

        $booking->update($validated);

        return redirect()->route('bookings.index')
            ->with('success', 'Booking updated successfully!');
    }

    public function reschedule(Request $request, Booking $booking)
    {
        // Ensure user can only reschedule their own bookings
        if ($booking->user_id !== Auth::id()) {
            abort(403);
        }

        // Don't allow rescheduling of completed bookings
        if ($booking->status === 'completed') {
            return redirect()->route('bookings.index')
                ->with('error', 'Cannot reschedule completed bookings.');
        }

        $validated = $request->validate([
            'event_date' => 'required|date|after:today',
            'event_time' => 'required|string',
            'reschedule_reason' => 'nullable|string|max:500'
        ]);

        $oldDate = $booking->event_date;
        $oldTime = $booking->event_time;

        $booking->update([
            'event_date' => $validated['event_date'],
            'event_time' => $validated['event_time'],
            'status' => 'pending' // Reset to pending for admin review
        ]);

        // Send reschedule confirmation email
        $this->bookingEmailService->sendRescheduleConfirmation($booking, $oldDate, $oldTime);

        return redirect()->route('bookings.index')
            ->with('success', "Booking rescheduled successfully from {$oldDate->format('M j, Y')} at {$oldTime} to {$booking->event_date->format('M j, Y')} at {$booking->event_time}. A confirmation email has been sent.");
    }

    public function cancel(Request $request, Booking $booking)
    {
        // Ensure user can only cancel their own bookings
        if ($booking->user_id !== Auth::id()) {
            abort(403);
        }

        // Don't allow cancellation of completed bookings
        if ($booking->status === 'completed') {
            return redirect()->route('bookings.index')
                ->with('error', 'Cannot cancel completed bookings.');
        }

        $validated = $request->validate([
            'cancellation_reason' => 'nullable|string|max:500'
        ]);

        $booking->update([
            'status' => 'cancelled'
        ]);

        // Send cancellation confirmation email
        $this->bookingEmailService->sendCancellationConfirmation($booking);
        
        return redirect()->route('bookings.index')
            ->with('success', 'Booking cancelled successfully. A confirmation email has been sent to you.');
    }

}
