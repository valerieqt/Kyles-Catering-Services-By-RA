<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class AuditLogController extends Controller
{
    /**
     * Get audit logs with optional filtering.
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $query = AuditLog::query()->orderBy('created_at', 'desc');

            // Filter by action
            if ($request->has('action') && $request->action !== 'all') {
                $query->byAction($request->action);
            }

            // Filter by user
            if ($request->has('user_id')) {
                $query->byUser($request->user_id);
            }

            // Pagination
            $limit = $request->get('limit', 50);
            $page = $request->get('page', 1);
            
            $logs = $query->paginate($limit, ['*'], 'page', $page);

            return response()->json([
                'success' => true,
                'logs' => $logs->items(),
                'pagination' => [
                    'current_page' => $logs->currentPage(),
                    'last_page' => $logs->lastPage(),
                    'per_page' => $logs->perPage(),
                    'total' => $logs->total(),
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch audit logs',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Create a new audit log entry.
     */
    public function store(Request $request): JsonResponse
    {
        try {
            $request->validate([
                'action' => 'required|string|max:255',
                'description' => 'required|string',
                'metadata' => 'nullable|array',
            ]);

            AuditLog::log(
                $request->action,
                $request->description,
                $request->metadata
            );

            return response()->json([
                'success' => true,
                'message' => 'Audit log created successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create audit log',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get audit log statistics.
     */
    public function stats(): JsonResponse
    {
        try {
            $stats = [
                'total_logs' => AuditLog::count(),
                'recent_logs' => AuditLog::recent(7)->count(),
                'actions_summary' => AuditLog::selectRaw('action, COUNT(*) as count')
                    ->groupBy('action')
                    ->orderBy('count', 'desc')
                    ->limit(10)
                    ->get(),
                'top_users' => AuditLog::selectRaw('user_name, COUNT(*) as count')
                    ->groupBy('user_name', 'user_id')
                    ->orderBy('count', 'desc')
                    ->limit(10)
                    ->get(),
            ];

            return response()->json([
                'success' => true,
                'stats' => $stats
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch audit log statistics',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
