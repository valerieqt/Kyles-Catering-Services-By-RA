<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class TaskController extends Controller
{
    public function index(Request $request)
    {
        $selectedDate = $request->get('date', now()->toDateString());
        
        $tasks = Task::with(['user', 'creator'])
            ->forDate($selectedDate)
            ->orderBy('task_time')
            ->get();

        $upcomingTasks = Task::with(['user', 'creator'])
            ->upcoming()
            ->limit(5)
            ->get();

        return view('tasks.index', compact('tasks', 'selectedDate', 'upcomingTasks'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'task_date' => 'required|date|after_or_equal:today',
            'task_time' => 'required|date_format:H:i',
            'type' => 'required|string|in:meeting,food_tasting,client_meeting,consultation,other',
            'user_id' => 'nullable|exists:users,id'
        ]);

        $validated['created_by'] = Auth::id();
        
        // Combine date and time for proper datetime storage
        $taskDateTime = Carbon::createFromFormat('Y-m-d H:i', $validated['task_date'] . ' ' . $validated['task_time']);
        $validated['task_time'] = $taskDateTime->format('H:i:s');

        $task = Task::create($validated);

        if ($request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Task created successfully!',
                'task' => $task->load(['user', 'creator'])
            ]);
        }

        return redirect()->route('tasks.index', ['date' => $validated['task_date']])
            ->with('success', 'Task created successfully!');
    }

    public function show(Task $task)
    {
        $task->load(['user', 'creator']);
        return view('tasks.show', compact('task'));
    }

    public function update(Request $request, Task $task)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'task_date' => 'required|date',
            'task_time' => 'required|date_format:H:i',
            'type' => 'required|string|in:meeting,food_tasting,client_meeting,consultation,other',
            'status' => 'required|string|in:pending,in_progress,completed,cancelled',
            'user_id' => 'nullable|exists:users,id'
        ]);

        // Combine date and time for proper datetime storage
        $taskDateTime = Carbon::createFromFormat('Y-m-d H:i', $validated['task_date'] . ' ' . $validated['task_time']);
        $validated['task_time'] = $taskDateTime->format('H:i:s');

        $task->update($validated);

        if ($request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Task updated successfully!',
                'task' => $task->load(['user', 'creator'])
            ]);
        }

        return redirect()->route('tasks.index', ['date' => $validated['task_date']])
            ->with('success', 'Task updated successfully!');
    }

    public function destroy(Task $task)
    {
        $task->delete();

        if (request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Task deleted successfully!'
            ]);
        }

        return redirect()->route('tasks.index')
            ->with('success', 'Task deleted successfully!');
    }

    public function getTasksForDate(Request $request)
    {
        $date = $request->get('date', now()->toDateString());
        
        $tasks = Task::with(['user', 'creator'])
            ->forDate($date)
            ->orderBy('task_time')
            ->get();

        return response()->json([
            'tasks' => $tasks,
            'date' => $date
        ]);
    }

    public function markComplete(Task $task)
    {
        $task->update(['status' => 'completed']);

        if (request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Task marked as completed!',
                'task' => $task->load(['user', 'creator'])
            ]);
        }

        return redirect()->back()->with('success', 'Task marked as completed!');
    }
}
