<?php

namespace App\Notifications;

use Illuminate\Notifications\Notification;
use App\Services\PHPMailerService;
use Illuminate\Support\Facades\Log;

class CustomResetPasswordNotification extends Notification
{
    public $token;

    public function __construct($token)
    {
        $this->token = $token;
    }

    public function via($notifiable)
    {
        return ['phpmailer'];
    }

    public function toPhpMailer($notifiable)
    {
        try {
            $phpMailerService = new PHPMailerService();
            $userName = $notifiable->name ?? null;
            
            $result = $phpMailerService->sendPasswordResetEmail(
                $notifiable->email,
                $this->token,
                $userName
            );

            if (!$result) {
                Log::error('Failed to send password reset email via PHPMailer for user: ' . $notifiable->email);
                throw new \Exception('Failed to send password reset email');
            }

            return $result;
        } catch (\Exception $e) {
            Log::error('PHPMailer notification error: ' . $e->getMessage());
            throw $e;
        }
    }

    public function toArray($notifiable)
    {
        return [
            'token' => $this->token,
            'email' => $notifiable->email,
        ];
    }
}
